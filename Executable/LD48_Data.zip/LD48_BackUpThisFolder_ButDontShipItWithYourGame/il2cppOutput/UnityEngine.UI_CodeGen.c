﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.String UnityEngine.UI.AnimationTriggers::get_normalTrigger()
extern void AnimationTriggers_get_normalTrigger_m823230E912A9564E56E2047E9E3A819B2B8FA55C (void);
// 0x00000002 System.Void UnityEngine.UI.AnimationTriggers::set_normalTrigger(System.String)
extern void AnimationTriggers_set_normalTrigger_m5F067D4F2FE49D95597B57047C3409F49633E46E (void);
// 0x00000003 System.String UnityEngine.UI.AnimationTriggers::get_highlightedTrigger()
extern void AnimationTriggers_get_highlightedTrigger_mD525FBB2FE079F203C0D93E1C361E8EDB2F3A3E0 (void);
// 0x00000004 System.Void UnityEngine.UI.AnimationTriggers::set_highlightedTrigger(System.String)
extern void AnimationTriggers_set_highlightedTrigger_m1F0FA3B4776E5CDA87AD942BE5694CEC8789E433 (void);
// 0x00000005 System.String UnityEngine.UI.AnimationTriggers::get_pressedTrigger()
extern void AnimationTriggers_get_pressedTrigger_m00190AD173D951B0F7E85B5F34361FE05AB1DE44 (void);
// 0x00000006 System.Void UnityEngine.UI.AnimationTriggers::set_pressedTrigger(System.String)
extern void AnimationTriggers_set_pressedTrigger_mF29EFB61939FE540D2849F96E8E1F0064E6647F2 (void);
// 0x00000007 System.String UnityEngine.UI.AnimationTriggers::get_selectedTrigger()
extern void AnimationTriggers_get_selectedTrigger_m008AFE8B295E04A47A1DD0B892EAE0506A9230FB (void);
// 0x00000008 System.Void UnityEngine.UI.AnimationTriggers::set_selectedTrigger(System.String)
extern void AnimationTriggers_set_selectedTrigger_m5E60D0E74C1A135BC8954EDF5479EC4780A65FD0 (void);
// 0x00000009 System.String UnityEngine.UI.AnimationTriggers::get_disabledTrigger()
extern void AnimationTriggers_get_disabledTrigger_mBC66170C0C45E08679FF1573FEE0F2B66175C83E (void);
// 0x0000000A System.Void UnityEngine.UI.AnimationTriggers::set_disabledTrigger(System.String)
extern void AnimationTriggers_set_disabledTrigger_mCCB3B04B6691787427DDFF8B1DCD49C198D263BA (void);
// 0x0000000B System.Void UnityEngine.UI.AnimationTriggers::.ctor()
extern void AnimationTriggers__ctor_m11FA25E6EC5A9BA71A3F725FDBAA3F5527AF946F (void);
// 0x0000000C System.Void UnityEngine.UI.Button::.ctor()
extern void Button__ctor_mEAD32B0D4006442C955F50B4577C5DF907EBCB5B (void);
// 0x0000000D UnityEngine.UI.Button/ButtonClickedEvent UnityEngine.UI.Button::get_onClick()
extern void Button_get_onClick_m77E8CA6917881760CC7900930F4C789F3E2F8817 (void);
// 0x0000000E System.Void UnityEngine.UI.Button::set_onClick(UnityEngine.UI.Button/ButtonClickedEvent)
extern void Button_set_onClick_m65B3D7697B513EEAB4193A246BE8D93C0D9B29DE (void);
// 0x0000000F System.Void UnityEngine.UI.Button::Press()
extern void Button_Press_m33BA6E9820146E8EED7AB489A8846D879B76CF41 (void);
// 0x00000010 System.Void UnityEngine.UI.Button::OnPointerClick(UnityEngine.EventSystems.PointerEventData)
extern void Button_OnPointerClick_m4C4EDB8613C2C5B391EFD3A29C58B0AA00DD9B91 (void);
// 0x00000011 System.Void UnityEngine.UI.Button::OnSubmit(UnityEngine.EventSystems.BaseEventData)
extern void Button_OnSubmit_m7CE6A04596CA9691D3E0D6D669FAD86E9A6D3427 (void);
// 0x00000012 System.Collections.IEnumerator UnityEngine.UI.Button::OnFinishSubmit()
extern void Button_OnFinishSubmit_mDDCC87F264A34E86148891F24646F655C0AF7E42 (void);
// 0x00000013 System.Void UnityEngine.UI.ICanvasElement::Rebuild(UnityEngine.UI.CanvasUpdate)
// 0x00000014 UnityEngine.Transform UnityEngine.UI.ICanvasElement::get_transform()
// 0x00000015 System.Void UnityEngine.UI.ICanvasElement::LayoutComplete()
// 0x00000016 System.Void UnityEngine.UI.ICanvasElement::GraphicUpdateComplete()
// 0x00000017 System.Boolean UnityEngine.UI.ICanvasElement::IsDestroyed()
// 0x00000018 System.Void UnityEngine.UI.CanvasUpdateRegistry::.ctor()
extern void CanvasUpdateRegistry__ctor_mA9DFE374CF59026B50EBE37E147854270730EE00 (void);
// 0x00000019 UnityEngine.UI.CanvasUpdateRegistry UnityEngine.UI.CanvasUpdateRegistry::get_instance()
extern void CanvasUpdateRegistry_get_instance_m6A2150EA4C8C74AF18E53B3CF22BF6EAF70FF927 (void);
// 0x0000001A System.Boolean UnityEngine.UI.CanvasUpdateRegistry::ObjectValidForUpdate(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_ObjectValidForUpdate_m2E72AF124053FD1E9003B488EC296410A74566C6 (void);
// 0x0000001B System.Void UnityEngine.UI.CanvasUpdateRegistry::CleanInvalidItems()
extern void CanvasUpdateRegistry_CleanInvalidItems_mBCA41C6F93EA42647274051F7DA61F36D3330DA3 (void);
// 0x0000001C System.Void UnityEngine.UI.CanvasUpdateRegistry::PerformUpdate()
extern void CanvasUpdateRegistry_PerformUpdate_m394F8B8FDD92DFCDFEEF86767B7A294B04211719 (void);
// 0x0000001D System.Int32 UnityEngine.UI.CanvasUpdateRegistry::ParentCount(UnityEngine.Transform)
extern void CanvasUpdateRegistry_ParentCount_m198B2252296D2FE5BB5EB22EBE0FD1444B8E81A9 (void);
// 0x0000001E System.Int32 UnityEngine.UI.CanvasUpdateRegistry::SortLayoutList(UnityEngine.UI.ICanvasElement,UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_SortLayoutList_m157F65FF5A7EB039678F6EF3B1F3B8CF355BD4EB (void);
// 0x0000001F System.Void UnityEngine.UI.CanvasUpdateRegistry::RegisterCanvasElementForLayoutRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_RegisterCanvasElementForLayoutRebuild_m97E606B5F1E848A6ACBA44ABE5E5A2A5ED99DCDA (void);
// 0x00000020 System.Boolean UnityEngine.UI.CanvasUpdateRegistry::TryRegisterCanvasElementForLayoutRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_TryRegisterCanvasElementForLayoutRebuild_m1AE79FC7D20A9212CB55D436BA9AE807A22E2A1F (void);
// 0x00000021 System.Boolean UnityEngine.UI.CanvasUpdateRegistry::InternalRegisterCanvasElementForLayoutRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_InternalRegisterCanvasElementForLayoutRebuild_m1F8CC12B180B85AE9D3CA4ED52DE3A4544A9D5E4 (void);
// 0x00000022 System.Void UnityEngine.UI.CanvasUpdateRegistry::RegisterCanvasElementForGraphicRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_RegisterCanvasElementForGraphicRebuild_m0D3A7158D8301462FF18CC00909AD105FF1591AE (void);
// 0x00000023 System.Boolean UnityEngine.UI.CanvasUpdateRegistry::TryRegisterCanvasElementForGraphicRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_TryRegisterCanvasElementForGraphicRebuild_m36405C59F3D0FA49C55737FE5481D00F5BC6350F (void);
// 0x00000024 System.Boolean UnityEngine.UI.CanvasUpdateRegistry::InternalRegisterCanvasElementForGraphicRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_InternalRegisterCanvasElementForGraphicRebuild_mFEFBCA741876E89C572A3BFBFD7EEC4D0FE503E4 (void);
// 0x00000025 System.Void UnityEngine.UI.CanvasUpdateRegistry::UnRegisterCanvasElementForRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_UnRegisterCanvasElementForRebuild_m79A4C7207CDAC083E716F9AA859F1763B8F84D84 (void);
// 0x00000026 System.Void UnityEngine.UI.CanvasUpdateRegistry::InternalUnRegisterCanvasElementForLayoutRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_InternalUnRegisterCanvasElementForLayoutRebuild_m3F6811D17DFF1519E71788D368A7BEB860DCE9E4 (void);
// 0x00000027 System.Void UnityEngine.UI.CanvasUpdateRegistry::InternalUnRegisterCanvasElementForGraphicRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_InternalUnRegisterCanvasElementForGraphicRebuild_mCACDA2130D25B96229C3C1594D44BD9347420784 (void);
// 0x00000028 System.Boolean UnityEngine.UI.CanvasUpdateRegistry::IsRebuildingLayout()
extern void CanvasUpdateRegistry_IsRebuildingLayout_m5720F54D56B252982240E5DF4723A3BA7B7A891B (void);
// 0x00000029 System.Boolean UnityEngine.UI.CanvasUpdateRegistry::IsRebuildingGraphics()
extern void CanvasUpdateRegistry_IsRebuildingGraphics_m1C67401F44BB421AE8945B8B1B3CD2AC61B75E89 (void);
// 0x0000002A System.Void UnityEngine.UI.CanvasUpdateRegistry::.cctor()
extern void CanvasUpdateRegistry__cctor_m97762F83684218576BD97297F450827240460C51 (void);
// 0x0000002B UnityEngine.Color UnityEngine.UI.ColorBlock::get_normalColor()
extern void ColorBlock_get_normalColor_mE0A4EBADEFB7A6F245F590B0A5DBB59F289C0905 (void);
// 0x0000002C System.Void UnityEngine.UI.ColorBlock::set_normalColor(UnityEngine.Color)
extern void ColorBlock_set_normalColor_mAB3355641A3BA73B63E1A8727EC51A095262CC51 (void);
// 0x0000002D UnityEngine.Color UnityEngine.UI.ColorBlock::get_highlightedColor()
extern void ColorBlock_get_highlightedColor_m779349828B304DB2551C3A3CCDDD69861A21EDFF (void);
// 0x0000002E System.Void UnityEngine.UI.ColorBlock::set_highlightedColor(UnityEngine.Color)
extern void ColorBlock_set_highlightedColor_m7E9A152B71CD6CBD5BEE9E4019547BD9CC991AF6 (void);
// 0x0000002F UnityEngine.Color UnityEngine.UI.ColorBlock::get_pressedColor()
extern void ColorBlock_get_pressedColor_m19AA95DCC2519975D93202C997EECB3E06CE96E5 (void);
// 0x00000030 System.Void UnityEngine.UI.ColorBlock::set_pressedColor(UnityEngine.Color)
extern void ColorBlock_set_pressedColor_m252EDA03CA097EF1604FF2678598BA6A294C13C8 (void);
// 0x00000031 UnityEngine.Color UnityEngine.UI.ColorBlock::get_selectedColor()
extern void ColorBlock_get_selectedColor_mE6DDB9D2D3466CCFFFF000286619BEC4AB60F83D (void);
// 0x00000032 System.Void UnityEngine.UI.ColorBlock::set_selectedColor(UnityEngine.Color)
extern void ColorBlock_set_selectedColor_mE731B0D4FFE33D3438CA3757F72B6808066937E2 (void);
// 0x00000033 UnityEngine.Color UnityEngine.UI.ColorBlock::get_disabledColor()
extern void ColorBlock_get_disabledColor_mD865FC8BCFE7B8535A51A68E78130409F3C97FC8 (void);
// 0x00000034 System.Void UnityEngine.UI.ColorBlock::set_disabledColor(UnityEngine.Color)
extern void ColorBlock_set_disabledColor_mABE874E9EF8C41CE83BB16B94C7511AF1FE8AE47 (void);
// 0x00000035 System.Single UnityEngine.UI.ColorBlock::get_colorMultiplier()
extern void ColorBlock_get_colorMultiplier_mA273A409AC9125C22CBCCB236F0E758C36BA9581 (void);
// 0x00000036 System.Void UnityEngine.UI.ColorBlock::set_colorMultiplier(System.Single)
extern void ColorBlock_set_colorMultiplier_m8EE6BD49B92CA0C7E801E9D4E39F0AB39237FE26 (void);
// 0x00000037 System.Single UnityEngine.UI.ColorBlock::get_fadeDuration()
extern void ColorBlock_get_fadeDuration_mCFF802DD654D7E9C3509A65974EB35153FDB1415 (void);
// 0x00000038 System.Void UnityEngine.UI.ColorBlock::set_fadeDuration(System.Single)
extern void ColorBlock_set_fadeDuration_m2C1C0A118396BB2DF370F2F87A6ECA861AE0CA63 (void);
// 0x00000039 UnityEngine.UI.ColorBlock UnityEngine.UI.ColorBlock::get_defaultColorBlock()
extern void ColorBlock_get_defaultColorBlock_mD3AEFDABCF5F714D81FB2047A744930650EC223E (void);
// 0x0000003A System.Boolean UnityEngine.UI.ColorBlock::Equals(System.Object)
extern void ColorBlock_Equals_m5F50CD8C86A89B8EFA4E878BD914656ECEB0177D (void);
// 0x0000003B System.Boolean UnityEngine.UI.ColorBlock::Equals(UnityEngine.UI.ColorBlock)
extern void ColorBlock_Equals_mCD07A68D8E306D372ECA1D13BDA091E9579B4AEE (void);
// 0x0000003C System.Boolean UnityEngine.UI.ColorBlock::op_Equality(UnityEngine.UI.ColorBlock,UnityEngine.UI.ColorBlock)
extern void ColorBlock_op_Equality_m5D66A64DD671C058B490AB603192AF53B505DE86 (void);
// 0x0000003D System.Boolean UnityEngine.UI.ColorBlock::op_Inequality(UnityEngine.UI.ColorBlock,UnityEngine.UI.ColorBlock)
extern void ColorBlock_op_Inequality_m78ECD4DA562EA2A1C98E66315F0A1BCB448603D6 (void);
// 0x0000003E System.Int32 UnityEngine.UI.ColorBlock::GetHashCode()
extern void ColorBlock_GetHashCode_m92C2ECB5F5118D21A01C35481D8CC9A091AB6B4B (void);
// 0x0000003F System.Void UnityEngine.UI.ClipperRegistry::.ctor()
extern void ClipperRegistry__ctor_m7F1EE293535B9B61C281BC6CCF563051B1212A74 (void);
// 0x00000040 UnityEngine.UI.ClipperRegistry UnityEngine.UI.ClipperRegistry::get_instance()
extern void ClipperRegistry_get_instance_mE4E214237577A08B2A6C8AF9DD7CDAE1B75E387B (void);
// 0x00000041 System.Void UnityEngine.UI.ClipperRegistry::Cull()
extern void ClipperRegistry_Cull_m1ECFA826A6969A177CE2DC701056E4A5E73A4BCB (void);
// 0x00000042 System.Void UnityEngine.UI.ClipperRegistry::Register(UnityEngine.UI.IClipper)
extern void ClipperRegistry_Register_mF8163BA97EA885507238312E699186155494D4F6 (void);
// 0x00000043 System.Void UnityEngine.UI.ClipperRegistry::Unregister(UnityEngine.UI.IClipper)
extern void ClipperRegistry_Unregister_mE9C2B3D8B5C8C71FE5B888D621EABC5E7639C7A2 (void);
// 0x00000044 UnityEngine.Rect UnityEngine.UI.Clipping::FindCullAndClipWorldRect(System.Collections.Generic.List`1<UnityEngine.UI.RectMask2D>,System.Boolean&)
extern void Clipping_FindCullAndClipWorldRect_m1006EEFD92ECCD0551162A8E4D677970A00B597A (void);
// 0x00000045 System.Void UnityEngine.UI.IClipper::PerformClipping()
// 0x00000046 UnityEngine.GameObject UnityEngine.UI.IClippable::get_gameObject()
// 0x00000047 System.Void UnityEngine.UI.IClippable::RecalculateClipping()
// 0x00000048 UnityEngine.RectTransform UnityEngine.UI.IClippable::get_rectTransform()
// 0x00000049 System.Void UnityEngine.UI.IClippable::Cull(UnityEngine.Rect,System.Boolean)
// 0x0000004A System.Void UnityEngine.UI.IClippable::SetClipRect(UnityEngine.Rect,System.Boolean)
// 0x0000004B System.Void UnityEngine.UI.IClippable::SetClipSoftness(UnityEngine.Vector2)
// 0x0000004C UnityEngine.Rect UnityEngine.UI.RectangularVertexClipper::GetCanvasRect(UnityEngine.RectTransform,UnityEngine.Canvas)
extern void RectangularVertexClipper_GetCanvasRect_m3A009069CB93F6A0D61221B26FD7BACD6A57533F (void);
// 0x0000004D System.Void UnityEngine.UI.RectangularVertexClipper::.ctor()
extern void RectangularVertexClipper__ctor_mEE97397722ADAA581A3DF8267BA5DBCFE585AC6A (void);
// 0x0000004E UnityEngine.UI.DefaultControls/IFactoryControls UnityEngine.UI.DefaultControls::get_factory()
extern void DefaultControls_get_factory_m616056407908402EFF7E24BC02D0A1B0CDED98B2 (void);
// 0x0000004F UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateUIElementRoot(System.String,UnityEngine.Vector2,System.Type[])
extern void DefaultControls_CreateUIElementRoot_m17541BAE4AF1CE86FBAC92CF02933A4CDAB0FAD7 (void);
// 0x00000050 UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateUIObject(System.String,UnityEngine.GameObject,System.Type[])
extern void DefaultControls_CreateUIObject_mF356800BB8FDF5BF330B67B70FC4148D9D2FB47E (void);
// 0x00000051 System.Void UnityEngine.UI.DefaultControls::SetDefaultTextValues(UnityEngine.UI.Text)
extern void DefaultControls_SetDefaultTextValues_m79AA4B1F7A2061B259933C3F0CDBB12788BC3DFE (void);
// 0x00000052 System.Void UnityEngine.UI.DefaultControls::SetDefaultColorTransitionValues(UnityEngine.UI.Selectable)
extern void DefaultControls_SetDefaultColorTransitionValues_m7E4AA2E8B97EF5620C34FEE8D146FA35C054EB8F (void);
// 0x00000053 System.Void UnityEngine.UI.DefaultControls::SetParentAndAlign(UnityEngine.GameObject,UnityEngine.GameObject)
extern void DefaultControls_SetParentAndAlign_mC0E1D3DCB97427FF74488DFED23A51047E04E925 (void);
// 0x00000054 System.Void UnityEngine.UI.DefaultControls::SetLayerRecursively(UnityEngine.GameObject,System.Int32)
extern void DefaultControls_SetLayerRecursively_m85578EB1E86A92ADE30289C7A9B8B937CD6933CA (void);
// 0x00000055 UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreatePanel(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreatePanel_m6CC4319B8D81426FC2A4E94CA836AB4F0ECA0205 (void);
// 0x00000056 UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateButton(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateButton_m73704B2DEB6F80CF622B31A7B14BBEC3A24737C2 (void);
// 0x00000057 UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateText(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateText_mB0CA319F4BF0C8EC8773075885BD67D78A4582FE (void);
// 0x00000058 UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateImage(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateImage_m5A948ACE15B86771B6F3EB7A8A74EBE938CEB3E6 (void);
// 0x00000059 UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateRawImage(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateRawImage_m3704C3F2E829FBCFEEDA34F27668000B1E6E5A02 (void);
// 0x0000005A UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateSlider(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateSlider_m2AF0A50D2FF4EB21A68A5DBF92076C8DB6D50C5B (void);
// 0x0000005B UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateScrollbar(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateScrollbar_m876785B77922E7A0918137096FE9CEEC4BBCA1C6 (void);
// 0x0000005C UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateToggle(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateToggle_m9F0611E37F71C5C077EB3D64D998A7117C830B7F (void);
// 0x0000005D UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateInputField(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateInputField_mDF85B76D7CDE06E5E49F537EA5FDD8192DA5E65A (void);
// 0x0000005E UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateDropdown(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateDropdown_m00FF9DE1B54D5EA9B22EECC23EAB2D465538C0B2 (void);
// 0x0000005F UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateScrollView(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateScrollView_m18E2B79533E8C63917A90B112C7861D8777FAB89 (void);
// 0x00000060 System.Void UnityEngine.UI.DefaultControls::.cctor()
extern void DefaultControls__cctor_m7241DF8D34792725FB5E67F8FA801EAD9C45E2FE (void);
// 0x00000061 UnityEngine.RectTransform UnityEngine.UI.Dropdown::get_template()
extern void Dropdown_get_template_m9C83BB0CFD2BA72F08ACC8B0FA9A274FAD0FC9C4 (void);
// 0x00000062 System.Void UnityEngine.UI.Dropdown::set_template(UnityEngine.RectTransform)
extern void Dropdown_set_template_mB9D019C2D44DB5A936754540CA54AB20E948B395 (void);
// 0x00000063 UnityEngine.UI.Text UnityEngine.UI.Dropdown::get_captionText()
extern void Dropdown_get_captionText_m3E3FF20006F7EC8A8FD7ABBB7F9F723A0E3CD5FF (void);
// 0x00000064 System.Void UnityEngine.UI.Dropdown::set_captionText(UnityEngine.UI.Text)
extern void Dropdown_set_captionText_m6EB525A575E15A0A8FBBA3C5E1E04B2743B5CE97 (void);
// 0x00000065 UnityEngine.UI.Image UnityEngine.UI.Dropdown::get_captionImage()
extern void Dropdown_get_captionImage_mB846CCDC2F81DEC05EFC9FA1E38505409B428253 (void);
// 0x00000066 System.Void UnityEngine.UI.Dropdown::set_captionImage(UnityEngine.UI.Image)
extern void Dropdown_set_captionImage_m49D7CB97D0524B43A8C47234FA092E0EE1A2A8E5 (void);
// 0x00000067 UnityEngine.UI.Text UnityEngine.UI.Dropdown::get_itemText()
extern void Dropdown_get_itemText_m1AEEFE1ACF751CD3483659F5E5B703239C28C7D5 (void);
// 0x00000068 System.Void UnityEngine.UI.Dropdown::set_itemText(UnityEngine.UI.Text)
extern void Dropdown_set_itemText_m2D83A9DFB92CB75269DB174DD05560F416368240 (void);
// 0x00000069 UnityEngine.UI.Image UnityEngine.UI.Dropdown::get_itemImage()
extern void Dropdown_get_itemImage_m3B115ACA023FC279CAE1757FD4AB0DF91242BA50 (void);
// 0x0000006A System.Void UnityEngine.UI.Dropdown::set_itemImage(UnityEngine.UI.Image)
extern void Dropdown_set_itemImage_m6C79EE0427BB5C381856CF054A460127906A2718 (void);
// 0x0000006B System.Collections.Generic.List`1<UnityEngine.UI.Dropdown/OptionData> UnityEngine.UI.Dropdown::get_options()
extern void Dropdown_get_options_mF01AB08188E47DA9CD1488723FCBC453F29BDFA6 (void);
// 0x0000006C System.Void UnityEngine.UI.Dropdown::set_options(System.Collections.Generic.List`1<UnityEngine.UI.Dropdown/OptionData>)
extern void Dropdown_set_options_m89BE75A0A6378F91F04C2DFBCBF091DF8A59CB65 (void);
// 0x0000006D UnityEngine.UI.Dropdown/DropdownEvent UnityEngine.UI.Dropdown::get_onValueChanged()
extern void Dropdown_get_onValueChanged_m4EE82DC9AE8618C52CECA362EBDE6284F41E88FE (void);
// 0x0000006E System.Void UnityEngine.UI.Dropdown::set_onValueChanged(UnityEngine.UI.Dropdown/DropdownEvent)
extern void Dropdown_set_onValueChanged_m8AA65759FBF874CF3D12C19DA97229853FA7BD91 (void);
// 0x0000006F System.Single UnityEngine.UI.Dropdown::get_alphaFadeSpeed()
extern void Dropdown_get_alphaFadeSpeed_mE18CF6C0434FA3570CF19C8D9687A714068A830E (void);
// 0x00000070 System.Void UnityEngine.UI.Dropdown::set_alphaFadeSpeed(System.Single)
extern void Dropdown_set_alphaFadeSpeed_mC017C63451B6F976EA0B1E8189390B7C2CDEB5C5 (void);
// 0x00000071 System.Int32 UnityEngine.UI.Dropdown::get_value()
extern void Dropdown_get_value_m5FC2BBBD94BA37BFF81DDCE45F42E0782C44CFCD (void);
// 0x00000072 System.Void UnityEngine.UI.Dropdown::set_value(System.Int32)
extern void Dropdown_set_value_m8899C656D4A14C8AD965B64EBAFDAA1EFC8C056A (void);
// 0x00000073 System.Void UnityEngine.UI.Dropdown::SetValueWithoutNotify(System.Int32)
extern void Dropdown_SetValueWithoutNotify_m7099987027B026424BAD7D2B500E9D14A23ACB48 (void);
// 0x00000074 System.Void UnityEngine.UI.Dropdown::Set(System.Int32,System.Boolean)
extern void Dropdown_Set_m8C6D5C2E784DBA1A4F4AB73354DA8B2C1265386E (void);
// 0x00000075 System.Void UnityEngine.UI.Dropdown::.ctor()
extern void Dropdown__ctor_m8333CFE620788E03D2E44CAB4AADC60FFDD7D40D (void);
// 0x00000076 System.Void UnityEngine.UI.Dropdown::Awake()
extern void Dropdown_Awake_m55BEE1E9BED97A6179251A5AAE9D1E734BBE4A98 (void);
// 0x00000077 System.Void UnityEngine.UI.Dropdown::Start()
extern void Dropdown_Start_mA6A8B9D3F55B5E372C5A45C82DC632AB28136F11 (void);
// 0x00000078 System.Void UnityEngine.UI.Dropdown::OnDisable()
extern void Dropdown_OnDisable_m3957AFD9FF300E263AD7D406810014AB7EA07F51 (void);
// 0x00000079 System.Void UnityEngine.UI.Dropdown::RefreshShownValue()
extern void Dropdown_RefreshShownValue_mA221C69078DAADC64EF227C7F66390A1D49E32F1 (void);
// 0x0000007A System.Void UnityEngine.UI.Dropdown::AddOptions(System.Collections.Generic.List`1<UnityEngine.UI.Dropdown/OptionData>)
extern void Dropdown_AddOptions_mF71FBCA3EBE345DB77666E64422AA2845979604B (void);
// 0x0000007B System.Void UnityEngine.UI.Dropdown::AddOptions(System.Collections.Generic.List`1<System.String>)
extern void Dropdown_AddOptions_m9DC5D88B6326E8D1427323778484653E29E86F8E (void);
// 0x0000007C System.Void UnityEngine.UI.Dropdown::AddOptions(System.Collections.Generic.List`1<UnityEngine.Sprite>)
extern void Dropdown_AddOptions_mE65624F3D156B27E80F4820012C85DBB109DD7C8 (void);
// 0x0000007D System.Void UnityEngine.UI.Dropdown::ClearOptions()
extern void Dropdown_ClearOptions_mD85755513F827D82DF4A8EE04D2CEE91C4023EA0 (void);
// 0x0000007E System.Void UnityEngine.UI.Dropdown::SetupTemplate()
extern void Dropdown_SetupTemplate_m5CE6BC1866BDCDE6E94E367175F90E557F48E143 (void);
// 0x0000007F T UnityEngine.UI.Dropdown::GetOrAddComponent(UnityEngine.GameObject)
// 0x00000080 System.Void UnityEngine.UI.Dropdown::OnPointerClick(UnityEngine.EventSystems.PointerEventData)
extern void Dropdown_OnPointerClick_m4A7BCD99C3ADD0D5DFC3B94E0AF51110C73C5D5A (void);
// 0x00000081 System.Void UnityEngine.UI.Dropdown::OnSubmit(UnityEngine.EventSystems.BaseEventData)
extern void Dropdown_OnSubmit_m684758E3F3C8465F6580A17DB0A05C804BA3ACD3 (void);
// 0x00000082 System.Void UnityEngine.UI.Dropdown::OnCancel(UnityEngine.EventSystems.BaseEventData)
extern void Dropdown_OnCancel_mB5306D5E3BAAB6E9F3FBDE6487F02A06A6A0E568 (void);
// 0x00000083 System.Void UnityEngine.UI.Dropdown::Show()
extern void Dropdown_Show_mD7E5E0A23BA93F7DDCF937D487FAA4A03B810592 (void);
// 0x00000084 UnityEngine.GameObject UnityEngine.UI.Dropdown::CreateBlocker(UnityEngine.Canvas)
extern void Dropdown_CreateBlocker_m036190311A5551395BC6DD3807D909F851AC8075 (void);
// 0x00000085 System.Void UnityEngine.UI.Dropdown::DestroyBlocker(UnityEngine.GameObject)
extern void Dropdown_DestroyBlocker_m5C4902C6F0A8F48BA82286ED70CFC60F7BA19961 (void);
// 0x00000086 UnityEngine.GameObject UnityEngine.UI.Dropdown::CreateDropdownList(UnityEngine.GameObject)
extern void Dropdown_CreateDropdownList_m4C38DE76864D27BBA2033CD5DD72A88B1D2896A9 (void);
// 0x00000087 System.Void UnityEngine.UI.Dropdown::DestroyDropdownList(UnityEngine.GameObject)
extern void Dropdown_DestroyDropdownList_mD11E6DE18CA6767744F725B6B1326DB7247E2FD8 (void);
// 0x00000088 UnityEngine.UI.Dropdown/DropdownItem UnityEngine.UI.Dropdown::CreateItem(UnityEngine.UI.Dropdown/DropdownItem)
extern void Dropdown_CreateItem_m591B3B4546D13786893F9930BE702F3A9AAE3CDC (void);
// 0x00000089 System.Void UnityEngine.UI.Dropdown::DestroyItem(UnityEngine.UI.Dropdown/DropdownItem)
extern void Dropdown_DestroyItem_mB71C1CAFF2E69C20B2FF8A9A82E8CA6BDBC5D829 (void);
// 0x0000008A UnityEngine.UI.Dropdown/DropdownItem UnityEngine.UI.Dropdown::AddItem(UnityEngine.UI.Dropdown/OptionData,System.Boolean,UnityEngine.UI.Dropdown/DropdownItem,System.Collections.Generic.List`1<UnityEngine.UI.Dropdown/DropdownItem>)
extern void Dropdown_AddItem_m5F858BC2C6F291D7E8E674A36F7036A1CA4BEAB2 (void);
// 0x0000008B System.Void UnityEngine.UI.Dropdown::AlphaFadeList(System.Single,System.Single)
extern void Dropdown_AlphaFadeList_m0ECDEA6B54E8EC0ED2C4ACB016942122B6E9FB1E (void);
// 0x0000008C System.Void UnityEngine.UI.Dropdown::AlphaFadeList(System.Single,System.Single,System.Single)
extern void Dropdown_AlphaFadeList_m2B80644908D3927EEB29497DBEA5BB5B8B239316 (void);
// 0x0000008D System.Void UnityEngine.UI.Dropdown::SetAlpha(System.Single)
extern void Dropdown_SetAlpha_mE46118E546C9444182554BD55A1352401AC8CC9A (void);
// 0x0000008E System.Void UnityEngine.UI.Dropdown::Hide()
extern void Dropdown_Hide_m35382248CCB9AB3A863EC390BD50BEBEC2ACC1E4 (void);
// 0x0000008F System.Collections.IEnumerator UnityEngine.UI.Dropdown::DelayedDestroyDropdownList(System.Single)
extern void Dropdown_DelayedDestroyDropdownList_mFDA7D3AEA4860DEF70F855A259A6A3F7637139CC (void);
// 0x00000090 System.Void UnityEngine.UI.Dropdown::ImmediateDestroyDropdownList()
extern void Dropdown_ImmediateDestroyDropdownList_m6B7217213F4E6CC4089712453892CBEA8725E3A4 (void);
// 0x00000091 System.Void UnityEngine.UI.Dropdown::OnSelectItem(UnityEngine.UI.Toggle)
extern void Dropdown_OnSelectItem_m57F0626C9D1A326B4FA15BA4B2F20EF9D529D95B (void);
// 0x00000092 System.Void UnityEngine.UI.Dropdown::.cctor()
extern void Dropdown__cctor_m3B76BCC67847B1F4704C2A91FC7BBC1991630061 (void);
// 0x00000093 UnityEngine.UI.FontData UnityEngine.UI.FontData::get_defaultFontData()
extern void FontData_get_defaultFontData_m395A2BA13B11A53C4BD4E8F1B7D97E9E278D6063 (void);
// 0x00000094 UnityEngine.Font UnityEngine.UI.FontData::get_font()
extern void FontData_get_font_m63A03245926CD05B461E00C281724370C8B7D0F4 (void);
// 0x00000095 System.Void UnityEngine.UI.FontData::set_font(UnityEngine.Font)
extern void FontData_set_font_mE19CF5265530AC3200BE65E20E8F909210ED71D0 (void);
// 0x00000096 System.Int32 UnityEngine.UI.FontData::get_fontSize()
extern void FontData_get_fontSize_m4B7B4842DC663B866E006A4DF86EBC1C3BC095AF (void);
// 0x00000097 System.Void UnityEngine.UI.FontData::set_fontSize(System.Int32)
extern void FontData_set_fontSize_mFAB8C6A7548E75E958984BD5365348A131194B0F (void);
// 0x00000098 UnityEngine.FontStyle UnityEngine.UI.FontData::get_fontStyle()
extern void FontData_get_fontStyle_m463803A5ED384064EC9B03549BA921BEAAC8A4A6 (void);
// 0x00000099 System.Void UnityEngine.UI.FontData::set_fontStyle(UnityEngine.FontStyle)
extern void FontData_set_fontStyle_m25218403D504C2D0876E5AB25E813EEFAE85F93E (void);
// 0x0000009A System.Boolean UnityEngine.UI.FontData::get_bestFit()
extern void FontData_get_bestFit_m927FFB8A5BE4376FC966BC16E0431B443F00E691 (void);
// 0x0000009B System.Void UnityEngine.UI.FontData::set_bestFit(System.Boolean)
extern void FontData_set_bestFit_m0426EC53969FF4848061B4C37888D242BAD0E07A (void);
// 0x0000009C System.Int32 UnityEngine.UI.FontData::get_minSize()
extern void FontData_get_minSize_m40C332F61CFB0F164EB84B35A05E2A10B801667B (void);
// 0x0000009D System.Void UnityEngine.UI.FontData::set_minSize(System.Int32)
extern void FontData_set_minSize_mF884D9FD3B53247AB2C9EE9EEC15EA2CAEF04787 (void);
// 0x0000009E System.Int32 UnityEngine.UI.FontData::get_maxSize()
extern void FontData_get_maxSize_mCFC5C0F12AF21C90D1D854B68A27043724911270 (void);
// 0x0000009F System.Void UnityEngine.UI.FontData::set_maxSize(System.Int32)
extern void FontData_set_maxSize_mDD9FCD710B9E033877FC966E70A0DF83D79A334C (void);
// 0x000000A0 UnityEngine.TextAnchor UnityEngine.UI.FontData::get_alignment()
extern void FontData_get_alignment_m2492DD0F8619041BD0426388DFFE2DA4634DF095 (void);
// 0x000000A1 System.Void UnityEngine.UI.FontData::set_alignment(UnityEngine.TextAnchor)
extern void FontData_set_alignment_m69E5F6567789E0623536766BADD833481D8D95A5 (void);
// 0x000000A2 System.Boolean UnityEngine.UI.FontData::get_alignByGeometry()
extern void FontData_get_alignByGeometry_m2283F19F108FF389FC586488AB28FFEC2A5422A7 (void);
// 0x000000A3 System.Void UnityEngine.UI.FontData::set_alignByGeometry(System.Boolean)
extern void FontData_set_alignByGeometry_m4A0066CFEAAE077592A22AAB95584B2ED416E139 (void);
// 0x000000A4 System.Boolean UnityEngine.UI.FontData::get_richText()
extern void FontData_get_richText_m42B50EC00F120906CE16259A13C5C37392B7E525 (void);
// 0x000000A5 System.Void UnityEngine.UI.FontData::set_richText(System.Boolean)
extern void FontData_set_richText_m2A9142EB34518A1516B6DD0A02263B6AA4FAAA8A (void);
// 0x000000A6 UnityEngine.HorizontalWrapMode UnityEngine.UI.FontData::get_horizontalOverflow()
extern void FontData_get_horizontalOverflow_mD9704C9760A72DF3123CD12CF2C801424B43F9B8 (void);
// 0x000000A7 System.Void UnityEngine.UI.FontData::set_horizontalOverflow(UnityEngine.HorizontalWrapMode)
extern void FontData_set_horizontalOverflow_m36E9099214AECDBA10782F2AD0D53FB0C564A2BF (void);
// 0x000000A8 UnityEngine.VerticalWrapMode UnityEngine.UI.FontData::get_verticalOverflow()
extern void FontData_get_verticalOverflow_m42B923B1137DAEA0D1846C81B659284A5B93D2F0 (void);
// 0x000000A9 System.Void UnityEngine.UI.FontData::set_verticalOverflow(UnityEngine.VerticalWrapMode)
extern void FontData_set_verticalOverflow_m0CADC4D430AF3B97EC6AB67E307B33416F73ACA2 (void);
// 0x000000AA System.Single UnityEngine.UI.FontData::get_lineSpacing()
extern void FontData_get_lineSpacing_m7E48A8B51A6E164736303C82428B1E09541BC259 (void);
// 0x000000AB System.Void UnityEngine.UI.FontData::set_lineSpacing(System.Single)
extern void FontData_set_lineSpacing_m4E5D389BD1B2AC5EE9819D016D348E9E86354418 (void);
// 0x000000AC System.Void UnityEngine.UI.FontData::UnityEngine.ISerializationCallbackReceiver.OnBeforeSerialize()
extern void FontData_UnityEngine_ISerializationCallbackReceiver_OnBeforeSerialize_mDC010D7E8B0760CE0609D448CB39CA0837A23CEE (void);
// 0x000000AD System.Void UnityEngine.UI.FontData::UnityEngine.ISerializationCallbackReceiver.OnAfterDeserialize()
extern void FontData_UnityEngine_ISerializationCallbackReceiver_OnAfterDeserialize_m4963180F7FBB1126FAA1FDE6DAD964BF3EA6EC92 (void);
// 0x000000AE System.Void UnityEngine.UI.FontData::.ctor()
extern void FontData__ctor_mD10DB1E862954A5B86378363336E6ED223EB167E (void);
// 0x000000AF System.Void UnityEngine.UI.FontUpdateTracker::TrackText(UnityEngine.UI.Text)
extern void FontUpdateTracker_TrackText_mD4637B32DDF98DBC4EB12276CF3F1F123D2E8DE1 (void);
// 0x000000B0 System.Void UnityEngine.UI.FontUpdateTracker::RebuildForFont(UnityEngine.Font)
extern void FontUpdateTracker_RebuildForFont_m50C112881473597E323D64BD8501BF2E2BCB7C42 (void);
// 0x000000B1 System.Void UnityEngine.UI.FontUpdateTracker::UntrackText(UnityEngine.UI.Text)
extern void FontUpdateTracker_UntrackText_m1AF4E3F1C4FB59FFB0CA434696983DFDD4B30C63 (void);
// 0x000000B2 System.Void UnityEngine.UI.FontUpdateTracker::.cctor()
extern void FontUpdateTracker__cctor_m574706565D0BB0A40976BDA6C673F1FC65E10361 (void);
// 0x000000B3 UnityEngine.Material UnityEngine.UI.Graphic::get_defaultGraphicMaterial()
extern void Graphic_get_defaultGraphicMaterial_m4CE20290CB9C10C4761280434B5C0DD703FAF5E9 (void);
// 0x000000B4 UnityEngine.Color UnityEngine.UI.Graphic::get_color()
extern void Graphic_get_color_m41096F123C41440AEBA4DFA9895C200D6A57E3BB (void);
// 0x000000B5 System.Void UnityEngine.UI.Graphic::set_color(UnityEngine.Color)
extern void Graphic_set_color_mFCFCE816B75EA90B65322CC8336A7E9B87ABB1DD (void);
// 0x000000B6 System.Boolean UnityEngine.UI.Graphic::get_raycastTarget()
extern void Graphic_get_raycastTarget_mB1DAE6E1CC56FF60FDB89F13380EBA423D89C0AC (void);
// 0x000000B7 System.Void UnityEngine.UI.Graphic::set_raycastTarget(System.Boolean)
extern void Graphic_set_raycastTarget_mF6ED840EE6143939BBD9D27A91E500F0088A9F0C (void);
// 0x000000B8 System.Boolean UnityEngine.UI.Graphic::get_useLegacyMeshGeneration()
extern void Graphic_get_useLegacyMeshGeneration_mA066E73CC94E4D2821CD3B75CCF6D1CDC9A16330 (void);
// 0x000000B9 System.Void UnityEngine.UI.Graphic::set_useLegacyMeshGeneration(System.Boolean)
extern void Graphic_set_useLegacyMeshGeneration_m1281A98F40D15A81E9F13E761A25971D26E22485 (void);
// 0x000000BA System.Void UnityEngine.UI.Graphic::.ctor()
extern void Graphic__ctor_mFF2C899E09B2A87349DE0CB30ED40E024F1BAC61 (void);
// 0x000000BB System.Void UnityEngine.UI.Graphic::SetAllDirty()
extern void Graphic_SetAllDirty_mEE96FA6CE5AE7BE672D31FF5B9453520203920C7 (void);
// 0x000000BC System.Void UnityEngine.UI.Graphic::SetLayoutDirty()
extern void Graphic_SetLayoutDirty_m718BE45BCBB1F1553737E4DC264C46574432318A (void);
// 0x000000BD System.Void UnityEngine.UI.Graphic::SetVerticesDirty()
extern void Graphic_SetVerticesDirty_m40D12C375CE57E385BB29A05AA545BA5D2756092 (void);
// 0x000000BE System.Void UnityEngine.UI.Graphic::SetMaterialDirty()
extern void Graphic_SetMaterialDirty_mF3CFAA798081BB0DE5BEF580DB9AFF3D133BF87D (void);
// 0x000000BF System.Void UnityEngine.UI.Graphic::OnRectTransformDimensionsChange()
extern void Graphic_OnRectTransformDimensionsChange_m791FEC0CE315489E5BAB77379905C60904CCEDF9 (void);
// 0x000000C0 System.Void UnityEngine.UI.Graphic::OnBeforeTransformParentChanged()
extern void Graphic_OnBeforeTransformParentChanged_mD8CCD355B472AADD4FC1482A16AC2C24D7E430FF (void);
// 0x000000C1 System.Void UnityEngine.UI.Graphic::OnTransformParentChanged()
extern void Graphic_OnTransformParentChanged_m5F233BA713EE94492742F8BA870B6146DD9E98EE (void);
// 0x000000C2 System.Int32 UnityEngine.UI.Graphic::get_depth()
extern void Graphic_get_depth_m0F71549881BC2F4D4A64E1502747F33ADAC38061 (void);
// 0x000000C3 UnityEngine.RectTransform UnityEngine.UI.Graphic::get_rectTransform()
extern void Graphic_get_rectTransform_m025371162D3A3FCD6D4692B43D0BD80602D0AFC4 (void);
// 0x000000C4 UnityEngine.Canvas UnityEngine.UI.Graphic::get_canvas()
extern void Graphic_get_canvas_mE278CED637619008522EF95A32071868DD6F028C (void);
// 0x000000C5 System.Void UnityEngine.UI.Graphic::CacheCanvas()
extern void Graphic_CacheCanvas_m90ED23543C47D22791442F8A0B075BE96390BC8A (void);
// 0x000000C6 UnityEngine.CanvasRenderer UnityEngine.UI.Graphic::get_canvasRenderer()
extern void Graphic_get_canvasRenderer_mB3E532BE19116A3F0D6ADC1CD29D242428EAE8AA (void);
// 0x000000C7 UnityEngine.Material UnityEngine.UI.Graphic::get_defaultMaterial()
extern void Graphic_get_defaultMaterial_m0A1AF379749391DF306119369BC47E422B7E5AA8 (void);
// 0x000000C8 UnityEngine.Material UnityEngine.UI.Graphic::get_material()
extern void Graphic_get_material_m009A329611244894C6F51FA7D72E7945074B1F66 (void);
// 0x000000C9 System.Void UnityEngine.UI.Graphic::set_material(UnityEngine.Material)
extern void Graphic_set_material_m20F9693B0716F3C6277FB5ECC4AF01992BB17508 (void);
// 0x000000CA UnityEngine.Material UnityEngine.UI.Graphic::get_materialForRendering()
extern void Graphic_get_materialForRendering_m0FE5B8462BCE184C19D7C7991AB00733E499B168 (void);
// 0x000000CB UnityEngine.Texture UnityEngine.UI.Graphic::get_mainTexture()
extern void Graphic_get_mainTexture_m8ADD95545D4FAB8D218C028196DCB9758C47B3E5 (void);
// 0x000000CC System.Void UnityEngine.UI.Graphic::OnEnable()
extern void Graphic_OnEnable_m543DA5728144CAA130ADF9B8766E047A8CD222A2 (void);
// 0x000000CD System.Void UnityEngine.UI.Graphic::OnDisable()
extern void Graphic_OnDisable_m2F04072EC06F71B669B0539C4D0351A3C6D5EBC9 (void);
// 0x000000CE System.Void UnityEngine.UI.Graphic::OnDestroy()
extern void Graphic_OnDestroy_mB0F9B2DF45C43FFE1C1E487E4D4AF219FB153E15 (void);
// 0x000000CF System.Void UnityEngine.UI.Graphic::OnCanvasHierarchyChanged()
extern void Graphic_OnCanvasHierarchyChanged_mEFE8337B5C2A02BA5391CDC62E16873A7A1B17A4 (void);
// 0x000000D0 System.Void UnityEngine.UI.Graphic::OnCullingChanged()
extern void Graphic_OnCullingChanged_m1E3F10422AA9E264DC409F263962853FBEFD120A (void);
// 0x000000D1 System.Void UnityEngine.UI.Graphic::Rebuild(UnityEngine.UI.CanvasUpdate)
extern void Graphic_Rebuild_m43361D85EF8407D841CF93B7A3B9BA3FAD2999D0 (void);
// 0x000000D2 System.Void UnityEngine.UI.Graphic::LayoutComplete()
extern void Graphic_LayoutComplete_m59965D03F9D848264D99053CC756771EF2861FDC (void);
// 0x000000D3 System.Void UnityEngine.UI.Graphic::GraphicUpdateComplete()
extern void Graphic_GraphicUpdateComplete_m3E3BB39CF9720E59C7CB2378942976A2355EC7B0 (void);
// 0x000000D4 System.Void UnityEngine.UI.Graphic::UpdateMaterial()
extern void Graphic_UpdateMaterial_m16534E5799F16708458941FC6498B73F097A2EE0 (void);
// 0x000000D5 System.Void UnityEngine.UI.Graphic::UpdateGeometry()
extern void Graphic_UpdateGeometry_mA96921531C4B1F1ECE14D3AEF696B6CE186A262E (void);
// 0x000000D6 System.Void UnityEngine.UI.Graphic::DoMeshGeneration()
extern void Graphic_DoMeshGeneration_m78C460A0D1FB69DECE0453DAEEF647493A81B4DC (void);
// 0x000000D7 System.Void UnityEngine.UI.Graphic::DoLegacyMeshGeneration()
extern void Graphic_DoLegacyMeshGeneration_m463048B9E5C90A49140769F5E9B698E056575D14 (void);
// 0x000000D8 UnityEngine.Mesh UnityEngine.UI.Graphic::get_workerMesh()
extern void Graphic_get_workerMesh_m44288E0C1A3F7208C2F0C845C66D97CC243DA8F3 (void);
// 0x000000D9 System.Void UnityEngine.UI.Graphic::OnFillVBO(System.Collections.Generic.List`1<UnityEngine.UIVertex>)
extern void Graphic_OnFillVBO_m02BB5C8EBFECEDF310C8D64BF3631C1FAD3B1741 (void);
// 0x000000DA System.Void UnityEngine.UI.Graphic::OnPopulateMesh(UnityEngine.Mesh)
extern void Graphic_OnPopulateMesh_m948CA3ACE51F62248FE46ED5A02860CF0F88F1B3 (void);
// 0x000000DB System.Void UnityEngine.UI.Graphic::OnPopulateMesh(UnityEngine.UI.VertexHelper)
extern void Graphic_OnPopulateMesh_mFEDD5EDAB64FF7F306FB1CBFDCA90C66C2AC3027 (void);
// 0x000000DC System.Void UnityEngine.UI.Graphic::OnDidApplyAnimationProperties()
extern void Graphic_OnDidApplyAnimationProperties_m9517A75CB3E3F34476E789D596D8876493DE63E0 (void);
// 0x000000DD System.Void UnityEngine.UI.Graphic::SetNativeSize()
extern void Graphic_SetNativeSize_mEAC831D42859BDE3D7110393268DFDA5E3EB7FC8 (void);
// 0x000000DE System.Boolean UnityEngine.UI.Graphic::Raycast(UnityEngine.Vector2,UnityEngine.Camera)
extern void Graphic_Raycast_m3FAF25FAD88AA922B0C0203EB93A29C317F6FA5D (void);
// 0x000000DF UnityEngine.Vector2 UnityEngine.UI.Graphic::PixelAdjustPoint(UnityEngine.Vector2)
extern void Graphic_PixelAdjustPoint_m6A06D04F7D6B6D946407ECBD984AB2E9B2EF2DCF (void);
// 0x000000E0 UnityEngine.Rect UnityEngine.UI.Graphic::GetPixelAdjustedRect()
extern void Graphic_GetPixelAdjustedRect_m324344D38946D6F976CD487B493B8D9787DE891B (void);
// 0x000000E1 System.Void UnityEngine.UI.Graphic::CrossFadeColor(UnityEngine.Color,System.Single,System.Boolean,System.Boolean)
extern void Graphic_CrossFadeColor_mA523A0BBF67D56A68EBF66D11ED9E4A4656E8E6A (void);
// 0x000000E2 System.Void UnityEngine.UI.Graphic::CrossFadeColor(UnityEngine.Color,System.Single,System.Boolean,System.Boolean,System.Boolean)
extern void Graphic_CrossFadeColor_mAF4F98CBBFE98F68194F613CA81D96D70BEE2130 (void);
// 0x000000E3 UnityEngine.Color UnityEngine.UI.Graphic::CreateColorFromAlpha(System.Single)
extern void Graphic_CreateColorFromAlpha_mE614B0D96600F8AD82ABF5E7E223FC567D5A64CF (void);
// 0x000000E4 System.Void UnityEngine.UI.Graphic::CrossFadeAlpha(System.Single,System.Single,System.Boolean)
extern void Graphic_CrossFadeAlpha_m840C0BA8E42721135A79AEB4CDCE57E820A157F8 (void);
// 0x000000E5 System.Void UnityEngine.UI.Graphic::RegisterDirtyLayoutCallback(UnityEngine.Events.UnityAction)
extern void Graphic_RegisterDirtyLayoutCallback_m11140B9203E6D66297136F496425CD8D9DDAC35A (void);
// 0x000000E6 System.Void UnityEngine.UI.Graphic::UnregisterDirtyLayoutCallback(UnityEngine.Events.UnityAction)
extern void Graphic_UnregisterDirtyLayoutCallback_m4BF876332C14A07BB5ADFB8466153B2F7333AC71 (void);
// 0x000000E7 System.Void UnityEngine.UI.Graphic::RegisterDirtyVerticesCallback(UnityEngine.Events.UnityAction)
extern void Graphic_RegisterDirtyVerticesCallback_m8727CA44030990DDC04C7D0B15E42EE855D6E04A (void);
// 0x000000E8 System.Void UnityEngine.UI.Graphic::UnregisterDirtyVerticesCallback(UnityEngine.Events.UnityAction)
extern void Graphic_UnregisterDirtyVerticesCallback_mD988A2D705D5BC5CF07D48FA6ACEDD62B0C6D806 (void);
// 0x000000E9 System.Void UnityEngine.UI.Graphic::RegisterDirtyMaterialCallback(UnityEngine.Events.UnityAction)
extern void Graphic_RegisterDirtyMaterialCallback_mFA087FA23F3FD8EBDC56B9F43B677D0D22E5A10D (void);
// 0x000000EA System.Void UnityEngine.UI.Graphic::UnregisterDirtyMaterialCallback(UnityEngine.Events.UnityAction)
extern void Graphic_UnregisterDirtyMaterialCallback_mB3C2D969D23C29E3CF1E3F26A7A0DE43B5402CFB (void);
// 0x000000EB System.Void UnityEngine.UI.Graphic::.cctor()
extern void Graphic__cctor_mBCF4F5AE23900A0133EA8C4F3ADC3B44DD518478 (void);
// 0x000000EC UnityEngine.Transform UnityEngine.UI.Graphic::UnityEngine.UI.ICanvasElement.get_transform()
extern void Graphic_UnityEngine_UI_ICanvasElement_get_transform_mCCB04E0F0F285EA97EDF6D033919593677F6A0DD (void);
// 0x000000ED System.Int32 UnityEngine.UI.GraphicRaycaster::get_sortOrderPriority()
extern void GraphicRaycaster_get_sortOrderPriority_m709D3A9421D94A92300FF2CB8BE1FC105CE36C27 (void);
// 0x000000EE System.Int32 UnityEngine.UI.GraphicRaycaster::get_renderOrderPriority()
extern void GraphicRaycaster_get_renderOrderPriority_m12D14281F1C24C62430F0197209048C88C788833 (void);
// 0x000000EF System.Boolean UnityEngine.UI.GraphicRaycaster::get_ignoreReversedGraphics()
extern void GraphicRaycaster_get_ignoreReversedGraphics_mA651ACD4D10ABF6814CA86388CFBAB53E08752C1 (void);
// 0x000000F0 System.Void UnityEngine.UI.GraphicRaycaster::set_ignoreReversedGraphics(System.Boolean)
extern void GraphicRaycaster_set_ignoreReversedGraphics_m30ED60312A83BAF135DB8698A66A282B86E7714C (void);
// 0x000000F1 UnityEngine.UI.GraphicRaycaster/BlockingObjects UnityEngine.UI.GraphicRaycaster::get_blockingObjects()
extern void GraphicRaycaster_get_blockingObjects_m65760F738BEBB63000DD47E0E5E1FF8BA0AE49AF (void);
// 0x000000F2 System.Void UnityEngine.UI.GraphicRaycaster::set_blockingObjects(UnityEngine.UI.GraphicRaycaster/BlockingObjects)
extern void GraphicRaycaster_set_blockingObjects_mA8A05772456F3C6D111D13F3F928B36515D76669 (void);
// 0x000000F3 System.Void UnityEngine.UI.GraphicRaycaster::.ctor()
extern void GraphicRaycaster__ctor_mEF612B2FC80F5DB5AE8EEA04173D4E16CA17FF7B (void);
// 0x000000F4 UnityEngine.Canvas UnityEngine.UI.GraphicRaycaster::get_canvas()
extern void GraphicRaycaster_get_canvas_m74BF579BA6B90DA2BB40CC35A4593891751D5CCA (void);
// 0x000000F5 System.Void UnityEngine.UI.GraphicRaycaster::Raycast(UnityEngine.EventSystems.PointerEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void GraphicRaycaster_Raycast_m84D9E6E7312B2D18DF42C1C32F8D286C478981B6 (void);
// 0x000000F6 UnityEngine.Camera UnityEngine.UI.GraphicRaycaster::get_eventCamera()
extern void GraphicRaycaster_get_eventCamera_m9A3A721CBF84A96629E4BC1733BBB6A45FF9059D (void);
// 0x000000F7 System.Void UnityEngine.UI.GraphicRaycaster::Raycast(UnityEngine.Canvas,UnityEngine.Camera,UnityEngine.Vector2,System.Collections.Generic.IList`1<UnityEngine.UI.Graphic>,System.Collections.Generic.List`1<UnityEngine.UI.Graphic>)
extern void GraphicRaycaster_Raycast_mB609C88B0463F4D9AEDF92A22699A2F0442C6903 (void);
// 0x000000F8 System.Void UnityEngine.UI.GraphicRaycaster::.cctor()
extern void GraphicRaycaster__cctor_m70E9DDE730788223448287D773BBA2A0CC65CD64 (void);
// 0x000000F9 System.Void UnityEngine.UI.GraphicRegistry::.ctor()
extern void GraphicRegistry__ctor_m1D7A55FF980852A6DF114132EAA37534B8E97BF2 (void);
// 0x000000FA UnityEngine.UI.GraphicRegistry UnityEngine.UI.GraphicRegistry::get_instance()
extern void GraphicRegistry_get_instance_mC44355C0B339CE448FE227149CEE9E1469DEA198 (void);
// 0x000000FB System.Void UnityEngine.UI.GraphicRegistry::RegisterGraphicForCanvas(UnityEngine.Canvas,UnityEngine.UI.Graphic)
extern void GraphicRegistry_RegisterGraphicForCanvas_mD3BF9B48740240B443D67BB16938AEFF50FD3D70 (void);
// 0x000000FC System.Void UnityEngine.UI.GraphicRegistry::UnregisterGraphicForCanvas(UnityEngine.Canvas,UnityEngine.UI.Graphic)
extern void GraphicRegistry_UnregisterGraphicForCanvas_m4123DD7960466B17764D322CA564DDB05F1A1005 (void);
// 0x000000FD System.Collections.Generic.IList`1<UnityEngine.UI.Graphic> UnityEngine.UI.GraphicRegistry::GetGraphicsForCanvas(UnityEngine.Canvas)
extern void GraphicRegistry_GetGraphicsForCanvas_m3F2DD225EAE745C24BD9505AB5B0BA662C1FC72D (void);
// 0x000000FE System.Void UnityEngine.UI.GraphicRegistry::.cctor()
extern void GraphicRegistry__cctor_m8BBF04829878A32D2DC3B4E4488455728A531F6D (void);
// 0x000000FF System.Void UnityEngine.UI.IGraphicEnabledDisabled::OnSiblingGraphicEnabledDisabled()
// 0x00000100 System.Boolean UnityEngine.UI.IMask::Enabled()
// 0x00000101 UnityEngine.RectTransform UnityEngine.UI.IMask::get_rectTransform()
// 0x00000102 System.Void UnityEngine.UI.IMaskable::RecalculateMasking()
// 0x00000103 UnityEngine.Sprite UnityEngine.UI.Image::get_sprite()
extern void Image_get_sprite_m642D753672A8CBCEB67950914B44EF34C62DD137 (void);
// 0x00000104 System.Void UnityEngine.UI.Image::set_sprite(UnityEngine.Sprite)
extern void Image_set_sprite_m0D1DBEFD8E361B3967964C71F93EF47E2AC53A13 (void);
// 0x00000105 System.Void UnityEngine.UI.Image::DisableSpriteOptimizations()
extern void Image_DisableSpriteOptimizations_mB0B9EF7868EF02231A2627B8A3C752ABECC4FFBC (void);
// 0x00000106 UnityEngine.Sprite UnityEngine.UI.Image::get_overrideSprite()
extern void Image_get_overrideSprite_mE32E3D384CA6220B81702E9E3051FF83C4232FF0 (void);
// 0x00000107 System.Void UnityEngine.UI.Image::set_overrideSprite(UnityEngine.Sprite)
extern void Image_set_overrideSprite_m3801998A40D32BC10393531714384D736D9F604B (void);
// 0x00000108 UnityEngine.Sprite UnityEngine.UI.Image::get_activeSprite()
extern void Image_get_activeSprite_mF8F075992BC21B86E47F76D5F8018524DA045A88 (void);
// 0x00000109 UnityEngine.UI.Image/Type UnityEngine.UI.Image::get_type()
extern void Image_get_type_mBF4695569A2C6FEBCDE60AB80A386F39D5708D6A (void);
// 0x0000010A System.Void UnityEngine.UI.Image::set_type(UnityEngine.UI.Image/Type)
extern void Image_set_type_mCA2BF9E071A77EE7D76C7EB343BE5ABEF9E7A199 (void);
// 0x0000010B System.Boolean UnityEngine.UI.Image::get_preserveAspect()
extern void Image_get_preserveAspect_mF5FDA8E207A0EA3BA3614D891DA58FB42D8F0665 (void);
// 0x0000010C System.Void UnityEngine.UI.Image::set_preserveAspect(System.Boolean)
extern void Image_set_preserveAspect_m69E602AC28CAD513726DF209DBAB355C85F6AB51 (void);
// 0x0000010D System.Boolean UnityEngine.UI.Image::get_fillCenter()
extern void Image_get_fillCenter_mC1C3D94313AEB5CDDA8AFBA05E5064614776F6A5 (void);
// 0x0000010E System.Void UnityEngine.UI.Image::set_fillCenter(System.Boolean)
extern void Image_set_fillCenter_m0A53CDA22B0CD9DC793B61BE2AAA8FDD77817777 (void);
// 0x0000010F UnityEngine.UI.Image/FillMethod UnityEngine.UI.Image::get_fillMethod()
extern void Image_get_fillMethod_m0F319641FE800193CB9FC939F4A4767D230D23F3 (void);
// 0x00000110 System.Void UnityEngine.UI.Image::set_fillMethod(UnityEngine.UI.Image/FillMethod)
extern void Image_set_fillMethod_mA33A12A016BAF78C4FA65DE06591E81A139BFAEE (void);
// 0x00000111 System.Single UnityEngine.UI.Image::get_fillAmount()
extern void Image_get_fillAmount_m52716D803065CDAFBCF2CE226868D71A58DE4792 (void);
// 0x00000112 System.Void UnityEngine.UI.Image::set_fillAmount(System.Single)
extern void Image_set_fillAmount_m3939CACF382B30A0353F300E2AE2D3823E1D42F4 (void);
// 0x00000113 System.Boolean UnityEngine.UI.Image::get_fillClockwise()
extern void Image_get_fillClockwise_m95EDEEA7817F4E6AAD688DD73F2CBDD42EC3AE67 (void);
// 0x00000114 System.Void UnityEngine.UI.Image::set_fillClockwise(System.Boolean)
extern void Image_set_fillClockwise_mFECFB87C66A74A11BC65A67F5E461E3ECA89D228 (void);
// 0x00000115 System.Int32 UnityEngine.UI.Image::get_fillOrigin()
extern void Image_get_fillOrigin_mD984C37AA02B39C490E94C80FC3AEC1329F2E581 (void);
// 0x00000116 System.Void UnityEngine.UI.Image::set_fillOrigin(System.Int32)
extern void Image_set_fillOrigin_m998854DF1C46B945BF46B836C1B57EBD81670D37 (void);
// 0x00000117 System.Single UnityEngine.UI.Image::get_eventAlphaThreshold()
extern void Image_get_eventAlphaThreshold_mF7B2B10F6BED44967456285F6E948C7446E6F0CB (void);
// 0x00000118 System.Void UnityEngine.UI.Image::set_eventAlphaThreshold(System.Single)
extern void Image_set_eventAlphaThreshold_mC199B8715309D0696A43D46337D8FE21B7417AC2 (void);
// 0x00000119 System.Single UnityEngine.UI.Image::get_alphaHitTestMinimumThreshold()
extern void Image_get_alphaHitTestMinimumThreshold_m46A783B6DCE2275998D39EDD95D6330AB577E153 (void);
// 0x0000011A System.Void UnityEngine.UI.Image::set_alphaHitTestMinimumThreshold(System.Single)
extern void Image_set_alphaHitTestMinimumThreshold_m896CA8778D60EC6265F0B0A8F638D807E6A6E629 (void);
// 0x0000011B System.Boolean UnityEngine.UI.Image::get_useSpriteMesh()
extern void Image_get_useSpriteMesh_mFDD492A5BCA3BC432A2C6B376A136A8F13EDD392 (void);
// 0x0000011C System.Void UnityEngine.UI.Image::set_useSpriteMesh(System.Boolean)
extern void Image_set_useSpriteMesh_m4AD6400C198048A34495BF659E05D2534884316B (void);
// 0x0000011D System.Void UnityEngine.UI.Image::.ctor()
extern void Image__ctor_m89E0D103F4CA0BBBC035607123F6E7C329204765 (void);
// 0x0000011E UnityEngine.Material UnityEngine.UI.Image::get_defaultETC1GraphicMaterial()
extern void Image_get_defaultETC1GraphicMaterial_m471CA72CC6141A7F71D521C366E04D728F0F66A0 (void);
// 0x0000011F UnityEngine.Texture UnityEngine.UI.Image::get_mainTexture()
extern void Image_get_mainTexture_mB257690C040998ECFC1BE091374B54B181823D27 (void);
// 0x00000120 System.Boolean UnityEngine.UI.Image::get_hasBorder()
extern void Image_get_hasBorder_m7C05F990262DFB3E3FA9930DD0C9ADE1A9ADD55A (void);
// 0x00000121 System.Single UnityEngine.UI.Image::get_pixelsPerUnitMultiplier()
extern void Image_get_pixelsPerUnitMultiplier_mEC77742FC868A9AF8D97062C2AF22CC67301A161 (void);
// 0x00000122 System.Void UnityEngine.UI.Image::set_pixelsPerUnitMultiplier(System.Single)
extern void Image_set_pixelsPerUnitMultiplier_mA5DDCE0047AF70E5B05C12B85A97C892E917AA4A (void);
// 0x00000123 System.Single UnityEngine.UI.Image::get_pixelsPerUnit()
extern void Image_get_pixelsPerUnit_mFEB9AE2275AA3C78B1B378E1D5BB3DAA3FEA468F (void);
// 0x00000124 System.Single UnityEngine.UI.Image::get_multipliedPixelsPerUnit()
extern void Image_get_multipliedPixelsPerUnit_m461D324E57EA6D27E040D604CC5E4B7E8C1BD6F6 (void);
// 0x00000125 UnityEngine.Material UnityEngine.UI.Image::get_material()
extern void Image_get_material_m75690B58C80538290BEECC5E1D145FB19158ACCA (void);
// 0x00000126 System.Void UnityEngine.UI.Image::set_material(UnityEngine.Material)
extern void Image_set_material_m77700AC8865555E51919FD83103AE7031EB2A099 (void);
// 0x00000127 System.Void UnityEngine.UI.Image::OnBeforeSerialize()
extern void Image_OnBeforeSerialize_m785C27A8280F9811921AD8562456E04704A31685 (void);
// 0x00000128 System.Void UnityEngine.UI.Image::OnAfterDeserialize()
extern void Image_OnAfterDeserialize_m97D51356CC8BB6709D54132B514D111382A03256 (void);
// 0x00000129 System.Void UnityEngine.UI.Image::PreserveSpriteAspectRatio(UnityEngine.Rect&,UnityEngine.Vector2)
extern void Image_PreserveSpriteAspectRatio_m867C0743E6073345231FC0CD83DB3D63EAE28E4B (void);
// 0x0000012A UnityEngine.Vector4 UnityEngine.UI.Image::GetDrawingDimensions(System.Boolean)
extern void Image_GetDrawingDimensions_mCE6C336D88D6E49D8052F79B9126D0FB6AF4452C (void);
// 0x0000012B System.Void UnityEngine.UI.Image::SetNativeSize()
extern void Image_SetNativeSize_mBDA1525980ABBB4BB36C0A24E507D099CEFD86D8 (void);
// 0x0000012C System.Void UnityEngine.UI.Image::OnPopulateMesh(UnityEngine.UI.VertexHelper)
extern void Image_OnPopulateMesh_m104866C152A6FC9048284507F0EAD18E15884A0A (void);
// 0x0000012D System.Void UnityEngine.UI.Image::TrackSprite()
extern void Image_TrackSprite_mB3639B263ED7B7E321ED6C2B92D080E8AF5291AA (void);
// 0x0000012E System.Void UnityEngine.UI.Image::OnEnable()
extern void Image_OnEnable_m9D7FE5D1A92A2297C23B9C2F64BD1A149E04BA0A (void);
// 0x0000012F System.Void UnityEngine.UI.Image::OnDisable()
extern void Image_OnDisable_m1C3110B08DE03A4B36B98C542F3791ABBFB4ADA4 (void);
// 0x00000130 System.Void UnityEngine.UI.Image::UpdateMaterial()
extern void Image_UpdateMaterial_mC3DCDCF173BCDDB05C20AFB60E06782B6A8768DE (void);
// 0x00000131 System.Void UnityEngine.UI.Image::OnCanvasHierarchyChanged()
extern void Image_OnCanvasHierarchyChanged_m83917F8982210F0AB2891662F97E516C818295BE (void);
// 0x00000132 System.Void UnityEngine.UI.Image::GenerateSimpleSprite(UnityEngine.UI.VertexHelper,System.Boolean)
extern void Image_GenerateSimpleSprite_m46170848CF38F077E68B011D15EB12F52B92B949 (void);
// 0x00000133 System.Void UnityEngine.UI.Image::GenerateSprite(UnityEngine.UI.VertexHelper,System.Boolean)
extern void Image_GenerateSprite_m033E01EDC91DE1DED74202F91E6F91A408955DDE (void);
// 0x00000134 System.Void UnityEngine.UI.Image::GenerateSlicedSprite(UnityEngine.UI.VertexHelper)
extern void Image_GenerateSlicedSprite_mBF002A4287C80541C8C806C74BA171DB8DFBAB8F (void);
// 0x00000135 System.Void UnityEngine.UI.Image::GenerateTiledSprite(UnityEngine.UI.VertexHelper)
extern void Image_GenerateTiledSprite_mEA5DDDFA3314A70F65EC73CC79D3011AF2EC9E63 (void);
// 0x00000136 System.Void UnityEngine.UI.Image::AddQuad(UnityEngine.UI.VertexHelper,UnityEngine.Vector3[],UnityEngine.Color32,UnityEngine.Vector3[])
extern void Image_AddQuad_mB70FE4783CDC72A84E64FEF905B0F7AC9E910AE8 (void);
// 0x00000137 System.Void UnityEngine.UI.Image::AddQuad(UnityEngine.UI.VertexHelper,UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.Color32,UnityEngine.Vector2,UnityEngine.Vector2)
extern void Image_AddQuad_m0A71218655EC3BA6C226556D470881A9CE46906F (void);
// 0x00000138 UnityEngine.Vector4 UnityEngine.UI.Image::GetAdjustedBorders(UnityEngine.Vector4,UnityEngine.Rect)
extern void Image_GetAdjustedBorders_mCF8A75527B652B1EE38AA901633CB4ECAD52AB89 (void);
// 0x00000139 System.Void UnityEngine.UI.Image::GenerateFilledSprite(UnityEngine.UI.VertexHelper,System.Boolean)
extern void Image_GenerateFilledSprite_m01DFCEE99311E089187D34053A2374FF8002EBAA (void);
// 0x0000013A System.Boolean UnityEngine.UI.Image::RadialCut(UnityEngine.Vector3[],UnityEngine.Vector3[],System.Single,System.Boolean,System.Int32)
extern void Image_RadialCut_m4E9900BA6EE4A9AA9B354697D77B2A662AEC23DF (void);
// 0x0000013B System.Void UnityEngine.UI.Image::RadialCut(UnityEngine.Vector3[],System.Single,System.Single,System.Boolean,System.Int32)
extern void Image_RadialCut_m9CCD0D83BADBD2AC4EF60952F4294E98FADAB8B2 (void);
// 0x0000013C System.Void UnityEngine.UI.Image::CalculateLayoutInputHorizontal()
extern void Image_CalculateLayoutInputHorizontal_m5232B7280E0A7DEE3BAF27C59053D65BE15BE0D2 (void);
// 0x0000013D System.Void UnityEngine.UI.Image::CalculateLayoutInputVertical()
extern void Image_CalculateLayoutInputVertical_m5158697A0915E9F3DCD7136565652B9357090B2D (void);
// 0x0000013E System.Single UnityEngine.UI.Image::get_minWidth()
extern void Image_get_minWidth_m626AD4C77AE11E5286F0B99EB54F3F0421472148 (void);
// 0x0000013F System.Single UnityEngine.UI.Image::get_preferredWidth()
extern void Image_get_preferredWidth_m26A0CCAD8AF401F83A2BC3343F70E5380F237FFD (void);
// 0x00000140 System.Single UnityEngine.UI.Image::get_flexibleWidth()
extern void Image_get_flexibleWidth_m65BC8846340179C353CF4D5ACFC33CEF96B8BF9B (void);
// 0x00000141 System.Single UnityEngine.UI.Image::get_minHeight()
extern void Image_get_minHeight_mF744D962891D563EEAA83C556A7F03E06C0F63F4 (void);
// 0x00000142 System.Single UnityEngine.UI.Image::get_preferredHeight()
extern void Image_get_preferredHeight_mE395F5CA183EE208F1A78C5BE5E84553B15A8E40 (void);
// 0x00000143 System.Single UnityEngine.UI.Image::get_flexibleHeight()
extern void Image_get_flexibleHeight_mFB51C992984741CDDC901DF8726B894E65BAE42C (void);
// 0x00000144 System.Int32 UnityEngine.UI.Image::get_layoutPriority()
extern void Image_get_layoutPriority_m93D32FC9B5713E5CB880807D122565D22B620C6E (void);
// 0x00000145 System.Boolean UnityEngine.UI.Image::IsRaycastLocationValid(UnityEngine.Vector2,UnityEngine.Camera)
extern void Image_IsRaycastLocationValid_m739ADDA1CDEF37EB21CDA648DDE30F87D39B235E (void);
// 0x00000146 UnityEngine.Vector2 UnityEngine.UI.Image::MapCoordinate(UnityEngine.Vector2,UnityEngine.Rect)
extern void Image_MapCoordinate_m90184DC8DE94E172E71287F95A400EE4C5EF464C (void);
// 0x00000147 System.Void UnityEngine.UI.Image::RebuildImage(UnityEngine.U2D.SpriteAtlas)
extern void Image_RebuildImage_m1A747F9521237EBC256F0B3831921844A57EB7C9 (void);
// 0x00000148 System.Void UnityEngine.UI.Image::TrackImage(UnityEngine.UI.Image)
extern void Image_TrackImage_m09253EA16561EB5DAA848F9E2F96FEC71300E85B (void);
// 0x00000149 System.Void UnityEngine.UI.Image::UnTrackImage(UnityEngine.UI.Image)
extern void Image_UnTrackImage_m0C8785427EE52C01A62F7DCBCAF8BC175423E21B (void);
// 0x0000014A System.Void UnityEngine.UI.Image::OnDidApplyAnimationProperties()
extern void Image_OnDidApplyAnimationProperties_m1CF377F062B5C36D1E4EEB18B7BE7D42F9653A15 (void);
// 0x0000014B System.Void UnityEngine.UI.Image::.cctor()
extern void Image__cctor_m4FB493FF96D111013AA8B8C1F0A61C7FC4BE3328 (void);
// 0x0000014C UnityEngine.EventSystems.BaseInput UnityEngine.UI.InputField::get_input()
extern void InputField_get_input_mAF4210F766099F23FA8695F12CA970CC8E5CA80A (void);
// 0x0000014D System.String UnityEngine.UI.InputField::get_compositionString()
extern void InputField_get_compositionString_m158BE146634913936807DB36538433F4B6F9E9E1 (void);
// 0x0000014E System.Void UnityEngine.UI.InputField::.ctor()
extern void InputField__ctor_m6FD452F23C09815941270A1145A3635720F74A81 (void);
// 0x0000014F UnityEngine.Mesh UnityEngine.UI.InputField::get_mesh()
extern void InputField_get_mesh_m6546FECF63F4A23B1A3C8B58B0BFE294106BAE7A (void);
// 0x00000150 UnityEngine.TextGenerator UnityEngine.UI.InputField::get_cachedInputTextGenerator()
extern void InputField_get_cachedInputTextGenerator_m6E2FFA43D0AE993D930B4763184F248AE1915CA0 (void);
// 0x00000151 System.Void UnityEngine.UI.InputField::set_shouldHideMobileInput(System.Boolean)
extern void InputField_set_shouldHideMobileInput_m0F1A7AB81C87ACEA5DD944C31B5FFFA17FBC0566 (void);
// 0x00000152 System.Boolean UnityEngine.UI.InputField::get_shouldHideMobileInput()
extern void InputField_get_shouldHideMobileInput_m4C519527445BF0BC3528E28ECC92353020569638 (void);
// 0x00000153 System.Void UnityEngine.UI.InputField::set_shouldActivateOnSelect(System.Boolean)
extern void InputField_set_shouldActivateOnSelect_mD3E4349843483230B1F2308A4B47402B36E8B489 (void);
// 0x00000154 System.Boolean UnityEngine.UI.InputField::get_shouldActivateOnSelect()
extern void InputField_get_shouldActivateOnSelect_m38CD67B376D9EE55E1448709C55FA6A915D55889 (void);
// 0x00000155 System.String UnityEngine.UI.InputField::get_text()
extern void InputField_get_text_mBF8B0DCF4E3CDBB06DA69715A7DD8F9E56775E79 (void);
// 0x00000156 System.Void UnityEngine.UI.InputField::set_text(System.String)
extern void InputField_set_text_m281F692E6AC99F9AE94EFE140B8AB2AAB5C4ED19 (void);
// 0x00000157 System.Void UnityEngine.UI.InputField::SetTextWithoutNotify(System.String)
extern void InputField_SetTextWithoutNotify_m383B2699A0A42D182441DB8B028129A901343C0E (void);
// 0x00000158 System.Void UnityEngine.UI.InputField::SetText(System.String,System.Boolean)
extern void InputField_SetText_mEF14F85B3A852C7BB42625B5982DB4BFEBAF313F (void);
// 0x00000159 System.Boolean UnityEngine.UI.InputField::get_isFocused()
extern void InputField_get_isFocused_m25CA31CA6CECDC64B52BB3AACC1B6A8A93A616A2 (void);
// 0x0000015A System.Single UnityEngine.UI.InputField::get_caretBlinkRate()
extern void InputField_get_caretBlinkRate_m56A493EBF4A015AC2CEDA650720ADB4FF2521511 (void);
// 0x0000015B System.Void UnityEngine.UI.InputField::set_caretBlinkRate(System.Single)
extern void InputField_set_caretBlinkRate_m4EDB44D8AEDA727A25FA6CC1C3DA45BB45A41933 (void);
// 0x0000015C System.Int32 UnityEngine.UI.InputField::get_caretWidth()
extern void InputField_get_caretWidth_m9D8E7C39BD3DF4F8BAB672500537A3BE99C3A6CC (void);
// 0x0000015D System.Void UnityEngine.UI.InputField::set_caretWidth(System.Int32)
extern void InputField_set_caretWidth_mF61CCF7F182E6DF6FA6F0353AE4EF3698A82AF97 (void);
// 0x0000015E UnityEngine.UI.Text UnityEngine.UI.InputField::get_textComponent()
extern void InputField_get_textComponent_mC1FC063C41D84947A3B0BE349C6E937EDF0EB19E (void);
// 0x0000015F System.Void UnityEngine.UI.InputField::set_textComponent(UnityEngine.UI.Text)
extern void InputField_set_textComponent_m11FA15B17BA3DB27324CE4040E063B7DAC091B07 (void);
// 0x00000160 UnityEngine.UI.Graphic UnityEngine.UI.InputField::get_placeholder()
extern void InputField_get_placeholder_mBDB090222F665AE8A1C96F1F375732346F177EEB (void);
// 0x00000161 System.Void UnityEngine.UI.InputField::set_placeholder(UnityEngine.UI.Graphic)
extern void InputField_set_placeholder_m0865B4D3D4ECD6FD461DAB885EB092EEB21A4043 (void);
// 0x00000162 UnityEngine.Color UnityEngine.UI.InputField::get_caretColor()
extern void InputField_get_caretColor_m9CC9FE92EE010A1F980A2838A41B4C081D2FDA3A (void);
// 0x00000163 System.Void UnityEngine.UI.InputField::set_caretColor(UnityEngine.Color)
extern void InputField_set_caretColor_m148EFE3197FB549ED9590E79857FA59A1745EDAC (void);
// 0x00000164 System.Boolean UnityEngine.UI.InputField::get_customCaretColor()
extern void InputField_get_customCaretColor_mA8F05610E0ED2EF183F5D3BFA85C2C6A5C18AC06 (void);
// 0x00000165 System.Void UnityEngine.UI.InputField::set_customCaretColor(System.Boolean)
extern void InputField_set_customCaretColor_m464BB3B1F60BE5921F4A7F332F56CC2B67BFBA39 (void);
// 0x00000166 UnityEngine.Color UnityEngine.UI.InputField::get_selectionColor()
extern void InputField_get_selectionColor_mA49DCB951B526D232C0E090783433304261D4D1C (void);
// 0x00000167 System.Void UnityEngine.UI.InputField::set_selectionColor(UnityEngine.Color)
extern void InputField_set_selectionColor_m518AC54CA807B49168B241A9C5AA631DECA66BEF (void);
// 0x00000168 UnityEngine.UI.InputField/SubmitEvent UnityEngine.UI.InputField::get_onEndEdit()
extern void InputField_get_onEndEdit_m912D9CA48D579EE1A68544EA58EF5EEB633148C1 (void);
// 0x00000169 System.Void UnityEngine.UI.InputField::set_onEndEdit(UnityEngine.UI.InputField/SubmitEvent)
extern void InputField_set_onEndEdit_m9319A04D9507BF95F126FBDC944EFBFD25437817 (void);
// 0x0000016A UnityEngine.UI.InputField/OnChangeEvent UnityEngine.UI.InputField::get_onValueChange()
extern void InputField_get_onValueChange_mC6364A9208DD2811E7DFF5F0A1225246A278BCD7 (void);
// 0x0000016B System.Void UnityEngine.UI.InputField::set_onValueChange(UnityEngine.UI.InputField/OnChangeEvent)
extern void InputField_set_onValueChange_m16DDA125D55D52930BEC5C48B510EA1DCB06D99A (void);
// 0x0000016C UnityEngine.UI.InputField/OnChangeEvent UnityEngine.UI.InputField::get_onValueChanged()
extern void InputField_get_onValueChanged_m1AE46D57FF8D96F53F2039722DE9CDDB6AB58CA1 (void);
// 0x0000016D System.Void UnityEngine.UI.InputField::set_onValueChanged(UnityEngine.UI.InputField/OnChangeEvent)
extern void InputField_set_onValueChanged_mCB16702D95434534F0E94F7FD7C6CB50A2CF1AAC (void);
// 0x0000016E UnityEngine.UI.InputField/OnValidateInput UnityEngine.UI.InputField::get_onValidateInput()
extern void InputField_get_onValidateInput_mCF04910E2F6920903CD095B86C1D61DA4C01B553 (void);
// 0x0000016F System.Void UnityEngine.UI.InputField::set_onValidateInput(UnityEngine.UI.InputField/OnValidateInput)
extern void InputField_set_onValidateInput_m5BEE0E501A9B7473CF12CDE4EFB3DB07D021E293 (void);
// 0x00000170 System.Int32 UnityEngine.UI.InputField::get_characterLimit()
extern void InputField_get_characterLimit_mCAD464954BEA8FFE1F325EB07145F0C0F685F327 (void);
// 0x00000171 System.Void UnityEngine.UI.InputField::set_characterLimit(System.Int32)
extern void InputField_set_characterLimit_mF4B5E0B2BFC530654453C0341CCDD708FEFC935C (void);
// 0x00000172 UnityEngine.UI.InputField/ContentType UnityEngine.UI.InputField::get_contentType()
extern void InputField_get_contentType_mBDEC121EFB7451BE3F56D8A2F68BF78FC28D2329 (void);
// 0x00000173 System.Void UnityEngine.UI.InputField::set_contentType(UnityEngine.UI.InputField/ContentType)
extern void InputField_set_contentType_mC4E201D9E627B8031D56F9161E3A3183240BA974 (void);
// 0x00000174 UnityEngine.UI.InputField/LineType UnityEngine.UI.InputField::get_lineType()
extern void InputField_get_lineType_mAFC713A8DC2FABB2FFC6902A767DAE2932A5BDBE (void);
// 0x00000175 System.Void UnityEngine.UI.InputField::set_lineType(UnityEngine.UI.InputField/LineType)
extern void InputField_set_lineType_m72D4588776FB00EE7A3CD409A9476A3DA335F69A (void);
// 0x00000176 UnityEngine.UI.InputField/InputType UnityEngine.UI.InputField::get_inputType()
extern void InputField_get_inputType_m1B9C2C98A32BBD27759C950DC4C65F0FD69329CF (void);
// 0x00000177 System.Void UnityEngine.UI.InputField::set_inputType(UnityEngine.UI.InputField/InputType)
extern void InputField_set_inputType_mB0E1EA230120261855A43AAB7677D7104B0C7FCD (void);
// 0x00000178 UnityEngine.TouchScreenKeyboard UnityEngine.UI.InputField::get_touchScreenKeyboard()
extern void InputField_get_touchScreenKeyboard_m6C45EACFFF50802976ADF0025CEAE8741153CB1E (void);
// 0x00000179 UnityEngine.TouchScreenKeyboardType UnityEngine.UI.InputField::get_keyboardType()
extern void InputField_get_keyboardType_m9837579BEE93CA6EEA8314AF9CE3074F39D8E661 (void);
// 0x0000017A System.Void UnityEngine.UI.InputField::set_keyboardType(UnityEngine.TouchScreenKeyboardType)
extern void InputField_set_keyboardType_m632644F9C8BA3E86134E9B438308F36706C4E13D (void);
// 0x0000017B UnityEngine.UI.InputField/CharacterValidation UnityEngine.UI.InputField::get_characterValidation()
extern void InputField_get_characterValidation_m3BA91CE0FC3845B40E1D43D6F0E36C5DB1D3EC29 (void);
// 0x0000017C System.Void UnityEngine.UI.InputField::set_characterValidation(UnityEngine.UI.InputField/CharacterValidation)
extern void InputField_set_characterValidation_m3190D57473E86E5303B7CDC4066156A35E5E4EB7 (void);
// 0x0000017D System.Boolean UnityEngine.UI.InputField::get_readOnly()
extern void InputField_get_readOnly_m270D135DF046240056F82A8B5FB33B88A1C75410 (void);
// 0x0000017E System.Void UnityEngine.UI.InputField::set_readOnly(System.Boolean)
extern void InputField_set_readOnly_m6C0CB487175DCD5A6D1FEFB0095FCE6AE81EF4A1 (void);
// 0x0000017F System.Boolean UnityEngine.UI.InputField::get_multiLine()
extern void InputField_get_multiLine_mBAA67A994CDFF54DDD2626911E1925EB696651F3 (void);
// 0x00000180 System.Char UnityEngine.UI.InputField::get_asteriskChar()
extern void InputField_get_asteriskChar_m121033347B2DEE7DDB48DB9BA0A8E0CDD4C063CB (void);
// 0x00000181 System.Void UnityEngine.UI.InputField::set_asteriskChar(System.Char)
extern void InputField_set_asteriskChar_mB506CCAFF03BC60DF6D977F6CFF4A8C49F36E643 (void);
// 0x00000182 System.Boolean UnityEngine.UI.InputField::get_wasCanceled()
extern void InputField_get_wasCanceled_m6BECF3C88C145F3E41A52F1D71DB73829C79F5DA (void);
// 0x00000183 System.Void UnityEngine.UI.InputField::ClampPos(System.Int32&)
extern void InputField_ClampPos_mA5284D511E01A281F0496B2E5501807E89095122 (void);
// 0x00000184 System.Int32 UnityEngine.UI.InputField::get_caretPositionInternal()
extern void InputField_get_caretPositionInternal_m1C8C179A08702D0100763BCBABCBD6C8657CF48C (void);
// 0x00000185 System.Void UnityEngine.UI.InputField::set_caretPositionInternal(System.Int32)
extern void InputField_set_caretPositionInternal_mF3AB830A2E57BD6C42D9F929A0022A08A19C2CBC (void);
// 0x00000186 System.Int32 UnityEngine.UI.InputField::get_caretSelectPositionInternal()
extern void InputField_get_caretSelectPositionInternal_m6C1C9309C63A54F0758E9E98874F506A000E836D (void);
// 0x00000187 System.Void UnityEngine.UI.InputField::set_caretSelectPositionInternal(System.Int32)
extern void InputField_set_caretSelectPositionInternal_mBA32741EB669F0A2442CD4D08769BC6A76B14A9C (void);
// 0x00000188 System.Boolean UnityEngine.UI.InputField::get_hasSelection()
extern void InputField_get_hasSelection_mDD4B79D003B25F135FCE39C1C616B931B376D512 (void);
// 0x00000189 System.Int32 UnityEngine.UI.InputField::get_caretPosition()
extern void InputField_get_caretPosition_m1C29C23140389DEC7F6F1E219CE0F05664F26F45 (void);
// 0x0000018A System.Void UnityEngine.UI.InputField::set_caretPosition(System.Int32)
extern void InputField_set_caretPosition_m9FA50128D39216F22600FAED4E524E2C11EA762C (void);
// 0x0000018B System.Int32 UnityEngine.UI.InputField::get_selectionAnchorPosition()
extern void InputField_get_selectionAnchorPosition_mDCDBF5541AF2070013C2AAC9C8EE9F71D7F646EA (void);
// 0x0000018C System.Void UnityEngine.UI.InputField::set_selectionAnchorPosition(System.Int32)
extern void InputField_set_selectionAnchorPosition_m4254083520C451CC3B47F4A378AB42E30EB35D44 (void);
// 0x0000018D System.Int32 UnityEngine.UI.InputField::get_selectionFocusPosition()
extern void InputField_get_selectionFocusPosition_m4DA6EE88607CA347897FC618404C516BBBF26F8F (void);
// 0x0000018E System.Void UnityEngine.UI.InputField::set_selectionFocusPosition(System.Int32)
extern void InputField_set_selectionFocusPosition_mB10332F1C25A0FBF55E5117311EA222341DA4226 (void);
// 0x0000018F System.Void UnityEngine.UI.InputField::OnEnable()
extern void InputField_OnEnable_m20C81684DD86C8AC2C9DFC484EED542348643953 (void);
// 0x00000190 System.Void UnityEngine.UI.InputField::OnDisable()
extern void InputField_OnDisable_m03FD432603A7B8BAEB1517C1CEF9463AC813B894 (void);
// 0x00000191 System.Collections.IEnumerator UnityEngine.UI.InputField::CaretBlink()
extern void InputField_CaretBlink_m1A5A634C9913890C778AAA97AEBDD94FB4AE2AD2 (void);
// 0x00000192 System.Void UnityEngine.UI.InputField::SetCaretVisible()
extern void InputField_SetCaretVisible_m5E833C2E576C37507EED1BB8E7277DBA7AC63F08 (void);
// 0x00000193 System.Void UnityEngine.UI.InputField::SetCaretActive()
extern void InputField_SetCaretActive_mB7D0B50A4C7EFEF79C1E42F2C4BFB151E004A2B4 (void);
// 0x00000194 System.Void UnityEngine.UI.InputField::UpdateCaretMaterial()
extern void InputField_UpdateCaretMaterial_mC952730C34A97B699C4ADF000D036DF093BC99B7 (void);
// 0x00000195 System.Void UnityEngine.UI.InputField::OnFocus()
extern void InputField_OnFocus_mE5526144A4E6817D74779CD9D127CCDBD3980CCE (void);
// 0x00000196 System.Void UnityEngine.UI.InputField::SelectAll()
extern void InputField_SelectAll_mC99C9736C43FE76D6BDECB08EF051C764F57420B (void);
// 0x00000197 System.Void UnityEngine.UI.InputField::MoveTextEnd(System.Boolean)
extern void InputField_MoveTextEnd_m8291A816FFD832C118C34F4220D6FE636EC6E4BB (void);
// 0x00000198 System.Void UnityEngine.UI.InputField::MoveTextStart(System.Boolean)
extern void InputField_MoveTextStart_m35289A28C51F5013159FB1EA1C51E9A0899BAC13 (void);
// 0x00000199 System.String UnityEngine.UI.InputField::get_clipboard()
extern void InputField_get_clipboard_m87ED8C088B1944A9650DBD85EC22D11433AD6899 (void);
// 0x0000019A System.Void UnityEngine.UI.InputField::set_clipboard(System.String)
extern void InputField_set_clipboard_mA6EC02047ED47823A27FB7E87118B9543C8A168D (void);
// 0x0000019B System.Boolean UnityEngine.UI.InputField::InPlaceEditing()
extern void InputField_InPlaceEditing_m5F17CD27EB3078E57421F200A539B78F9FD1682D (void);
// 0x0000019C System.Void UnityEngine.UI.InputField::UpdateCaretFromKeyboard()
extern void InputField_UpdateCaretFromKeyboard_mA211259D2D0C449945399D833B7EDD7ED74339B3 (void);
// 0x0000019D System.Void UnityEngine.UI.InputField::LateUpdate()
extern void InputField_LateUpdate_mE13037D8AAE74792EE4778656814D109024952B9 (void);
// 0x0000019E UnityEngine.Vector2 UnityEngine.UI.InputField::ScreenToLocal(UnityEngine.Vector2)
extern void InputField_ScreenToLocal_m4B659514B174BA0738ECB4D1D6BE5DCB9A75665D (void);
// 0x0000019F System.Int32 UnityEngine.UI.InputField::GetUnclampedCharacterLineFromPosition(UnityEngine.Vector2,UnityEngine.TextGenerator)
extern void InputField_GetUnclampedCharacterLineFromPosition_mA6F6A42ABE7639B298B52F042C665680353D279F (void);
// 0x000001A0 System.Int32 UnityEngine.UI.InputField::GetCharacterIndexFromPosition(UnityEngine.Vector2)
extern void InputField_GetCharacterIndexFromPosition_m5388B3DCABB00D1EA4CE6552FC968A33EC767DD6 (void);
// 0x000001A1 System.Boolean UnityEngine.UI.InputField::MayDrag(UnityEngine.EventSystems.PointerEventData)
extern void InputField_MayDrag_m946895179CA97D3AC931726D8D8A5569A1A65E59 (void);
// 0x000001A2 System.Void UnityEngine.UI.InputField::OnBeginDrag(UnityEngine.EventSystems.PointerEventData)
extern void InputField_OnBeginDrag_m8776FCBE8ECD5C40E82A095677EB8C6CEE9FEA21 (void);
// 0x000001A3 System.Void UnityEngine.UI.InputField::OnDrag(UnityEngine.EventSystems.PointerEventData)
extern void InputField_OnDrag_m61EA2B1E813F8500D8F6E35025FEF7F1A0654794 (void);
// 0x000001A4 System.Collections.IEnumerator UnityEngine.UI.InputField::MouseDragOutsideRect(UnityEngine.EventSystems.PointerEventData)
extern void InputField_MouseDragOutsideRect_mBC8D652300D6171DD11D57C5F5059B16484731C6 (void);
// 0x000001A5 System.Void UnityEngine.UI.InputField::OnEndDrag(UnityEngine.EventSystems.PointerEventData)
extern void InputField_OnEndDrag_mCADE3829E0CA9518C9638A46D5261B3DEF55E012 (void);
// 0x000001A6 System.Void UnityEngine.UI.InputField::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
extern void InputField_OnPointerDown_m5CD7B9F95A3465DDB6454CF1F2AF46896A4CF932 (void);
// 0x000001A7 UnityEngine.UI.InputField/EditState UnityEngine.UI.InputField::KeyPressed(UnityEngine.Event)
extern void InputField_KeyPressed_mEA9D60091DBDFCC1F62B626C119A1618DB2395E4 (void);
// 0x000001A8 System.Boolean UnityEngine.UI.InputField::IsValidChar(System.Char)
extern void InputField_IsValidChar_m3C26A8B27DAAE0A59BC7210B36212D46DB8B1E86 (void);
// 0x000001A9 System.Void UnityEngine.UI.InputField::ProcessEvent(UnityEngine.Event)
extern void InputField_ProcessEvent_mAD3C565CB7849EAFFB71855FD6382BCECF239877 (void);
// 0x000001AA System.Void UnityEngine.UI.InputField::OnUpdateSelected(UnityEngine.EventSystems.BaseEventData)
extern void InputField_OnUpdateSelected_m98054B214C32ED83ADB3A2FDDE381A21DC11A046 (void);
// 0x000001AB System.String UnityEngine.UI.InputField::GetSelectedString()
extern void InputField_GetSelectedString_m761F3DEC2B8D9B76EDC69DD671107CF7A4E56A0A (void);
// 0x000001AC System.Int32 UnityEngine.UI.InputField::FindtNextWordBegin()
extern void InputField_FindtNextWordBegin_m419767AB6316824DFE43453E667E6D4A9A348414 (void);
// 0x000001AD System.Void UnityEngine.UI.InputField::MoveRight(System.Boolean,System.Boolean)
extern void InputField_MoveRight_m4C134741EB97B5EC89420A1A1DE71AF7F7E39361 (void);
// 0x000001AE System.Int32 UnityEngine.UI.InputField::FindtPrevWordBegin()
extern void InputField_FindtPrevWordBegin_m98550E481175C04EDBBD08052E3F858FBE2144FE (void);
// 0x000001AF System.Void UnityEngine.UI.InputField::MoveLeft(System.Boolean,System.Boolean)
extern void InputField_MoveLeft_mCE95C5E9D07A7B8B4A5E678542B0B593D20A776C (void);
// 0x000001B0 System.Int32 UnityEngine.UI.InputField::DetermineCharacterLine(System.Int32,UnityEngine.TextGenerator)
extern void InputField_DetermineCharacterLine_m925C5167CBCD2F83CC65948F091962215AEC64E1 (void);
// 0x000001B1 System.Int32 UnityEngine.UI.InputField::LineUpCharacterPosition(System.Int32,System.Boolean)
extern void InputField_LineUpCharacterPosition_m71B047A08236E2A951664B72CF9C274D901731B1 (void);
// 0x000001B2 System.Int32 UnityEngine.UI.InputField::LineDownCharacterPosition(System.Int32,System.Boolean)
extern void InputField_LineDownCharacterPosition_m6882D259B230FD4959193870B577126128F14FAC (void);
// 0x000001B3 System.Void UnityEngine.UI.InputField::MoveDown(System.Boolean)
extern void InputField_MoveDown_m97C7C3ED2A7A82A40ADAD9E3C8189D07AF7757DD (void);
// 0x000001B4 System.Void UnityEngine.UI.InputField::MoveDown(System.Boolean,System.Boolean)
extern void InputField_MoveDown_m9BF66331524D87F6A52B31B24DD158F866898D7E (void);
// 0x000001B5 System.Void UnityEngine.UI.InputField::MoveUp(System.Boolean)
extern void InputField_MoveUp_m195799658320F3FCB0A5FD477946BE00478D2BA4 (void);
// 0x000001B6 System.Void UnityEngine.UI.InputField::MoveUp(System.Boolean,System.Boolean)
extern void InputField_MoveUp_m34EB65513DEA6C65A078E574C6D6E339D94AE2AE (void);
// 0x000001B7 System.Void UnityEngine.UI.InputField::Delete()
extern void InputField_Delete_m75479E87AD701376D0518A18BC7E4843C1FE8CC6 (void);
// 0x000001B8 System.Void UnityEngine.UI.InputField::ForwardSpace()
extern void InputField_ForwardSpace_mB8BA4AC3665D63B5F2A8B55F561924E05DAB2A5E (void);
// 0x000001B9 System.Void UnityEngine.UI.InputField::Backspace()
extern void InputField_Backspace_m680DD4C0F0A0909FC175FE0CCBAF2432ED5DE024 (void);
// 0x000001BA System.Void UnityEngine.UI.InputField::Insert(System.Char)
extern void InputField_Insert_m27461897DD817CB4BDE4C53B2758B6DF24EAAE9C (void);
// 0x000001BB System.Void UnityEngine.UI.InputField::UpdateTouchKeyboardFromEditChanges()
extern void InputField_UpdateTouchKeyboardFromEditChanges_m4CD005532CF761D05B43E41F42A9E2006C9D7942 (void);
// 0x000001BC System.Void UnityEngine.UI.InputField::SendOnValueChangedAndUpdateLabel()
extern void InputField_SendOnValueChangedAndUpdateLabel_m0BDE3809282CC75454CBFC4FC3F132F2DAEC1328 (void);
// 0x000001BD System.Void UnityEngine.UI.InputField::SendOnValueChanged()
extern void InputField_SendOnValueChanged_m109BDF2F31D21428277833B6717D301B5913CDE8 (void);
// 0x000001BE System.Void UnityEngine.UI.InputField::SendOnSubmit()
extern void InputField_SendOnSubmit_mD7791DDE32989BCA9889CE8DE7A83BBA5AA33509 (void);
// 0x000001BF System.Void UnityEngine.UI.InputField::Append(System.String)
extern void InputField_Append_m9DB5994BC31CC8F86FC49603267FB1F66671AB63 (void);
// 0x000001C0 System.Void UnityEngine.UI.InputField::Append(System.Char)
extern void InputField_Append_mAEDAFB21A110A4A5AC9408411F9AF7C6FE95B16C (void);
// 0x000001C1 System.Void UnityEngine.UI.InputField::UpdateLabel()
extern void InputField_UpdateLabel_m56AF0E325FFD43B6039469CF9F64942777AF07D7 (void);
// 0x000001C2 System.Boolean UnityEngine.UI.InputField::IsSelectionVisible()
extern void InputField_IsSelectionVisible_mDDCB4FB02B253679E8A26BB30618B2BE0C8EF257 (void);
// 0x000001C3 System.Int32 UnityEngine.UI.InputField::GetLineStartPosition(UnityEngine.TextGenerator,System.Int32)
extern void InputField_GetLineStartPosition_mB1B1189372CEE93568E9257709D37B7D41C745AC (void);
// 0x000001C4 System.Int32 UnityEngine.UI.InputField::GetLineEndPosition(UnityEngine.TextGenerator,System.Int32)
extern void InputField_GetLineEndPosition_m3FE92795F71AF46C930B7D155FAF4CEFC08B908E (void);
// 0x000001C5 System.Void UnityEngine.UI.InputField::SetDrawRangeToContainCaretPosition(System.Int32)
extern void InputField_SetDrawRangeToContainCaretPosition_m6D0F9575DFFB0706ACDF50DB01FB208D524D94B8 (void);
// 0x000001C6 System.Void UnityEngine.UI.InputField::ForceLabelUpdate()
extern void InputField_ForceLabelUpdate_m9078340CFD94260B81F17C288DAD373A668C51A5 (void);
// 0x000001C7 System.Void UnityEngine.UI.InputField::MarkGeometryAsDirty()
extern void InputField_MarkGeometryAsDirty_mA5216287BEAAC4D0014DE2DFCD0000AD16C6BA46 (void);
// 0x000001C8 System.Void UnityEngine.UI.InputField::Rebuild(UnityEngine.UI.CanvasUpdate)
extern void InputField_Rebuild_mA488543E825A8EC8A360A540D9FB01764AD3629D (void);
// 0x000001C9 System.Void UnityEngine.UI.InputField::LayoutComplete()
extern void InputField_LayoutComplete_mA3E0738AAC694417AF9FB264155DA14336E38FF4 (void);
// 0x000001CA System.Void UnityEngine.UI.InputField::GraphicUpdateComplete()
extern void InputField_GraphicUpdateComplete_m81F61868C3F59CFF7469CF32EE814B8828381FAC (void);
// 0x000001CB System.Void UnityEngine.UI.InputField::UpdateGeometry()
extern void InputField_UpdateGeometry_m1C7358E21A1DED9E9BC04C481DF8FC91F91F478F (void);
// 0x000001CC System.Void UnityEngine.UI.InputField::AssignPositioningIfNeeded()
extern void InputField_AssignPositioningIfNeeded_m8496688DC031C0F84BB4E54DBA151E5F2E222C63 (void);
// 0x000001CD System.Void UnityEngine.UI.InputField::OnFillVBO(UnityEngine.Mesh)
extern void InputField_OnFillVBO_mBC5777473FE0CB1136EB3FBDD9A8304B15806DF2 (void);
// 0x000001CE System.Void UnityEngine.UI.InputField::GenerateCaret(UnityEngine.UI.VertexHelper,UnityEngine.Vector2)
extern void InputField_GenerateCaret_m1E7FF81EE5A455B29E43D569CEB9AECA895A4245 (void);
// 0x000001CF System.Void UnityEngine.UI.InputField::CreateCursorVerts()
extern void InputField_CreateCursorVerts_m2A026BA8A75C2D185E031A34628042A7657D773B (void);
// 0x000001D0 System.Void UnityEngine.UI.InputField::GenerateHighlight(UnityEngine.UI.VertexHelper,UnityEngine.Vector2)
extern void InputField_GenerateHighlight_m7186EE9860C6681E464D08CF7E468213159F9D11 (void);
// 0x000001D1 System.Char UnityEngine.UI.InputField::Validate(System.String,System.Int32,System.Char)
extern void InputField_Validate_m826B947E2A4B23D6CB485CE11706451BA9121B62 (void);
// 0x000001D2 System.Void UnityEngine.UI.InputField::ActivateInputField()
extern void InputField_ActivateInputField_m66BDD1901AC8340AB4E8CD05A57F078E0DC8A25F (void);
// 0x000001D3 System.Void UnityEngine.UI.InputField::ActivateInputFieldInternal()
extern void InputField_ActivateInputFieldInternal_mE34A1852894F77959A6C9456E6DDB875E79DF43F (void);
// 0x000001D4 System.Void UnityEngine.UI.InputField::OnSelect(UnityEngine.EventSystems.BaseEventData)
extern void InputField_OnSelect_m2A617E01070E5CF91C03FB5767809A1D70F99BB8 (void);
// 0x000001D5 System.Void UnityEngine.UI.InputField::OnPointerClick(UnityEngine.EventSystems.PointerEventData)
extern void InputField_OnPointerClick_m24CF01ECCA8827C3BE3F457AC04749862EF3DF68 (void);
// 0x000001D6 System.Void UnityEngine.UI.InputField::DeactivateInputField()
extern void InputField_DeactivateInputField_mF737763D44515FFDD2CB8996C217E309A7C093C1 (void);
// 0x000001D7 System.Void UnityEngine.UI.InputField::OnDeselect(UnityEngine.EventSystems.BaseEventData)
extern void InputField_OnDeselect_m82BDA40E2189550304326F34731DD3ECEB6AFBF9 (void);
// 0x000001D8 System.Void UnityEngine.UI.InputField::OnSubmit(UnityEngine.EventSystems.BaseEventData)
extern void InputField_OnSubmit_m785E6CDC0214663CF6F98AC9A510207C94C66C75 (void);
// 0x000001D9 System.Void UnityEngine.UI.InputField::EnforceContentType()
extern void InputField_EnforceContentType_m10FEFA2EDDFAAFC991DB65015F1F568681773DAB (void);
// 0x000001DA System.Void UnityEngine.UI.InputField::EnforceTextHOverflow()
extern void InputField_EnforceTextHOverflow_m379D84AC252CC5B0F97C0AD18C0211262BD46844 (void);
// 0x000001DB System.Void UnityEngine.UI.InputField::SetToCustomIfContentTypeIsNot(UnityEngine.UI.InputField/ContentType[])
extern void InputField_SetToCustomIfContentTypeIsNot_mCD19F5C6652848C0C69747D41E27ED45C049A68E (void);
// 0x000001DC System.Void UnityEngine.UI.InputField::SetToCustom()
extern void InputField_SetToCustom_m910908310AD2FA95A55DF409518D6F850101AE03 (void);
// 0x000001DD System.Void UnityEngine.UI.InputField::DoStateTransition(UnityEngine.UI.Selectable/SelectionState,System.Boolean)
extern void InputField_DoStateTransition_m731CAF975B9C0EC4F8F532F44D13682829F1D58F (void);
// 0x000001DE System.Void UnityEngine.UI.InputField::CalculateLayoutInputHorizontal()
extern void InputField_CalculateLayoutInputHorizontal_m2C1B72BC5ABDEF5591BB2FDC052DBCE5E2B65B2F (void);
// 0x000001DF System.Void UnityEngine.UI.InputField::CalculateLayoutInputVertical()
extern void InputField_CalculateLayoutInputVertical_mDB5730E842441D564B167213E30273B7A68676DE (void);
// 0x000001E0 System.Single UnityEngine.UI.InputField::get_minWidth()
extern void InputField_get_minWidth_m6E032035AE2A92CA1598C3D2A2F2810F99F2D861 (void);
// 0x000001E1 System.Single UnityEngine.UI.InputField::get_preferredWidth()
extern void InputField_get_preferredWidth_m32D60DB236E3746DC4B4EF7AF959BE38644BDA2D (void);
// 0x000001E2 System.Single UnityEngine.UI.InputField::get_flexibleWidth()
extern void InputField_get_flexibleWidth_m5B43EC657BBE243E692C4F1220BB70D8A607D453 (void);
// 0x000001E3 System.Single UnityEngine.UI.InputField::get_minHeight()
extern void InputField_get_minHeight_m2E81E7A196378F1A26F5E5F2B135BB5A6DD27F7F (void);
// 0x000001E4 System.Single UnityEngine.UI.InputField::get_preferredHeight()
extern void InputField_get_preferredHeight_m12F9C42567B57A7D9CE0006304D5BC89A798ED4F (void);
// 0x000001E5 System.Single UnityEngine.UI.InputField::get_flexibleHeight()
extern void InputField_get_flexibleHeight_m193CFE65714A149E47A1F440CA75A12E06A8904D (void);
// 0x000001E6 System.Int32 UnityEngine.UI.InputField::get_layoutPriority()
extern void InputField_get_layoutPriority_m6CA2ACA9A3A94A6D181E7C3139ACC794A7DC2A40 (void);
// 0x000001E7 System.Void UnityEngine.UI.InputField::.cctor()
extern void InputField__cctor_m5C49905D88F7708D78B17A5F9FAF0AE5FDD1A85C (void);
// 0x000001E8 UnityEngine.Transform UnityEngine.UI.InputField::UnityEngine.UI.ICanvasElement.get_transform()
extern void InputField_UnityEngine_UI_ICanvasElement_get_transform_mA04C52C3E8831E49F2D5ED03E7A1B532E83D0C28 (void);
// 0x000001E9 UnityEngine.UI.AspectRatioFitter/AspectMode UnityEngine.UI.AspectRatioFitter::get_aspectMode()
extern void AspectRatioFitter_get_aspectMode_m9DC7F64E9AB97AAB413EEF9931EDEDF90ACE0B75 (void);
// 0x000001EA System.Void UnityEngine.UI.AspectRatioFitter::set_aspectMode(UnityEngine.UI.AspectRatioFitter/AspectMode)
extern void AspectRatioFitter_set_aspectMode_m2B9DECD0227F9EA110263C1DD914ACA721BA9FFD (void);
// 0x000001EB System.Single UnityEngine.UI.AspectRatioFitter::get_aspectRatio()
extern void AspectRatioFitter_get_aspectRatio_m7141303427F7C4B091B584E7D4ED93B54A91BA24 (void);
// 0x000001EC System.Void UnityEngine.UI.AspectRatioFitter::set_aspectRatio(System.Single)
extern void AspectRatioFitter_set_aspectRatio_mA2730A84D3DBECC5BD1F4312AA9AEBE0E70C09EA (void);
// 0x000001ED UnityEngine.RectTransform UnityEngine.UI.AspectRatioFitter::get_rectTransform()
extern void AspectRatioFitter_get_rectTransform_m10762C918EB094ED7335B938446F6537EF9E7F26 (void);
// 0x000001EE System.Void UnityEngine.UI.AspectRatioFitter::.ctor()
extern void AspectRatioFitter__ctor_mE02BE235DC018758BFE700706FBB402DC33BDFD1 (void);
// 0x000001EF System.Void UnityEngine.UI.AspectRatioFitter::OnEnable()
extern void AspectRatioFitter_OnEnable_m2B6B9713030B8DBFCD9EFF71CEEA31909C030BAE (void);
// 0x000001F0 System.Void UnityEngine.UI.AspectRatioFitter::OnDisable()
extern void AspectRatioFitter_OnDisable_mE231BEC53154F2BA0DD9DB6955DAF9D14460EB2C (void);
// 0x000001F1 System.Void UnityEngine.UI.AspectRatioFitter::Update()
extern void AspectRatioFitter_Update_m191D2D397A1A1768C15DFD06B2F0E78053754FEC (void);
// 0x000001F2 System.Void UnityEngine.UI.AspectRatioFitter::OnRectTransformDimensionsChange()
extern void AspectRatioFitter_OnRectTransformDimensionsChange_m74DBDBE13646F660E7A0DE64DE8F30771209D269 (void);
// 0x000001F3 System.Void UnityEngine.UI.AspectRatioFitter::UpdateRect()
extern void AspectRatioFitter_UpdateRect_mF6BB81E2FBD1F500FA9B6F9412B03AA7ECC1C3F8 (void);
// 0x000001F4 System.Single UnityEngine.UI.AspectRatioFitter::GetSizeDeltaToProduceSize(System.Single,System.Int32)
extern void AspectRatioFitter_GetSizeDeltaToProduceSize_mC140746FFF3304905CFDA0D7BB6F44805802F018 (void);
// 0x000001F5 UnityEngine.Vector2 UnityEngine.UI.AspectRatioFitter::GetParentSize()
extern void AspectRatioFitter_GetParentSize_m5AA652B731F6930CA9C9B342C93354D73EFB6874 (void);
// 0x000001F6 System.Void UnityEngine.UI.AspectRatioFitter::SetLayoutHorizontal()
extern void AspectRatioFitter_SetLayoutHorizontal_mF7D446EBAC74206ED48D7A0351D4E713A9CEA956 (void);
// 0x000001F7 System.Void UnityEngine.UI.AspectRatioFitter::SetLayoutVertical()
extern void AspectRatioFitter_SetLayoutVertical_m7C15BC603D635DFE7E55724F2BA88D8DDF5C1FE3 (void);
// 0x000001F8 System.Void UnityEngine.UI.AspectRatioFitter::SetDirty()
extern void AspectRatioFitter_SetDirty_mA44FF8D66147B28F0F8885F0CB2FD63A610E45F8 (void);
// 0x000001F9 UnityEngine.UI.CanvasScaler/ScaleMode UnityEngine.UI.CanvasScaler::get_uiScaleMode()
extern void CanvasScaler_get_uiScaleMode_m8D75124B20A8598DFEF27665EBE9C5925CB25301 (void);
// 0x000001FA System.Void UnityEngine.UI.CanvasScaler::set_uiScaleMode(UnityEngine.UI.CanvasScaler/ScaleMode)
extern void CanvasScaler_set_uiScaleMode_m478E9BFA69FD3316071D3D7ED2FE39E7178B2457 (void);
// 0x000001FB System.Single UnityEngine.UI.CanvasScaler::get_referencePixelsPerUnit()
extern void CanvasScaler_get_referencePixelsPerUnit_m8BBFDC7B5F8FBD64EDCE87496628A80F2A0D11F2 (void);
// 0x000001FC System.Void UnityEngine.UI.CanvasScaler::set_referencePixelsPerUnit(System.Single)
extern void CanvasScaler_set_referencePixelsPerUnit_m4B93F51599E7546F20E3B6493B3EF64486C00EFE (void);
// 0x000001FD System.Single UnityEngine.UI.CanvasScaler::get_scaleFactor()
extern void CanvasScaler_get_scaleFactor_m5314751BC9829C63CA49617A045A0D1F878C7369 (void);
// 0x000001FE System.Void UnityEngine.UI.CanvasScaler::set_scaleFactor(System.Single)
extern void CanvasScaler_set_scaleFactor_m5F0946A8D73C20E1D337ED96E16687CD9E03F64E (void);
// 0x000001FF UnityEngine.Vector2 UnityEngine.UI.CanvasScaler::get_referenceResolution()
extern void CanvasScaler_get_referenceResolution_m8CB18ECD76532AD9FAFA92D9D395AB1070730A8C (void);
// 0x00000200 System.Void UnityEngine.UI.CanvasScaler::set_referenceResolution(UnityEngine.Vector2)
extern void CanvasScaler_set_referenceResolution_mF84A06A5910501D88862F2A3E60C4D1C7F2366F9 (void);
// 0x00000201 UnityEngine.UI.CanvasScaler/ScreenMatchMode UnityEngine.UI.CanvasScaler::get_screenMatchMode()
extern void CanvasScaler_get_screenMatchMode_mD1444EF5D606499AE030E88AEACD0D4319C394F2 (void);
// 0x00000202 System.Void UnityEngine.UI.CanvasScaler::set_screenMatchMode(UnityEngine.UI.CanvasScaler/ScreenMatchMode)
extern void CanvasScaler_set_screenMatchMode_m250FDED7E3FC15A299F5C4F2F54331938A25C56B (void);
// 0x00000203 System.Single UnityEngine.UI.CanvasScaler::get_matchWidthOrHeight()
extern void CanvasScaler_get_matchWidthOrHeight_mD8FE572E1C181C79825EDBF2784D0ABC52E35335 (void);
// 0x00000204 System.Void UnityEngine.UI.CanvasScaler::set_matchWidthOrHeight(System.Single)
extern void CanvasScaler_set_matchWidthOrHeight_m3D4313C8B356B3B2FDF55338A0738554148C2496 (void);
// 0x00000205 UnityEngine.UI.CanvasScaler/Unit UnityEngine.UI.CanvasScaler::get_physicalUnit()
extern void CanvasScaler_get_physicalUnit_m2F6DD4DFDDA3DE8652A5F295C1E66060D0D8E94A (void);
// 0x00000206 System.Void UnityEngine.UI.CanvasScaler::set_physicalUnit(UnityEngine.UI.CanvasScaler/Unit)
extern void CanvasScaler_set_physicalUnit_mEA258DCB98BCD821B005A9B692B60AF26E89AE75 (void);
// 0x00000207 System.Single UnityEngine.UI.CanvasScaler::get_fallbackScreenDPI()
extern void CanvasScaler_get_fallbackScreenDPI_m1AD8E450A8FC166D4ABD1B4DF60F0B3CF40CA098 (void);
// 0x00000208 System.Void UnityEngine.UI.CanvasScaler::set_fallbackScreenDPI(System.Single)
extern void CanvasScaler_set_fallbackScreenDPI_m8F5F430869974863F420751733DD54DDA65F1849 (void);
// 0x00000209 System.Single UnityEngine.UI.CanvasScaler::get_defaultSpriteDPI()
extern void CanvasScaler_get_defaultSpriteDPI_mE6F4BC67BC414A04C503B416BB9E570E2FE2D233 (void);
// 0x0000020A System.Void UnityEngine.UI.CanvasScaler::set_defaultSpriteDPI(System.Single)
extern void CanvasScaler_set_defaultSpriteDPI_mB5AA7CA6E85A7D5D37C0B585B73F37D05FBBE1B7 (void);
// 0x0000020B System.Single UnityEngine.UI.CanvasScaler::get_dynamicPixelsPerUnit()
extern void CanvasScaler_get_dynamicPixelsPerUnit_m1D3563AB8AA6D1DDD6E555FDA4D95DFCF1561F37 (void);
// 0x0000020C System.Void UnityEngine.UI.CanvasScaler::set_dynamicPixelsPerUnit(System.Single)
extern void CanvasScaler_set_dynamicPixelsPerUnit_m246DCF7C13AF23ACBBDBD961225A80DD9EA8AA5B (void);
// 0x0000020D System.Void UnityEngine.UI.CanvasScaler::.ctor()
extern void CanvasScaler__ctor_m81B7F75FE4D0083EF90495C1FFD56272F6F5B7F4 (void);
// 0x0000020E System.Void UnityEngine.UI.CanvasScaler::OnEnable()
extern void CanvasScaler_OnEnable_m13AC455B337B234EE4175EF573ED8605803493D6 (void);
// 0x0000020F System.Void UnityEngine.UI.CanvasScaler::Canvas_preWillRenderCanvases()
extern void CanvasScaler_Canvas_preWillRenderCanvases_m17D245138E87A90ECDD52F83DF76C2A38C23FCC4 (void);
// 0x00000210 System.Void UnityEngine.UI.CanvasScaler::OnDisable()
extern void CanvasScaler_OnDisable_m280A05C8B1C3CE112D66C56C4594BC14289B6BE5 (void);
// 0x00000211 System.Void UnityEngine.UI.CanvasScaler::Handle()
extern void CanvasScaler_Handle_mF38FFB050D9EF070AEA7B02DA20BCC4A0B8CC1C3 (void);
// 0x00000212 System.Void UnityEngine.UI.CanvasScaler::HandleWorldCanvas()
extern void CanvasScaler_HandleWorldCanvas_m4046A6BA99D747151C37AB62ADB1D96B76882C42 (void);
// 0x00000213 System.Void UnityEngine.UI.CanvasScaler::HandleConstantPixelSize()
extern void CanvasScaler_HandleConstantPixelSize_m1850F67FA454035DF75C523220FA06DC490AE90E (void);
// 0x00000214 System.Void UnityEngine.UI.CanvasScaler::HandleScaleWithScreenSize()
extern void CanvasScaler_HandleScaleWithScreenSize_mE0E51C003AC9FAAA848D20B0C150BE48A616CE66 (void);
// 0x00000215 System.Void UnityEngine.UI.CanvasScaler::HandleConstantPhysicalSize()
extern void CanvasScaler_HandleConstantPhysicalSize_m1518C4BAB0337C6C892B97AA4E02877A795453D2 (void);
// 0x00000216 System.Void UnityEngine.UI.CanvasScaler::SetScaleFactor(System.Single)
extern void CanvasScaler_SetScaleFactor_m7713446FB3925CF413DA9CAD0F41B6BA1664EBAC (void);
// 0x00000217 System.Void UnityEngine.UI.CanvasScaler::SetReferencePixelsPerUnit(System.Single)
extern void CanvasScaler_SetReferencePixelsPerUnit_m701D2207CF834585C87E53C88E1D10EACAADB9C9 (void);
// 0x00000218 UnityEngine.UI.ContentSizeFitter/FitMode UnityEngine.UI.ContentSizeFitter::get_horizontalFit()
extern void ContentSizeFitter_get_horizontalFit_mB775F652AC10946108F7D44BB52C57413086F524 (void);
// 0x00000219 System.Void UnityEngine.UI.ContentSizeFitter::set_horizontalFit(UnityEngine.UI.ContentSizeFitter/FitMode)
extern void ContentSizeFitter_set_horizontalFit_mA1745A5D95BC8E08C7433D60F7C74501EEC7D232 (void);
// 0x0000021A UnityEngine.UI.ContentSizeFitter/FitMode UnityEngine.UI.ContentSizeFitter::get_verticalFit()
extern void ContentSizeFitter_get_verticalFit_m937F784A1D950E72A561B7DF96206ADA5F1FC490 (void);
// 0x0000021B System.Void UnityEngine.UI.ContentSizeFitter::set_verticalFit(UnityEngine.UI.ContentSizeFitter/FitMode)
extern void ContentSizeFitter_set_verticalFit_m57AFB7FD63A75442295C14BA58417B2110FE836A (void);
// 0x0000021C UnityEngine.RectTransform UnityEngine.UI.ContentSizeFitter::get_rectTransform()
extern void ContentSizeFitter_get_rectTransform_mE7FD5F977E954B6D54B9C1CCD112A4A70840CF56 (void);
// 0x0000021D System.Void UnityEngine.UI.ContentSizeFitter::.ctor()
extern void ContentSizeFitter__ctor_m2E5245D54587CA87E6AEE5AB7FA33AB33461D4BF (void);
// 0x0000021E System.Void UnityEngine.UI.ContentSizeFitter::OnEnable()
extern void ContentSizeFitter_OnEnable_mBB226A80395594658A4E93F5CEBDA702B2581D74 (void);
// 0x0000021F System.Void UnityEngine.UI.ContentSizeFitter::OnDisable()
extern void ContentSizeFitter_OnDisable_m500C638EBFCDA4B7B10A93A4106B49DBADCB9619 (void);
// 0x00000220 System.Void UnityEngine.UI.ContentSizeFitter::OnRectTransformDimensionsChange()
extern void ContentSizeFitter_OnRectTransformDimensionsChange_m299D481E8654CF7608B48204E48678C84DF7DB1A (void);
// 0x00000221 System.Void UnityEngine.UI.ContentSizeFitter::HandleSelfFittingAlongAxis(System.Int32)
extern void ContentSizeFitter_HandleSelfFittingAlongAxis_m725678942EB77B09B4FCD47347DF54FD7079AFF8 (void);
// 0x00000222 System.Void UnityEngine.UI.ContentSizeFitter::SetLayoutHorizontal()
extern void ContentSizeFitter_SetLayoutHorizontal_m966F300CAB4A67ED9FCE5C8133F091BEAA53F435 (void);
// 0x00000223 System.Void UnityEngine.UI.ContentSizeFitter::SetLayoutVertical()
extern void ContentSizeFitter_SetLayoutVertical_m8B76F70D92D2D74ACBB85D35028B1949205FEA63 (void);
// 0x00000224 System.Void UnityEngine.UI.ContentSizeFitter::SetDirty()
extern void ContentSizeFitter_SetDirty_m4830A85DEBF04D4D2523563C5E5ECE3712225080 (void);
// 0x00000225 UnityEngine.UI.GridLayoutGroup/Corner UnityEngine.UI.GridLayoutGroup::get_startCorner()
extern void GridLayoutGroup_get_startCorner_m8D842137857E7AD45EE6AC346E0413A8F392729F (void);
// 0x00000226 System.Void UnityEngine.UI.GridLayoutGroup::set_startCorner(UnityEngine.UI.GridLayoutGroup/Corner)
extern void GridLayoutGroup_set_startCorner_mA30664DE41D3BAA82D88A5A99D1E8141799A6609 (void);
// 0x00000227 UnityEngine.UI.GridLayoutGroup/Axis UnityEngine.UI.GridLayoutGroup::get_startAxis()
extern void GridLayoutGroup_get_startAxis_mAA66BAC768514A784F891AF3771952CFDE713E7D (void);
// 0x00000228 System.Void UnityEngine.UI.GridLayoutGroup::set_startAxis(UnityEngine.UI.GridLayoutGroup/Axis)
extern void GridLayoutGroup_set_startAxis_m273639C7AFDB7C478E131FBE86C1BA856ABE2B25 (void);
// 0x00000229 UnityEngine.Vector2 UnityEngine.UI.GridLayoutGroup::get_cellSize()
extern void GridLayoutGroup_get_cellSize_mC5817788B1279F0ED4FA8E97D64B705FB782FCAA (void);
// 0x0000022A System.Void UnityEngine.UI.GridLayoutGroup::set_cellSize(UnityEngine.Vector2)
extern void GridLayoutGroup_set_cellSize_m3002F1B69515359C8B04F5443D564069B9023A48 (void);
// 0x0000022B UnityEngine.Vector2 UnityEngine.UI.GridLayoutGroup::get_spacing()
extern void GridLayoutGroup_get_spacing_m4E066AD77C47D776D142944838AA592DCDBFB1F1 (void);
// 0x0000022C System.Void UnityEngine.UI.GridLayoutGroup::set_spacing(UnityEngine.Vector2)
extern void GridLayoutGroup_set_spacing_mF32D629044BD8E6C1957988794045138C24308A8 (void);
// 0x0000022D UnityEngine.UI.GridLayoutGroup/Constraint UnityEngine.UI.GridLayoutGroup::get_constraint()
extern void GridLayoutGroup_get_constraint_mD3C4128F573301158661CC38EB13105D2A3CD0F8 (void);
// 0x0000022E System.Void UnityEngine.UI.GridLayoutGroup::set_constraint(UnityEngine.UI.GridLayoutGroup/Constraint)
extern void GridLayoutGroup_set_constraint_mE4443AAB6843A407F9DF59149A96C19F357823B3 (void);
// 0x0000022F System.Int32 UnityEngine.UI.GridLayoutGroup::get_constraintCount()
extern void GridLayoutGroup_get_constraintCount_mFDF654FD0ED7E27EE6B0A91CEFFD5CDE7CD3D3AD (void);
// 0x00000230 System.Void UnityEngine.UI.GridLayoutGroup::set_constraintCount(System.Int32)
extern void GridLayoutGroup_set_constraintCount_mCC7DC87CA3EEAEDD1169CD193B5D4AA79CC6FB7A (void);
// 0x00000231 System.Void UnityEngine.UI.GridLayoutGroup::.ctor()
extern void GridLayoutGroup__ctor_m28EC9A0E41E7E41D2300210AD64D68F8AA601719 (void);
// 0x00000232 System.Void UnityEngine.UI.GridLayoutGroup::CalculateLayoutInputHorizontal()
extern void GridLayoutGroup_CalculateLayoutInputHorizontal_mE0A1816B18864A95D5C6BAF7CA80F1258740CED0 (void);
// 0x00000233 System.Void UnityEngine.UI.GridLayoutGroup::CalculateLayoutInputVertical()
extern void GridLayoutGroup_CalculateLayoutInputVertical_m38EBB62BE57E99E0E5C12613C869963B7F42ECC8 (void);
// 0x00000234 System.Void UnityEngine.UI.GridLayoutGroup::SetLayoutHorizontal()
extern void GridLayoutGroup_SetLayoutHorizontal_m1EF39B8828AE80B69399AA7B4BE6A4C05828D2BC (void);
// 0x00000235 System.Void UnityEngine.UI.GridLayoutGroup::SetLayoutVertical()
extern void GridLayoutGroup_SetLayoutVertical_m31FD2FD1283496F10A5457B5606B3269648B6CCB (void);
// 0x00000236 System.Void UnityEngine.UI.GridLayoutGroup::SetCellsAlongAxis(System.Int32)
extern void GridLayoutGroup_SetCellsAlongAxis_m9B8524B64C76236C2A650FA33469FD304B3786AA (void);
// 0x00000237 System.Void UnityEngine.UI.HorizontalLayoutGroup::.ctor()
extern void HorizontalLayoutGroup__ctor_m91BF4E28B7EAD170D3298B97CD5693EAD3B49544 (void);
// 0x00000238 System.Void UnityEngine.UI.HorizontalLayoutGroup::CalculateLayoutInputHorizontal()
extern void HorizontalLayoutGroup_CalculateLayoutInputHorizontal_m8DBDC80D3FA52745EAA128EE8DA388FADD0969A7 (void);
// 0x00000239 System.Void UnityEngine.UI.HorizontalLayoutGroup::CalculateLayoutInputVertical()
extern void HorizontalLayoutGroup_CalculateLayoutInputVertical_m3BC66076E6A10D0AE17EF46A7333E099CFA4F0C7 (void);
// 0x0000023A System.Void UnityEngine.UI.HorizontalLayoutGroup::SetLayoutHorizontal()
extern void HorizontalLayoutGroup_SetLayoutHorizontal_m5BBC14368FBB85B9454024243237FE3D1EF4A3EC (void);
// 0x0000023B System.Void UnityEngine.UI.HorizontalLayoutGroup::SetLayoutVertical()
extern void HorizontalLayoutGroup_SetLayoutVertical_mE191679651DD170E87A8BD1FDF209C4EB1B5AC82 (void);
// 0x0000023C System.Single UnityEngine.UI.HorizontalOrVerticalLayoutGroup::get_spacing()
extern void HorizontalOrVerticalLayoutGroup_get_spacing_mF0E72DE0E088D3A1C72141A06E671820DC56B199 (void);
// 0x0000023D System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::set_spacing(System.Single)
extern void HorizontalOrVerticalLayoutGroup_set_spacing_m57D5B010DB70EE3BD758253FC5A4D66F4CFB2DC5 (void);
// 0x0000023E System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::get_childForceExpandWidth()
extern void HorizontalOrVerticalLayoutGroup_get_childForceExpandWidth_m469E78D0FBD65A4C310E048344C78FFF670F01B2 (void);
// 0x0000023F System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::set_childForceExpandWidth(System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_set_childForceExpandWidth_m4D900CF3408A41D7E65F23824609F7EF7FF57E2B (void);
// 0x00000240 System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::get_childForceExpandHeight()
extern void HorizontalOrVerticalLayoutGroup_get_childForceExpandHeight_m53DF36B44AD193D25380C7E9AC385E5E9914622C (void);
// 0x00000241 System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::set_childForceExpandHeight(System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_set_childForceExpandHeight_m76C7BA66A926BF02BE3500ADEBC10229B8FCB4A5 (void);
// 0x00000242 System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::get_childControlWidth()
extern void HorizontalOrVerticalLayoutGroup_get_childControlWidth_m717382EF5BA6539EADDCDCCFE57150059881C3B5 (void);
// 0x00000243 System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::set_childControlWidth(System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_set_childControlWidth_m2C9192500DB7BF9AB2E17C40391C4F9A7FE7DB4D (void);
// 0x00000244 System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::get_childControlHeight()
extern void HorizontalOrVerticalLayoutGroup_get_childControlHeight_mE203945C2D8E119C236765B6AD048C0B37530DCB (void);
// 0x00000245 System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::set_childControlHeight(System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_set_childControlHeight_m375CD26500D400D626D4CCE1A60C31656622FF88 (void);
// 0x00000246 System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::get_childScaleWidth()
extern void HorizontalOrVerticalLayoutGroup_get_childScaleWidth_m0160878917AC8A815C80BB11EA81744C1F768313 (void);
// 0x00000247 System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::set_childScaleWidth(System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_set_childScaleWidth_mF2CEB85EF3F4B658A8A6B6394D40EA3C44908307 (void);
// 0x00000248 System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::get_childScaleHeight()
extern void HorizontalOrVerticalLayoutGroup_get_childScaleHeight_m39F288AB513FB4CBF4EF446B3893E20B6D1857EE (void);
// 0x00000249 System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::set_childScaleHeight(System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_set_childScaleHeight_m80E62DAF30C4480E7E393F9604B33628A92CC86B (void);
// 0x0000024A System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::CalcAlongAxis(System.Int32,System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_CalcAlongAxis_mBD2F5E965FB5D3FF14DA66362F3D8D6E7570B4CB (void);
// 0x0000024B System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::SetChildrenAlongAxis(System.Int32,System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_SetChildrenAlongAxis_mE587F7E541768FF7047F667ED9275DB0ED41AB3B (void);
// 0x0000024C System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::GetChildSizes(UnityEngine.RectTransform,System.Int32,System.Boolean,System.Boolean,System.Single&,System.Single&,System.Single&)
extern void HorizontalOrVerticalLayoutGroup_GetChildSizes_m73D43AD63F25246B418DAAF75B7EAC7046F963A5 (void);
// 0x0000024D System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::.ctor()
extern void HorizontalOrVerticalLayoutGroup__ctor_m0898BB696CC353377FBCF175B86681B505130127 (void);
// 0x0000024E System.Void UnityEngine.UI.ILayoutElement::CalculateLayoutInputHorizontal()
// 0x0000024F System.Void UnityEngine.UI.ILayoutElement::CalculateLayoutInputVertical()
// 0x00000250 System.Single UnityEngine.UI.ILayoutElement::get_minWidth()
// 0x00000251 System.Single UnityEngine.UI.ILayoutElement::get_preferredWidth()
// 0x00000252 System.Single UnityEngine.UI.ILayoutElement::get_flexibleWidth()
// 0x00000253 System.Single UnityEngine.UI.ILayoutElement::get_minHeight()
// 0x00000254 System.Single UnityEngine.UI.ILayoutElement::get_preferredHeight()
// 0x00000255 System.Single UnityEngine.UI.ILayoutElement::get_flexibleHeight()
// 0x00000256 System.Int32 UnityEngine.UI.ILayoutElement::get_layoutPriority()
// 0x00000257 System.Void UnityEngine.UI.ILayoutController::SetLayoutHorizontal()
// 0x00000258 System.Void UnityEngine.UI.ILayoutController::SetLayoutVertical()
// 0x00000259 System.Boolean UnityEngine.UI.ILayoutIgnorer::get_ignoreLayout()
// 0x0000025A System.Boolean UnityEngine.UI.LayoutElement::get_ignoreLayout()
extern void LayoutElement_get_ignoreLayout_m674960BA20B5B43D66D330B5D8EC1109DE9CCCD2 (void);
// 0x0000025B System.Void UnityEngine.UI.LayoutElement::set_ignoreLayout(System.Boolean)
extern void LayoutElement_set_ignoreLayout_mA83B2CF22334007D7DB0F89770D3F0B6A1FC7549 (void);
// 0x0000025C System.Void UnityEngine.UI.LayoutElement::CalculateLayoutInputHorizontal()
extern void LayoutElement_CalculateLayoutInputHorizontal_mCAC4BA8545C1E17B9AF5373988F9CFDD316779DF (void);
// 0x0000025D System.Void UnityEngine.UI.LayoutElement::CalculateLayoutInputVertical()
extern void LayoutElement_CalculateLayoutInputVertical_m78707F08AEDC89D19AC105B9E20163A496912B09 (void);
// 0x0000025E System.Single UnityEngine.UI.LayoutElement::get_minWidth()
extern void LayoutElement_get_minWidth_mD171C411C321A923DFCA1A8078E34A5843159EED (void);
// 0x0000025F System.Void UnityEngine.UI.LayoutElement::set_minWidth(System.Single)
extern void LayoutElement_set_minWidth_m1BF66D6E95EF801A5B524FCDFAAB3D5E94CD574A (void);
// 0x00000260 System.Single UnityEngine.UI.LayoutElement::get_minHeight()
extern void LayoutElement_get_minHeight_m2073A6B54227C055021D507588AFABB4865A750E (void);
// 0x00000261 System.Void UnityEngine.UI.LayoutElement::set_minHeight(System.Single)
extern void LayoutElement_set_minHeight_m8C84E1959A4C086053AEA787D5764C161F36877B (void);
// 0x00000262 System.Single UnityEngine.UI.LayoutElement::get_preferredWidth()
extern void LayoutElement_get_preferredWidth_mCB7E4710CF26E845CB0D0C601536FBBF4E05D576 (void);
// 0x00000263 System.Void UnityEngine.UI.LayoutElement::set_preferredWidth(System.Single)
extern void LayoutElement_set_preferredWidth_m6F446890B38433645A78FF803A3A0315EDB6E11A (void);
// 0x00000264 System.Single UnityEngine.UI.LayoutElement::get_preferredHeight()
extern void LayoutElement_get_preferredHeight_m69E4021BC8EBB999C0DF30438746F73AF27B07AA (void);
// 0x00000265 System.Void UnityEngine.UI.LayoutElement::set_preferredHeight(System.Single)
extern void LayoutElement_set_preferredHeight_m8400BFE46DBF2E4FA5E1C43F4C97721AC836B91E (void);
// 0x00000266 System.Single UnityEngine.UI.LayoutElement::get_flexibleWidth()
extern void LayoutElement_get_flexibleWidth_m4CACAAE62C470DBFF9DB51E5742C1905014F65CC (void);
// 0x00000267 System.Void UnityEngine.UI.LayoutElement::set_flexibleWidth(System.Single)
extern void LayoutElement_set_flexibleWidth_m77B18FF58BF66FEFE916ABC8CECABC74D33ECFAD (void);
// 0x00000268 System.Single UnityEngine.UI.LayoutElement::get_flexibleHeight()
extern void LayoutElement_get_flexibleHeight_mD02CB51F08CC258113D840B5FF6FD1960E130E01 (void);
// 0x00000269 System.Void UnityEngine.UI.LayoutElement::set_flexibleHeight(System.Single)
extern void LayoutElement_set_flexibleHeight_mFFEE9A500A82FAF8C1AE432EA807FF05F275C038 (void);
// 0x0000026A System.Int32 UnityEngine.UI.LayoutElement::get_layoutPriority()
extern void LayoutElement_get_layoutPriority_m4BE0D6D1F8D36FA6CB8AE1AD02DAAD26215AB35B (void);
// 0x0000026B System.Void UnityEngine.UI.LayoutElement::set_layoutPriority(System.Int32)
extern void LayoutElement_set_layoutPriority_m89170914A681A6B8CE7DAE26F3E785F95FE4AEF6 (void);
// 0x0000026C System.Void UnityEngine.UI.LayoutElement::.ctor()
extern void LayoutElement__ctor_m11506C492B20963D347C2CD2C41205D08326B183 (void);
// 0x0000026D System.Void UnityEngine.UI.LayoutElement::OnEnable()
extern void LayoutElement_OnEnable_mBA9D3928DF8835C7407D60C83EF55ECD5025FCEA (void);
// 0x0000026E System.Void UnityEngine.UI.LayoutElement::OnTransformParentChanged()
extern void LayoutElement_OnTransformParentChanged_mFB56C31341BAE7691F949282A7CB305E249DBCDF (void);
// 0x0000026F System.Void UnityEngine.UI.LayoutElement::OnDisable()
extern void LayoutElement_OnDisable_m0107489E98F41B97E47267D741830C0C137CE875 (void);
// 0x00000270 System.Void UnityEngine.UI.LayoutElement::OnDidApplyAnimationProperties()
extern void LayoutElement_OnDidApplyAnimationProperties_mBEC936D11204B7C6D72C64F884E1535135B58BF0 (void);
// 0x00000271 System.Void UnityEngine.UI.LayoutElement::OnBeforeTransformParentChanged()
extern void LayoutElement_OnBeforeTransformParentChanged_mEC5B1AEF104419A64FE74B2D31A29B6DC0987565 (void);
// 0x00000272 System.Void UnityEngine.UI.LayoutElement::SetDirty()
extern void LayoutElement_SetDirty_mF388238B7950A97356CD86F94409B2C5E139C1EA (void);
// 0x00000273 UnityEngine.RectOffset UnityEngine.UI.LayoutGroup::get_padding()
extern void LayoutGroup_get_padding_m7C98F5699A1F144A3CD754094159DD61EDEA6D18 (void);
// 0x00000274 System.Void UnityEngine.UI.LayoutGroup::set_padding(UnityEngine.RectOffset)
extern void LayoutGroup_set_padding_mFF9BDC9CB27CFA3F8F7877370494589BC750E1A0 (void);
// 0x00000275 UnityEngine.TextAnchor UnityEngine.UI.LayoutGroup::get_childAlignment()
extern void LayoutGroup_get_childAlignment_mC2E6A497C4BCAEF50E46CB271EA4FB48EF345826 (void);
// 0x00000276 System.Void UnityEngine.UI.LayoutGroup::set_childAlignment(UnityEngine.TextAnchor)
extern void LayoutGroup_set_childAlignment_m682098D7D631F9CAD62E0862216EFAFF5533CCE9 (void);
// 0x00000277 UnityEngine.RectTransform UnityEngine.UI.LayoutGroup::get_rectTransform()
extern void LayoutGroup_get_rectTransform_mBA2164F608E800F4C819611E721EA825995BA9B8 (void);
// 0x00000278 System.Collections.Generic.List`1<UnityEngine.RectTransform> UnityEngine.UI.LayoutGroup::get_rectChildren()
extern void LayoutGroup_get_rectChildren_m145C077B057CFC695BA495A113A828E61B14E881 (void);
// 0x00000279 System.Void UnityEngine.UI.LayoutGroup::CalculateLayoutInputHorizontal()
extern void LayoutGroup_CalculateLayoutInputHorizontal_m277295CF69DFA23F13B84022E1D2482B16C35B2E (void);
// 0x0000027A System.Void UnityEngine.UI.LayoutGroup::CalculateLayoutInputVertical()
// 0x0000027B System.Single UnityEngine.UI.LayoutGroup::get_minWidth()
extern void LayoutGroup_get_minWidth_mD992262173D5E3937E65062B9DDD92CFD83D66AD (void);
// 0x0000027C System.Single UnityEngine.UI.LayoutGroup::get_preferredWidth()
extern void LayoutGroup_get_preferredWidth_m278AFB42E85BB072239FCA597DED628EF14C0F7E (void);
// 0x0000027D System.Single UnityEngine.UI.LayoutGroup::get_flexibleWidth()
extern void LayoutGroup_get_flexibleWidth_m9B41E60921FF83EBB1BBCBEB51AF3D174F651B4B (void);
// 0x0000027E System.Single UnityEngine.UI.LayoutGroup::get_minHeight()
extern void LayoutGroup_get_minHeight_mB83AFE2E8B307780B1897A6FA0ACE2B49FFE079B (void);
// 0x0000027F System.Single UnityEngine.UI.LayoutGroup::get_preferredHeight()
extern void LayoutGroup_get_preferredHeight_m8C6595741BFA31340941117D90C016D9ECD90B0C (void);
// 0x00000280 System.Single UnityEngine.UI.LayoutGroup::get_flexibleHeight()
extern void LayoutGroup_get_flexibleHeight_m65C158520888C4717889070B7B65BA4A844AAEE9 (void);
// 0x00000281 System.Int32 UnityEngine.UI.LayoutGroup::get_layoutPriority()
extern void LayoutGroup_get_layoutPriority_m7DE6C39661D8321D4416513FE296C59E41711DED (void);
// 0x00000282 System.Void UnityEngine.UI.LayoutGroup::SetLayoutHorizontal()
// 0x00000283 System.Void UnityEngine.UI.LayoutGroup::SetLayoutVertical()
// 0x00000284 System.Void UnityEngine.UI.LayoutGroup::.ctor()
extern void LayoutGroup__ctor_mE9EDB59D79B2F479B4F83B2E72B3F28A6ECE1FF1 (void);
// 0x00000285 System.Void UnityEngine.UI.LayoutGroup::OnEnable()
extern void LayoutGroup_OnEnable_mB39D415B2E929902587DF64A4309DB603DBF13B6 (void);
// 0x00000286 System.Void UnityEngine.UI.LayoutGroup::OnDisable()
extern void LayoutGroup_OnDisable_m8EC3E56D5C3BC149AB6AC14107FD5D355D26BA97 (void);
// 0x00000287 System.Void UnityEngine.UI.LayoutGroup::OnDidApplyAnimationProperties()
extern void LayoutGroup_OnDidApplyAnimationProperties_mD9C9DC2A8A41269702743E9B2DA147D1BDA8E3B2 (void);
// 0x00000288 System.Single UnityEngine.UI.LayoutGroup::GetTotalMinSize(System.Int32)
extern void LayoutGroup_GetTotalMinSize_m5823C20B9484ACC6E15B40969AB73C22BF957702 (void);
// 0x00000289 System.Single UnityEngine.UI.LayoutGroup::GetTotalPreferredSize(System.Int32)
extern void LayoutGroup_GetTotalPreferredSize_mB458709CB2ADDE62A57E04C6F75E9F78EDCF0B48 (void);
// 0x0000028A System.Single UnityEngine.UI.LayoutGroup::GetTotalFlexibleSize(System.Int32)
extern void LayoutGroup_GetTotalFlexibleSize_m46FDCCDA02E9C74D826901517227C4D35F6E4C1E (void);
// 0x0000028B System.Single UnityEngine.UI.LayoutGroup::GetStartOffset(System.Int32,System.Single)
extern void LayoutGroup_GetStartOffset_mE12B0110FDFF2D7EBF37B0CD707AF7D41133E7E9 (void);
// 0x0000028C System.Single UnityEngine.UI.LayoutGroup::GetAlignmentOnAxis(System.Int32)
extern void LayoutGroup_GetAlignmentOnAxis_m8A38F1E039364BFB9D27FF1BB656663D3EC96DAB (void);
// 0x0000028D System.Void UnityEngine.UI.LayoutGroup::SetLayoutInputForAxis(System.Single,System.Single,System.Single,System.Int32)
extern void LayoutGroup_SetLayoutInputForAxis_mD99F9A0F350212266AB5782DF024A5BD8752F021 (void);
// 0x0000028E System.Void UnityEngine.UI.LayoutGroup::SetChildAlongAxis(UnityEngine.RectTransform,System.Int32,System.Single)
extern void LayoutGroup_SetChildAlongAxis_m989B25707EDE13DA0BE38840FABB9D2B413E5042 (void);
// 0x0000028F System.Void UnityEngine.UI.LayoutGroup::SetChildAlongAxisWithScale(UnityEngine.RectTransform,System.Int32,System.Single,System.Single)
extern void LayoutGroup_SetChildAlongAxisWithScale_mB08FABA1880A800F5EB3621143C6AC13F0BF52D9 (void);
// 0x00000290 System.Void UnityEngine.UI.LayoutGroup::SetChildAlongAxis(UnityEngine.RectTransform,System.Int32,System.Single,System.Single)
extern void LayoutGroup_SetChildAlongAxis_m4714DB3C67D9672D10BD889BD6E116F35BD9ABEB (void);
// 0x00000291 System.Void UnityEngine.UI.LayoutGroup::SetChildAlongAxisWithScale(UnityEngine.RectTransform,System.Int32,System.Single,System.Single,System.Single)
extern void LayoutGroup_SetChildAlongAxisWithScale_m1F46FBB4FCB5BDB1D630D9745E22BE12B2CCE126 (void);
// 0x00000292 System.Boolean UnityEngine.UI.LayoutGroup::get_isRootLayoutGroup()
extern void LayoutGroup_get_isRootLayoutGroup_mA6019F332B4E8D73D975AA1C332CB8D7628EC9B0 (void);
// 0x00000293 System.Void UnityEngine.UI.LayoutGroup::OnRectTransformDimensionsChange()
extern void LayoutGroup_OnRectTransformDimensionsChange_m5BD1C40240872FA6EA86602BF85A23908DD27D7E (void);
// 0x00000294 System.Void UnityEngine.UI.LayoutGroup::OnTransformChildrenChanged()
extern void LayoutGroup_OnTransformChildrenChanged_mCA082C8376435962FAE317D684BD107B56827203 (void);
// 0x00000295 System.Void UnityEngine.UI.LayoutGroup::SetProperty(T&,T)
// 0x00000296 System.Void UnityEngine.UI.LayoutGroup::SetDirty()
extern void LayoutGroup_SetDirty_m152A7201F1F9398073632454974676E44328CFC2 (void);
// 0x00000297 System.Collections.IEnumerator UnityEngine.UI.LayoutGroup::DelayedSetDirty(UnityEngine.RectTransform)
extern void LayoutGroup_DelayedSetDirty_m2933254B576C5056DCFA10E48A542A6B8DB21C85 (void);
// 0x00000298 System.Void UnityEngine.UI.LayoutRebuilder::Initialize(UnityEngine.RectTransform)
extern void LayoutRebuilder_Initialize_m9B6938B2B1A081FB3B103A0996F2A542962BB292 (void);
// 0x00000299 System.Void UnityEngine.UI.LayoutRebuilder::Clear()
extern void LayoutRebuilder_Clear_m60DA3F587EC757923870BC3396003EA862C513D7 (void);
// 0x0000029A System.Void UnityEngine.UI.LayoutRebuilder::.cctor()
extern void LayoutRebuilder__cctor_mAF54F10C63984CCA9DEBEF6BFDF4FA61BCC2100C (void);
// 0x0000029B System.Void UnityEngine.UI.LayoutRebuilder::ReapplyDrivenProperties(UnityEngine.RectTransform)
extern void LayoutRebuilder_ReapplyDrivenProperties_mDBCB8CA4C64C45ABFAD4C2E8E873B7C1ABC4633F (void);
// 0x0000029C UnityEngine.Transform UnityEngine.UI.LayoutRebuilder::get_transform()
extern void LayoutRebuilder_get_transform_mE890ECF65A84FF10C7EE33BBC73D01503908D090 (void);
// 0x0000029D System.Boolean UnityEngine.UI.LayoutRebuilder::IsDestroyed()
extern void LayoutRebuilder_IsDestroyed_m7C00F5BFB607E5A367237F7E98C55B1F295A2E9D (void);
// 0x0000029E System.Void UnityEngine.UI.LayoutRebuilder::StripDisabledBehavioursFromList(System.Collections.Generic.List`1<UnityEngine.Component>)
extern void LayoutRebuilder_StripDisabledBehavioursFromList_m9CF0899F9CDC51CD675408E583D91FE69EB3D0A7 (void);
// 0x0000029F System.Void UnityEngine.UI.LayoutRebuilder::ForceRebuildLayoutImmediate(UnityEngine.RectTransform)
extern void LayoutRebuilder_ForceRebuildLayoutImmediate_m395DFDC2E411F7DAE10114CB6B76ECF9E2F2D210 (void);
// 0x000002A0 System.Void UnityEngine.UI.LayoutRebuilder::Rebuild(UnityEngine.UI.CanvasUpdate)
extern void LayoutRebuilder_Rebuild_m4F6172A7ABA4E3FE206DB9890581C993806CD018 (void);
// 0x000002A1 System.Void UnityEngine.UI.LayoutRebuilder::PerformLayoutControl(UnityEngine.RectTransform,UnityEngine.Events.UnityAction`1<UnityEngine.Component>)
extern void LayoutRebuilder_PerformLayoutControl_mFDAE19BFECC6C038AE7F60BC7225B8EF2CDA48BB (void);
// 0x000002A2 System.Void UnityEngine.UI.LayoutRebuilder::PerformLayoutCalculation(UnityEngine.RectTransform,UnityEngine.Events.UnityAction`1<UnityEngine.Component>)
extern void LayoutRebuilder_PerformLayoutCalculation_mCB5430F37CAD504CB027BD76C7E80B18B9A27A31 (void);
// 0x000002A3 System.Void UnityEngine.UI.LayoutRebuilder::MarkLayoutForRebuild(UnityEngine.RectTransform)
extern void LayoutRebuilder_MarkLayoutForRebuild_m25E7408353DE4624A78A43AB985C289210B6E1EE (void);
// 0x000002A4 System.Boolean UnityEngine.UI.LayoutRebuilder::ValidController(UnityEngine.RectTransform,System.Collections.Generic.List`1<UnityEngine.Component>)
extern void LayoutRebuilder_ValidController_m74EE2B6ECA5CC2CD78673626192B8A44DF3DDA0F (void);
// 0x000002A5 System.Void UnityEngine.UI.LayoutRebuilder::MarkLayoutRootForRebuild(UnityEngine.RectTransform)
extern void LayoutRebuilder_MarkLayoutRootForRebuild_m44E0DBDA962C6820A4E747F941126E96613EA0FF (void);
// 0x000002A6 System.Void UnityEngine.UI.LayoutRebuilder::LayoutComplete()
extern void LayoutRebuilder_LayoutComplete_m1426141B8418693A23108B8EBB456778886B4B62 (void);
// 0x000002A7 System.Void UnityEngine.UI.LayoutRebuilder::GraphicUpdateComplete()
extern void LayoutRebuilder_GraphicUpdateComplete_mEE37C0D1F726AD91B7A3DDCD8A6F1F056C7E1D3E (void);
// 0x000002A8 System.Int32 UnityEngine.UI.LayoutRebuilder::GetHashCode()
extern void LayoutRebuilder_GetHashCode_m5424FDACF84B9357892543701E6FC98ADE01BA1D (void);
// 0x000002A9 System.Boolean UnityEngine.UI.LayoutRebuilder::Equals(System.Object)
extern void LayoutRebuilder_Equals_m31F03DEFCFD32981725DD94633818B52E486A9A3 (void);
// 0x000002AA System.String UnityEngine.UI.LayoutRebuilder::ToString()
extern void LayoutRebuilder_ToString_mFF25DB4B319B32D5387BF7FAE7AECF3D89D1723A (void);
// 0x000002AB System.Void UnityEngine.UI.LayoutRebuilder::.ctor()
extern void LayoutRebuilder__ctor_m2BA2A83C3615437ECE582B704689CE15E0DEB2AA (void);
// 0x000002AC System.Single UnityEngine.UI.LayoutUtility::GetMinSize(UnityEngine.RectTransform,System.Int32)
extern void LayoutUtility_GetMinSize_m430414C7CA8EF99A8519968D9BD1ACEEA751A431 (void);
// 0x000002AD System.Single UnityEngine.UI.LayoutUtility::GetPreferredSize(UnityEngine.RectTransform,System.Int32)
extern void LayoutUtility_GetPreferredSize_mFF694E6C47FA410533223DC752F65F02ACA639AB (void);
// 0x000002AE System.Single UnityEngine.UI.LayoutUtility::GetFlexibleSize(UnityEngine.RectTransform,System.Int32)
extern void LayoutUtility_GetFlexibleSize_mF9999813A638C60FB044DC654F1690D151EC08D3 (void);
// 0x000002AF System.Single UnityEngine.UI.LayoutUtility::GetMinWidth(UnityEngine.RectTransform)
extern void LayoutUtility_GetMinWidth_m7636AECFC6B9D23D2F935EF451CE3AA624FB49C0 (void);
// 0x000002B0 System.Single UnityEngine.UI.LayoutUtility::GetPreferredWidth(UnityEngine.RectTransform)
extern void LayoutUtility_GetPreferredWidth_m6CE457065EFB3041B95C63F846DE4FA66420E3B2 (void);
// 0x000002B1 System.Single UnityEngine.UI.LayoutUtility::GetFlexibleWidth(UnityEngine.RectTransform)
extern void LayoutUtility_GetFlexibleWidth_mBCB8A662113B098119B47B2715015DB879738477 (void);
// 0x000002B2 System.Single UnityEngine.UI.LayoutUtility::GetMinHeight(UnityEngine.RectTransform)
extern void LayoutUtility_GetMinHeight_m340FA8EC5D74BAF9EC725DA3B92B1DE99DB1B3F8 (void);
// 0x000002B3 System.Single UnityEngine.UI.LayoutUtility::GetPreferredHeight(UnityEngine.RectTransform)
extern void LayoutUtility_GetPreferredHeight_m13A1739A1A15D012AAD85AC18307D2EDA1EE6283 (void);
// 0x000002B4 System.Single UnityEngine.UI.LayoutUtility::GetFlexibleHeight(UnityEngine.RectTransform)
extern void LayoutUtility_GetFlexibleHeight_m019E2BF198E49FC916C032CB0C47EF228A18BBDE (void);
// 0x000002B5 System.Single UnityEngine.UI.LayoutUtility::GetLayoutProperty(UnityEngine.RectTransform,System.Func`2<UnityEngine.UI.ILayoutElement,System.Single>,System.Single)
extern void LayoutUtility_GetLayoutProperty_m91333F066D9AC93F3BEC9A33AB9F3232C91FE24B (void);
// 0x000002B6 System.Single UnityEngine.UI.LayoutUtility::GetLayoutProperty(UnityEngine.RectTransform,System.Func`2<UnityEngine.UI.ILayoutElement,System.Single>,System.Single,UnityEngine.UI.ILayoutElement&)
extern void LayoutUtility_GetLayoutProperty_mEE67E5361FD000748AE752388165CE7EE63AE984 (void);
// 0x000002B7 System.Void UnityEngine.UI.VerticalLayoutGroup::.ctor()
extern void VerticalLayoutGroup__ctor_m0824F6AE284E5B00625E4AB9B9FFBDA6BD065F1F (void);
// 0x000002B8 System.Void UnityEngine.UI.VerticalLayoutGroup::CalculateLayoutInputHorizontal()
extern void VerticalLayoutGroup_CalculateLayoutInputHorizontal_mAB31FBDFC9EC9D002B2F887F8E432CA7AAC87FD4 (void);
// 0x000002B9 System.Void UnityEngine.UI.VerticalLayoutGroup::CalculateLayoutInputVertical()
extern void VerticalLayoutGroup_CalculateLayoutInputVertical_m41DABF9935F2DD105C9C94CBD00CF9E2FC65CC90 (void);
// 0x000002BA System.Void UnityEngine.UI.VerticalLayoutGroup::SetLayoutHorizontal()
extern void VerticalLayoutGroup_SetLayoutHorizontal_mA8295CC4191B2E90A95FD75D7C214B1B47AC5820 (void);
// 0x000002BB System.Void UnityEngine.UI.VerticalLayoutGroup::SetLayoutVertical()
extern void VerticalLayoutGroup_SetLayoutVertical_m5B333E9565C45AFBF54803A67C031FEDBA8D8D8B (void);
// 0x000002BC UnityEngine.RectTransform UnityEngine.UI.Mask::get_rectTransform()
extern void Mask_get_rectTransform_m9D5D4775C23D46D7ED977FE1E00424A2E592B0FC (void);
// 0x000002BD System.Boolean UnityEngine.UI.Mask::get_showMaskGraphic()
extern void Mask_get_showMaskGraphic_m63BDFCDA0B68E7EACA1B9CCFE1BD5155EA1EEC7B (void);
// 0x000002BE System.Void UnityEngine.UI.Mask::set_showMaskGraphic(System.Boolean)
extern void Mask_set_showMaskGraphic_m90255D390C59EE8D263A71068837FB0768E998C8 (void);
// 0x000002BF UnityEngine.UI.Graphic UnityEngine.UI.Mask::get_graphic()
extern void Mask_get_graphic_m5B49E746A9E93A4D1BAAFD83F9ACB7C90633B5B3 (void);
// 0x000002C0 System.Void UnityEngine.UI.Mask::.ctor()
extern void Mask__ctor_m52B610E05764BC69F906983AB172FF23805A1D37 (void);
// 0x000002C1 System.Boolean UnityEngine.UI.Mask::MaskEnabled()
extern void Mask_MaskEnabled_mBDFFCB167E44208335DBC9334022A7228FACA69D (void);
// 0x000002C2 System.Void UnityEngine.UI.Mask::OnSiblingGraphicEnabledDisabled()
extern void Mask_OnSiblingGraphicEnabledDisabled_m8CF5123E985B83A339517C7B786D017BD59DE5EE (void);
// 0x000002C3 System.Void UnityEngine.UI.Mask::OnEnable()
extern void Mask_OnEnable_mC396891226E6853FF502F1F056790192052FF202 (void);
// 0x000002C4 System.Void UnityEngine.UI.Mask::OnDisable()
extern void Mask_OnDisable_m9ACB6854596A0A91E3990F9CE1D7C693B513A9A0 (void);
// 0x000002C5 System.Boolean UnityEngine.UI.Mask::IsRaycastLocationValid(UnityEngine.Vector2,UnityEngine.Camera)
extern void Mask_IsRaycastLocationValid_m74F62BD38E42D52E34AE0DC2654AE827D4DEF85C (void);
// 0x000002C6 UnityEngine.Material UnityEngine.UI.Mask::GetModifiedMaterial(UnityEngine.Material)
extern void Mask_GetModifiedMaterial_m708D77F5312C3DA4B3E2D5D71046393BE533DDEF (void);
// 0x000002C7 System.Void UnityEngine.UI.MaskUtilities::Notify2DMaskStateChanged(UnityEngine.Component)
extern void MaskUtilities_Notify2DMaskStateChanged_m9059BB3432994FE2C5722C579F36F6B2BAE5B3C7 (void);
// 0x000002C8 System.Void UnityEngine.UI.MaskUtilities::NotifyStencilStateChanged(UnityEngine.Component)
extern void MaskUtilities_NotifyStencilStateChanged_m939869F3BB83A2846052F702B4FB09244AC502AD (void);
// 0x000002C9 UnityEngine.Transform UnityEngine.UI.MaskUtilities::FindRootSortOverrideCanvas(UnityEngine.Transform)
extern void MaskUtilities_FindRootSortOverrideCanvas_m7E303D29D22F86212DD023C8854211C525629FDD (void);
// 0x000002CA System.Int32 UnityEngine.UI.MaskUtilities::GetStencilDepth(UnityEngine.Transform,UnityEngine.Transform)
extern void MaskUtilities_GetStencilDepth_m01EE1FFF799078024CDC40C03A4D001351B8BBB3 (void);
// 0x000002CB System.Boolean UnityEngine.UI.MaskUtilities::IsDescendantOrSelf(UnityEngine.Transform,UnityEngine.Transform)
extern void MaskUtilities_IsDescendantOrSelf_m306364287D0DE8E3760278C59272D79E226F5A73 (void);
// 0x000002CC UnityEngine.UI.RectMask2D UnityEngine.UI.MaskUtilities::GetRectMaskForClippable(UnityEngine.UI.IClippable)
extern void MaskUtilities_GetRectMaskForClippable_mA22FA75F79D98E00CF0B0A41DFBD0FC2D4DC2F28 (void);
// 0x000002CD System.Void UnityEngine.UI.MaskUtilities::GetRectMasksForClip(UnityEngine.UI.RectMask2D,System.Collections.Generic.List`1<UnityEngine.UI.RectMask2D>)
extern void MaskUtilities_GetRectMasksForClip_m0A1C0238E0CDFCA72B5E72EC24E3F9A180355585 (void);
// 0x000002CE System.Void UnityEngine.UI.MaskUtilities::.ctor()
extern void MaskUtilities__ctor_m990AF9ADD62963CBCB13EE2C6C150F27051669D9 (void);
// 0x000002CF UnityEngine.UI.MaskableGraphic/CullStateChangedEvent UnityEngine.UI.MaskableGraphic::get_onCullStateChanged()
extern void MaskableGraphic_get_onCullStateChanged_m9CF82537F28EEEC73E48B437DF49EA0B2312BDE8 (void);
// 0x000002D0 System.Void UnityEngine.UI.MaskableGraphic::set_onCullStateChanged(UnityEngine.UI.MaskableGraphic/CullStateChangedEvent)
extern void MaskableGraphic_set_onCullStateChanged_m208B9A83B85B42F2B98F454E4A2226D7EB57697B (void);
// 0x000002D1 System.Boolean UnityEngine.UI.MaskableGraphic::get_maskable()
extern void MaskableGraphic_get_maskable_mE95AFA7FF064B95334989FEE75DC2F668E250FA1 (void);
// 0x000002D2 System.Void UnityEngine.UI.MaskableGraphic::set_maskable(System.Boolean)
extern void MaskableGraphic_set_maskable_mDFB9A55F0E7F2F4B988FF4E976FAE1DD6A336A83 (void);
// 0x000002D3 System.Boolean UnityEngine.UI.MaskableGraphic::get_isMaskingGraphic()
extern void MaskableGraphic_get_isMaskingGraphic_m2876603FFD10936ADC8008154111FECCB69DC392 (void);
// 0x000002D4 System.Void UnityEngine.UI.MaskableGraphic::set_isMaskingGraphic(System.Boolean)
extern void MaskableGraphic_set_isMaskingGraphic_m2E6B1415EB6E0A0EF864752310B44F1306F429DC (void);
// 0x000002D5 UnityEngine.Material UnityEngine.UI.MaskableGraphic::GetModifiedMaterial(UnityEngine.Material)
extern void MaskableGraphic_GetModifiedMaterial_m8FCD645EF28C3D0E9C40DE6CA88C4A6FA9D1DC31 (void);
// 0x000002D6 System.Void UnityEngine.UI.MaskableGraphic::Cull(UnityEngine.Rect,System.Boolean)
extern void MaskableGraphic_Cull_m9DBCD28391A2ECF6A84FFFF39A556C340FAC2A93 (void);
// 0x000002D7 System.Void UnityEngine.UI.MaskableGraphic::UpdateCull(System.Boolean)
extern void MaskableGraphic_UpdateCull_m73323DA72DA1B3C5FE5309398FDCC286762851B5 (void);
// 0x000002D8 System.Void UnityEngine.UI.MaskableGraphic::SetClipRect(UnityEngine.Rect,System.Boolean)
extern void MaskableGraphic_SetClipRect_m55C87014B575FFF861392379718C0138AC12B3FD (void);
// 0x000002D9 System.Void UnityEngine.UI.MaskableGraphic::SetClipSoftness(UnityEngine.Vector2)
extern void MaskableGraphic_SetClipSoftness_m57E729CA63EAF90883636ACC257E687E6812484F (void);
// 0x000002DA System.Void UnityEngine.UI.MaskableGraphic::OnEnable()
extern void MaskableGraphic_OnEnable_m9F237DEB38F94621751B57A24C38B5C2B2E37343 (void);
// 0x000002DB System.Void UnityEngine.UI.MaskableGraphic::OnDisable()
extern void MaskableGraphic_OnDisable_m7082110BEF7DD61D91076319CF47E97090F70899 (void);
// 0x000002DC System.Void UnityEngine.UI.MaskableGraphic::OnTransformParentChanged()
extern void MaskableGraphic_OnTransformParentChanged_mCFFE90B41975B7BD6C21B95355FD96D92CD17C5D (void);
// 0x000002DD System.Void UnityEngine.UI.MaskableGraphic::ParentMaskStateChanged()
extern void MaskableGraphic_ParentMaskStateChanged_m9AECEF843EC50D19FC347A3C1081E07A9EFEB2F9 (void);
// 0x000002DE System.Void UnityEngine.UI.MaskableGraphic::OnCanvasHierarchyChanged()
extern void MaskableGraphic_OnCanvasHierarchyChanged_m02C468B0AD88E840778B68C780FB80B7CCD2768C (void);
// 0x000002DF UnityEngine.Rect UnityEngine.UI.MaskableGraphic::get_rootCanvasRect()
extern void MaskableGraphic_get_rootCanvasRect_m2751607479FE02BDA964AF973CDD19B62B208DA4 (void);
// 0x000002E0 System.Void UnityEngine.UI.MaskableGraphic::UpdateClipParent()
extern void MaskableGraphic_UpdateClipParent_mAB3C2401455E40700CF6FAAC0E407FB3AB0E5E80 (void);
// 0x000002E1 System.Void UnityEngine.UI.MaskableGraphic::RecalculateClipping()
extern void MaskableGraphic_RecalculateClipping_m8C757450AF711AF80F71851DB736D5377BDFEA57 (void);
// 0x000002E2 System.Void UnityEngine.UI.MaskableGraphic::RecalculateMasking()
extern void MaskableGraphic_RecalculateMasking_mDEEA7EFFC6AB605EA8FE22E5E2050DA4F46DAF38 (void);
// 0x000002E3 System.Void UnityEngine.UI.MaskableGraphic::.ctor()
extern void MaskableGraphic__ctor_mF2B16CE3752FDC9F7F96F5DE671690B4424B5AA6 (void);
// 0x000002E4 UnityEngine.GameObject UnityEngine.UI.MaskableGraphic::UnityEngine.UI.IClippable.get_gameObject()
extern void MaskableGraphic_UnityEngine_UI_IClippable_get_gameObject_m68A7FD1C35B1E5A0A1FFF135F89A62F4F1521DB8 (void);
// 0x000002E5 UnityEngine.Material UnityEngine.UI.IMaterialModifier::GetModifiedMaterial(UnityEngine.Material)
// 0x000002E6 System.Void UnityEngine.UI.Misc::Destroy(UnityEngine.Object)
extern void Misc_Destroy_m3EA2A050EE68D29509A76F1E9A25372B8627F1B3 (void);
// 0x000002E7 System.Void UnityEngine.UI.Misc::DestroyImmediate(UnityEngine.Object)
extern void Misc_DestroyImmediate_mE7D29D1E4B20D856C1CA3C18A9BF50F46FCC0213 (void);
// 0x000002E8 System.Boolean UnityEngine.UI.MultipleDisplayUtilities::GetRelativeMousePositionForDrag(UnityEngine.EventSystems.PointerEventData,UnityEngine.Vector2&)
extern void MultipleDisplayUtilities_GetRelativeMousePositionForDrag_m185231526F59A9A770E471905EFF08A693E4BDD9 (void);
// 0x000002E9 UnityEngine.Vector2 UnityEngine.UI.MultipleDisplayUtilities::GetMousePositionRelativeToMainDisplayResolution()
extern void MultipleDisplayUtilities_GetMousePositionRelativeToMainDisplayResolution_m2D3CB08174B28122E201011E77C0A1BE762C948C (void);
// 0x000002EA UnityEngine.UI.Navigation/Mode UnityEngine.UI.Navigation::get_mode()
extern void Navigation_get_mode_m3C77554140D0A56ACD06B1E6DB2D016F080FB95E (void);
// 0x000002EB System.Void UnityEngine.UI.Navigation::set_mode(UnityEngine.UI.Navigation/Mode)
extern void Navigation_set_mode_m98F00F98459C0C3D79FDC7221C779D83130D67BC (void);
// 0x000002EC UnityEngine.UI.Selectable UnityEngine.UI.Navigation::get_selectOnUp()
extern void Navigation_get_selectOnUp_m8E3A8A4358C862B402C322E93062E10F22371A0E (void);
// 0x000002ED System.Void UnityEngine.UI.Navigation::set_selectOnUp(UnityEngine.UI.Selectable)
extern void Navigation_set_selectOnUp_mDC6497A819851FC70C1771FA5B4F8DEF7BDCD552 (void);
// 0x000002EE UnityEngine.UI.Selectable UnityEngine.UI.Navigation::get_selectOnDown()
extern void Navigation_get_selectOnDown_mC9469ADD19689D5D263A39861E70E43A75BB9398 (void);
// 0x000002EF System.Void UnityEngine.UI.Navigation::set_selectOnDown(UnityEngine.UI.Selectable)
extern void Navigation_set_selectOnDown_mE97059CFEDDAA89BC14D85EA1FB51A9D3BDA4549 (void);
// 0x000002F0 UnityEngine.UI.Selectable UnityEngine.UI.Navigation::get_selectOnLeft()
extern void Navigation_get_selectOnLeft_m1B2D71E749D06A2D89855AE6715DBD253BC623FA (void);
// 0x000002F1 System.Void UnityEngine.UI.Navigation::set_selectOnLeft(UnityEngine.UI.Selectable)
extern void Navigation_set_selectOnLeft_m6C219E151D044D1C4F086A2DDD104C537553B79D (void);
// 0x000002F2 UnityEngine.UI.Selectable UnityEngine.UI.Navigation::get_selectOnRight()
extern void Navigation_get_selectOnRight_mD44071FB2CBE195EBD6EBF37437C3F5BBFA5B328 (void);
// 0x000002F3 System.Void UnityEngine.UI.Navigation::set_selectOnRight(UnityEngine.UI.Selectable)
extern void Navigation_set_selectOnRight_mEBD7DF30AC830A83DCC7F1E2BA9629864A40336E (void);
// 0x000002F4 UnityEngine.UI.Navigation UnityEngine.UI.Navigation::get_defaultNavigation()
extern void Navigation_get_defaultNavigation_m00087A1157696556EB1D34E20D7324DE4788F6C6 (void);
// 0x000002F5 System.Boolean UnityEngine.UI.Navigation::Equals(UnityEngine.UI.Navigation)
extern void Navigation_Equals_m06EE535BFA43DD09F43FB681936E6AA4112F2AE2 (void);
// 0x000002F6 System.Void UnityEngine.UI.RawImage::.ctor()
extern void RawImage__ctor_mCB80C49C5E0B500C28F4DC84142D8C38D05CAECF (void);
// 0x000002F7 UnityEngine.Texture UnityEngine.UI.RawImage::get_mainTexture()
extern void RawImage_get_mainTexture_mAC899EE3026C3BD076E21B43D840D05162F56E29 (void);
// 0x000002F8 UnityEngine.Texture UnityEngine.UI.RawImage::get_texture()
extern void RawImage_get_texture_m992AF81884D22B9ADC97A800AB931DCB4140954E (void);
// 0x000002F9 System.Void UnityEngine.UI.RawImage::set_texture(UnityEngine.Texture)
extern void RawImage_set_texture_mA09F1C8E2EBCBE1D2A06DA84BC28FB1F9ED58977 (void);
// 0x000002FA UnityEngine.Rect UnityEngine.UI.RawImage::get_uvRect()
extern void RawImage_get_uvRect_m3BE55AF17D17143B9F084B1FA4689C5A52A0F530 (void);
// 0x000002FB System.Void UnityEngine.UI.RawImage::set_uvRect(UnityEngine.Rect)
extern void RawImage_set_uvRect_m610CB870B752BA8C210F031C14C1C90F127290EB (void);
// 0x000002FC System.Void UnityEngine.UI.RawImage::SetNativeSize()
extern void RawImage_SetNativeSize_m1C1C496F24A54895367632F8B3F6232F91E892BB (void);
// 0x000002FD System.Void UnityEngine.UI.RawImage::OnPopulateMesh(UnityEngine.UI.VertexHelper)
extern void RawImage_OnPopulateMesh_m4CCF9546E0927627FCFD69922991DE112B6CB78E (void);
// 0x000002FE System.Void UnityEngine.UI.RawImage::OnDidApplyAnimationProperties()
extern void RawImage_OnDidApplyAnimationProperties_m608D10EE69EB99AB30C1F3DC456432A723EE39A9 (void);
// 0x000002FF UnityEngine.Vector4 UnityEngine.UI.RectMask2D::get_padding()
extern void RectMask2D_get_padding_mAE70AF9C0ABD28AD225A2BFD4965C45883B31E20 (void);
// 0x00000300 System.Void UnityEngine.UI.RectMask2D::set_padding(UnityEngine.Vector4)
extern void RectMask2D_set_padding_mC54939B5E146796EC0EC33626CBF8308F3125238 (void);
// 0x00000301 UnityEngine.Vector2Int UnityEngine.UI.RectMask2D::get_softness()
extern void RectMask2D_get_softness_m67F6E132A98566FC2191856462BAB6F7080884C8 (void);
// 0x00000302 System.Void UnityEngine.UI.RectMask2D::set_softness(UnityEngine.Vector2Int)
extern void RectMask2D_set_softness_mF808AE93A3A5C10682C0CEC9B9A5F3588BD693C6 (void);
// 0x00000303 UnityEngine.Canvas UnityEngine.UI.RectMask2D::get_Canvas()
extern void RectMask2D_get_Canvas_m67059D0D1FF1530F8AA8B5D94F1A27D559C25C41 (void);
// 0x00000304 UnityEngine.Rect UnityEngine.UI.RectMask2D::get_canvasRect()
extern void RectMask2D_get_canvasRect_m2CFEAC92FBAE3C1E500CAD0BDB3D6CDD263558BA (void);
// 0x00000305 UnityEngine.RectTransform UnityEngine.UI.RectMask2D::get_rectTransform()
extern void RectMask2D_get_rectTransform_m2EE1645888FCF5638B9B59EE4087B96FB53574AC (void);
// 0x00000306 System.Void UnityEngine.UI.RectMask2D::.ctor()
extern void RectMask2D__ctor_m64686F359A4948A90D18A825147A4FE1B4FFD9E0 (void);
// 0x00000307 System.Void UnityEngine.UI.RectMask2D::OnEnable()
extern void RectMask2D_OnEnable_m7B52E866806641669DD09B0D13CB4BBE1E1E250B (void);
// 0x00000308 System.Void UnityEngine.UI.RectMask2D::OnDisable()
extern void RectMask2D_OnDisable_m87883543DA7D4BE685C7306493BA9D26EA72553C (void);
// 0x00000309 System.Boolean UnityEngine.UI.RectMask2D::IsRaycastLocationValid(UnityEngine.Vector2,UnityEngine.Camera)
extern void RectMask2D_IsRaycastLocationValid_m4CF23859DFFCAC7387F1CB0BBD539C2C6EED9FE9 (void);
// 0x0000030A UnityEngine.Rect UnityEngine.UI.RectMask2D::get_rootCanvasRect()
extern void RectMask2D_get_rootCanvasRect_m17D93FBA715A10CB270CE52C794B1FB687DD5431 (void);
// 0x0000030B System.Void UnityEngine.UI.RectMask2D::PerformClipping()
extern void RectMask2D_PerformClipping_m91BF3957B8A63187689F2A89E6098B3071E4BF7D (void);
// 0x0000030C System.Void UnityEngine.UI.RectMask2D::UpdateClipSoftness()
extern void RectMask2D_UpdateClipSoftness_mF53422C7C57EE1904720E5A3E1758B66A218C375 (void);
// 0x0000030D System.Void UnityEngine.UI.RectMask2D::AddClippable(UnityEngine.UI.IClippable)
extern void RectMask2D_AddClippable_m929A0090BDFD39B38611AB64E3057D57F61FCE60 (void);
// 0x0000030E System.Void UnityEngine.UI.RectMask2D::RemoveClippable(UnityEngine.UI.IClippable)
extern void RectMask2D_RemoveClippable_mBB177F8B9F4C654604A627F17A28432B667100F1 (void);
// 0x0000030F System.Void UnityEngine.UI.RectMask2D::OnTransformParentChanged()
extern void RectMask2D_OnTransformParentChanged_mF3A127BFCDBC923F54F0CD416BA9365595023A12 (void);
// 0x00000310 System.Void UnityEngine.UI.RectMask2D::OnCanvasHierarchyChanged()
extern void RectMask2D_OnCanvasHierarchyChanged_mF5D924FA85A0890DCB73251CEBAE4A4C83DFE38E (void);
// 0x00000311 UnityEngine.RectTransform UnityEngine.UI.ScrollRect::get_content()
extern void ScrollRect_get_content_m7F3FC07991CE67DFBEE4068D6E14ED0A1E26B526 (void);
// 0x00000312 System.Void UnityEngine.UI.ScrollRect::set_content(UnityEngine.RectTransform)
extern void ScrollRect_set_content_mCCF04D1FE05A6EE7DB578FA797DD668C79F05373 (void);
// 0x00000313 System.Boolean UnityEngine.UI.ScrollRect::get_horizontal()
extern void ScrollRect_get_horizontal_m77D2BE93F6B45D023B56967D39329DB8F8892BB2 (void);
// 0x00000314 System.Void UnityEngine.UI.ScrollRect::set_horizontal(System.Boolean)
extern void ScrollRect_set_horizontal_mE171242DA7E88CFA23CFD1867ABCF02408BAE630 (void);
// 0x00000315 System.Boolean UnityEngine.UI.ScrollRect::get_vertical()
extern void ScrollRect_get_vertical_m643EEEF2FD8D01EA5BAA2378FF7E32BEC896B273 (void);
// 0x00000316 System.Void UnityEngine.UI.ScrollRect::set_vertical(System.Boolean)
extern void ScrollRect_set_vertical_mC57B4C207ACDBDBB31F81E765DF3E4991FDC2C3C (void);
// 0x00000317 UnityEngine.UI.ScrollRect/MovementType UnityEngine.UI.ScrollRect::get_movementType()
extern void ScrollRect_get_movementType_m96D7F76863CD4288A6E36481A9ED3028EA37CFFC (void);
// 0x00000318 System.Void UnityEngine.UI.ScrollRect::set_movementType(UnityEngine.UI.ScrollRect/MovementType)
extern void ScrollRect_set_movementType_m5DC0E885A97CE2CE998AAF32B21BA0E5F0872375 (void);
// 0x00000319 System.Single UnityEngine.UI.ScrollRect::get_elasticity()
extern void ScrollRect_get_elasticity_mCC6354C1CEB5F288516571252CDA821B82969C95 (void);
// 0x0000031A System.Void UnityEngine.UI.ScrollRect::set_elasticity(System.Single)
extern void ScrollRect_set_elasticity_m74BC808E94C6CD5AA54BF1AAA5E835E35A025953 (void);
// 0x0000031B System.Boolean UnityEngine.UI.ScrollRect::get_inertia()
extern void ScrollRect_get_inertia_mD2DF80F45E405D5AB4D764FE9D6A8A7A73266468 (void);
// 0x0000031C System.Void UnityEngine.UI.ScrollRect::set_inertia(System.Boolean)
extern void ScrollRect_set_inertia_m77F6FBC5E117250CDD4588076E7795545235ECFD (void);
// 0x0000031D System.Single UnityEngine.UI.ScrollRect::get_decelerationRate()
extern void ScrollRect_get_decelerationRate_m4033B0B9663384FCE4AE291DFA3337803D3FEDBF (void);
// 0x0000031E System.Void UnityEngine.UI.ScrollRect::set_decelerationRate(System.Single)
extern void ScrollRect_set_decelerationRate_mD6F9A2957861F11D6D8159CB86E3E95155417617 (void);
// 0x0000031F System.Single UnityEngine.UI.ScrollRect::get_scrollSensitivity()
extern void ScrollRect_get_scrollSensitivity_m706C7F4633E2A4B816DA0423821E0716A73BADD0 (void);
// 0x00000320 System.Void UnityEngine.UI.ScrollRect::set_scrollSensitivity(System.Single)
extern void ScrollRect_set_scrollSensitivity_mA1A29A5B0DDC4E7A9CC25F871D0D962CAC85997E (void);
// 0x00000321 UnityEngine.RectTransform UnityEngine.UI.ScrollRect::get_viewport()
extern void ScrollRect_get_viewport_mD3C6CD4F782A5FC7F886BA1CC4DB6CF250DF164D (void);
// 0x00000322 System.Void UnityEngine.UI.ScrollRect::set_viewport(UnityEngine.RectTransform)
extern void ScrollRect_set_viewport_m445D1D8568F23E4F14BF524A7C3D06AC8C779DBF (void);
// 0x00000323 UnityEngine.UI.Scrollbar UnityEngine.UI.ScrollRect::get_horizontalScrollbar()
extern void ScrollRect_get_horizontalScrollbar_m258E5BA6988FD113301575E1107A37D506515273 (void);
// 0x00000324 System.Void UnityEngine.UI.ScrollRect::set_horizontalScrollbar(UnityEngine.UI.Scrollbar)
extern void ScrollRect_set_horizontalScrollbar_mB61F6C8B7878EAFCB4AF0EC5D1E42E1A14F8B438 (void);
// 0x00000325 UnityEngine.UI.Scrollbar UnityEngine.UI.ScrollRect::get_verticalScrollbar()
extern void ScrollRect_get_verticalScrollbar_m0A9EBD87C90FBC567C11D37ECEBD2E6A7218BD0E (void);
// 0x00000326 System.Void UnityEngine.UI.ScrollRect::set_verticalScrollbar(UnityEngine.UI.Scrollbar)
extern void ScrollRect_set_verticalScrollbar_m8FBFA26D8764A67595C2A051E9F3EC96359AD587 (void);
// 0x00000327 UnityEngine.UI.ScrollRect/ScrollbarVisibility UnityEngine.UI.ScrollRect::get_horizontalScrollbarVisibility()
extern void ScrollRect_get_horizontalScrollbarVisibility_mC43D0E4908D8876D399B15F36A8D98B827C77DDC (void);
// 0x00000328 System.Void UnityEngine.UI.ScrollRect::set_horizontalScrollbarVisibility(UnityEngine.UI.ScrollRect/ScrollbarVisibility)
extern void ScrollRect_set_horizontalScrollbarVisibility_mC9B69627EE6A64877864E77485E27773EB855DF6 (void);
// 0x00000329 UnityEngine.UI.ScrollRect/ScrollbarVisibility UnityEngine.UI.ScrollRect::get_verticalScrollbarVisibility()
extern void ScrollRect_get_verticalScrollbarVisibility_m8D671BA3821D2F3F263DAC0C7FE1487333326DA9 (void);
// 0x0000032A System.Void UnityEngine.UI.ScrollRect::set_verticalScrollbarVisibility(UnityEngine.UI.ScrollRect/ScrollbarVisibility)
extern void ScrollRect_set_verticalScrollbarVisibility_m04378E56059A4C84FC9B210F79C2E6FF7A507E12 (void);
// 0x0000032B System.Single UnityEngine.UI.ScrollRect::get_horizontalScrollbarSpacing()
extern void ScrollRect_get_horizontalScrollbarSpacing_m12F0D7366D9FEE8B2E886ABFBE35663A43427AC7 (void);
// 0x0000032C System.Void UnityEngine.UI.ScrollRect::set_horizontalScrollbarSpacing(System.Single)
extern void ScrollRect_set_horizontalScrollbarSpacing_m0ECCC684AE9E391D854C6C2B5B695277F065A2D3 (void);
// 0x0000032D System.Single UnityEngine.UI.ScrollRect::get_verticalScrollbarSpacing()
extern void ScrollRect_get_verticalScrollbarSpacing_m99467BCEA6A514E4410693AE44644E7035A2FD17 (void);
// 0x0000032E System.Void UnityEngine.UI.ScrollRect::set_verticalScrollbarSpacing(System.Single)
extern void ScrollRect_set_verticalScrollbarSpacing_mD3E2AFC566836F6FA7C216D628044D5B46BFB13B (void);
// 0x0000032F UnityEngine.UI.ScrollRect/ScrollRectEvent UnityEngine.UI.ScrollRect::get_onValueChanged()
extern void ScrollRect_get_onValueChanged_mB59CCC8D8CD14BEB23018EDEE69EDB1EEE32C08B (void);
// 0x00000330 System.Void UnityEngine.UI.ScrollRect::set_onValueChanged(UnityEngine.UI.ScrollRect/ScrollRectEvent)
extern void ScrollRect_set_onValueChanged_mAF07F0AB9982FFDD4426A9E50586DA137EC5DCFD (void);
// 0x00000331 UnityEngine.RectTransform UnityEngine.UI.ScrollRect::get_viewRect()
extern void ScrollRect_get_viewRect_m4CAAF3A523BAB284A6DA9D5EC45057D7EE51D89A (void);
// 0x00000332 UnityEngine.Vector2 UnityEngine.UI.ScrollRect::get_velocity()
extern void ScrollRect_get_velocity_m44CA563C38ED997693167D354904EF8139C0C9D9 (void);
// 0x00000333 System.Void UnityEngine.UI.ScrollRect::set_velocity(UnityEngine.Vector2)
extern void ScrollRect_set_velocity_mEC9426341841F20D3CDD799B8C665BCFD34B4074 (void);
// 0x00000334 UnityEngine.RectTransform UnityEngine.UI.ScrollRect::get_rectTransform()
extern void ScrollRect_get_rectTransform_m8DB7B0810D6E5D34C973716FCAC50C5B259DA3FE (void);
// 0x00000335 System.Void UnityEngine.UI.ScrollRect::.ctor()
extern void ScrollRect__ctor_mDD61FF33C47DCA8A928240008EFAD4F0B5D007F9 (void);
// 0x00000336 System.Void UnityEngine.UI.ScrollRect::Rebuild(UnityEngine.UI.CanvasUpdate)
extern void ScrollRect_Rebuild_m267BB5221243C163733957AE0B85FB3E99650FE9 (void);
// 0x00000337 System.Void UnityEngine.UI.ScrollRect::LayoutComplete()
extern void ScrollRect_LayoutComplete_mE14EE1A24AED1CB6F1713AE01524E6DFD713F6BE (void);
// 0x00000338 System.Void UnityEngine.UI.ScrollRect::GraphicUpdateComplete()
extern void ScrollRect_GraphicUpdateComplete_mE3AF45EC2A4BE612AEA5DC3353F3A2F5F50BAE21 (void);
// 0x00000339 System.Void UnityEngine.UI.ScrollRect::UpdateCachedData()
extern void ScrollRect_UpdateCachedData_m1D16AA0BC08EC0314233C5FC5A5765CA9D34AEC1 (void);
// 0x0000033A System.Void UnityEngine.UI.ScrollRect::OnEnable()
extern void ScrollRect_OnEnable_mAFB147D41D660C2A29662E579C75179F10AC88E6 (void);
// 0x0000033B System.Void UnityEngine.UI.ScrollRect::OnDisable()
extern void ScrollRect_OnDisable_m295590E40366286628DCE780F3A96AA1E1AFEE1A (void);
// 0x0000033C System.Boolean UnityEngine.UI.ScrollRect::IsActive()
extern void ScrollRect_IsActive_m3999CA1C8943A53FC6CA52DD9162FAEE0CFD3F2E (void);
// 0x0000033D System.Void UnityEngine.UI.ScrollRect::EnsureLayoutHasRebuilt()
extern void ScrollRect_EnsureLayoutHasRebuilt_m2483FBE8BDAFB07D4FC6312210C6BBB9841ED68C (void);
// 0x0000033E System.Void UnityEngine.UI.ScrollRect::StopMovement()
extern void ScrollRect_StopMovement_m07CCEE2EFE71B691CB220DD4E425EEF021659CC3 (void);
// 0x0000033F System.Void UnityEngine.UI.ScrollRect::OnScroll(UnityEngine.EventSystems.PointerEventData)
extern void ScrollRect_OnScroll_m08CFC24A7066E0CF03716F7EA75EB54DEDF4D66E (void);
// 0x00000340 System.Void UnityEngine.UI.ScrollRect::OnInitializePotentialDrag(UnityEngine.EventSystems.PointerEventData)
extern void ScrollRect_OnInitializePotentialDrag_m913BEBD7F84C7E4161E28DB12051CBD2C9D5982B (void);
// 0x00000341 System.Void UnityEngine.UI.ScrollRect::OnBeginDrag(UnityEngine.EventSystems.PointerEventData)
extern void ScrollRect_OnBeginDrag_m192E58D2BA90D243B35938EF500DD56B2530FAB9 (void);
// 0x00000342 System.Void UnityEngine.UI.ScrollRect::OnEndDrag(UnityEngine.EventSystems.PointerEventData)
extern void ScrollRect_OnEndDrag_mD2CE3B2FB607F557033834F06B68B428B8F2379D (void);
// 0x00000343 System.Void UnityEngine.UI.ScrollRect::OnDrag(UnityEngine.EventSystems.PointerEventData)
extern void ScrollRect_OnDrag_m85965B899737B02EA82060F24F935E75DC6C697B (void);
// 0x00000344 System.Void UnityEngine.UI.ScrollRect::SetContentAnchoredPosition(UnityEngine.Vector2)
extern void ScrollRect_SetContentAnchoredPosition_m076F4C2F727C2C6B7F7280F320A2E8D47CD3EBA4 (void);
// 0x00000345 System.Void UnityEngine.UI.ScrollRect::LateUpdate()
extern void ScrollRect_LateUpdate_mD0338F8F0C9BDB6ED9A77936E9B842CE4C3AFED8 (void);
// 0x00000346 System.Void UnityEngine.UI.ScrollRect::UpdatePrevData()
extern void ScrollRect_UpdatePrevData_mF1F5F118359BA01F88039771EACA41DFE383F688 (void);
// 0x00000347 System.Void UnityEngine.UI.ScrollRect::UpdateScrollbars(UnityEngine.Vector2)
extern void ScrollRect_UpdateScrollbars_m497591E45E477F64ED044191EE3DB0FF13E3A282 (void);
// 0x00000348 UnityEngine.Vector2 UnityEngine.UI.ScrollRect::get_normalizedPosition()
extern void ScrollRect_get_normalizedPosition_m064ABEFDFBCD4B9E01A01A9802297827AA5C8B5E (void);
// 0x00000349 System.Void UnityEngine.UI.ScrollRect::set_normalizedPosition(UnityEngine.Vector2)
extern void ScrollRect_set_normalizedPosition_mD0152A9B4137D325360590E987023103B90A2884 (void);
// 0x0000034A System.Single UnityEngine.UI.ScrollRect::get_horizontalNormalizedPosition()
extern void ScrollRect_get_horizontalNormalizedPosition_m959E56CFCAFE7569A2C3E5163F28B336C442C26F (void);
// 0x0000034B System.Void UnityEngine.UI.ScrollRect::set_horizontalNormalizedPosition(System.Single)
extern void ScrollRect_set_horizontalNormalizedPosition_mDD8430131CF4AF2D89BD823258D109DE85049C07 (void);
// 0x0000034C System.Single UnityEngine.UI.ScrollRect::get_verticalNormalizedPosition()
extern void ScrollRect_get_verticalNormalizedPosition_mAF207C4C8888284A5C767D746FCD1274804575AB (void);
// 0x0000034D System.Void UnityEngine.UI.ScrollRect::set_verticalNormalizedPosition(System.Single)
extern void ScrollRect_set_verticalNormalizedPosition_mA0A9AA1AFAC02ED26392F47D1BC33A488065C54D (void);
// 0x0000034E System.Void UnityEngine.UI.ScrollRect::SetHorizontalNormalizedPosition(System.Single)
extern void ScrollRect_SetHorizontalNormalizedPosition_mF920FF30350B829DDDECFCDB1390C35468349556 (void);
// 0x0000034F System.Void UnityEngine.UI.ScrollRect::SetVerticalNormalizedPosition(System.Single)
extern void ScrollRect_SetVerticalNormalizedPosition_mCEBF9D425E8437747800A215A77DE3DD51D1F96F (void);
// 0x00000350 System.Void UnityEngine.UI.ScrollRect::SetNormalizedPosition(System.Single,System.Int32)
extern void ScrollRect_SetNormalizedPosition_m0B931F68C9F72AADDC2D83399AD9FC4BBF1E56B9 (void);
// 0x00000351 System.Single UnityEngine.UI.ScrollRect::RubberDelta(System.Single,System.Single)
extern void ScrollRect_RubberDelta_mE509E9E109D99815A0DA8F33743E5D6D6B4E6A50 (void);
// 0x00000352 System.Void UnityEngine.UI.ScrollRect::OnRectTransformDimensionsChange()
extern void ScrollRect_OnRectTransformDimensionsChange_m361C33901A72D7013A4D3A6C2867035FD3A26197 (void);
// 0x00000353 System.Boolean UnityEngine.UI.ScrollRect::get_hScrollingNeeded()
extern void ScrollRect_get_hScrollingNeeded_mEFE7764508480F49A1309DC875A322DDDD8FAC38 (void);
// 0x00000354 System.Boolean UnityEngine.UI.ScrollRect::get_vScrollingNeeded()
extern void ScrollRect_get_vScrollingNeeded_mA8735A2355F5367934E394121E40BAED0BBF85CB (void);
// 0x00000355 System.Void UnityEngine.UI.ScrollRect::CalculateLayoutInputHorizontal()
extern void ScrollRect_CalculateLayoutInputHorizontal_mEDAD4A0AA8B1A774B19251979A0BF3400BE50CD6 (void);
// 0x00000356 System.Void UnityEngine.UI.ScrollRect::CalculateLayoutInputVertical()
extern void ScrollRect_CalculateLayoutInputVertical_m624C98DEBA5E3460709A3B26BB1BD03F71169634 (void);
// 0x00000357 System.Single UnityEngine.UI.ScrollRect::get_minWidth()
extern void ScrollRect_get_minWidth_mA267D28170303672F3399D2A96A1DFDB714D4170 (void);
// 0x00000358 System.Single UnityEngine.UI.ScrollRect::get_preferredWidth()
extern void ScrollRect_get_preferredWidth_mF3644DD1214DF90155D8F4D6821DABC0A017D38C (void);
// 0x00000359 System.Single UnityEngine.UI.ScrollRect::get_flexibleWidth()
extern void ScrollRect_get_flexibleWidth_mB580A06FB49CFF43AB6523219D59E2D327031457 (void);
// 0x0000035A System.Single UnityEngine.UI.ScrollRect::get_minHeight()
extern void ScrollRect_get_minHeight_m43301B9C935C4F2B449F21F417D11EC078875C6D (void);
// 0x0000035B System.Single UnityEngine.UI.ScrollRect::get_preferredHeight()
extern void ScrollRect_get_preferredHeight_m7FA20C8592B368AC8312343BF0A30458D47F15D0 (void);
// 0x0000035C System.Single UnityEngine.UI.ScrollRect::get_flexibleHeight()
extern void ScrollRect_get_flexibleHeight_mA707884F08E849377677DD1CDE0E8A10CCA19A33 (void);
// 0x0000035D System.Int32 UnityEngine.UI.ScrollRect::get_layoutPriority()
extern void ScrollRect_get_layoutPriority_m9E8FAA08BBABB9A2D8D6C3A49A564E1DCE877666 (void);
// 0x0000035E System.Void UnityEngine.UI.ScrollRect::SetLayoutHorizontal()
extern void ScrollRect_SetLayoutHorizontal_m5661A30C05FE721AF1920780D0F5D3F475997C25 (void);
// 0x0000035F System.Void UnityEngine.UI.ScrollRect::SetLayoutVertical()
extern void ScrollRect_SetLayoutVertical_mB30C93AE3867BF3B3B9351344619FF311CBBEFB1 (void);
// 0x00000360 System.Void UnityEngine.UI.ScrollRect::UpdateScrollbarVisibility()
extern void ScrollRect_UpdateScrollbarVisibility_m047CCDE29A8A95C181EEE47AB8DDB6D9B9D0589C (void);
// 0x00000361 System.Void UnityEngine.UI.ScrollRect::UpdateOneScrollbarVisibility(System.Boolean,System.Boolean,UnityEngine.UI.ScrollRect/ScrollbarVisibility,UnityEngine.UI.Scrollbar)
extern void ScrollRect_UpdateOneScrollbarVisibility_mA9F384AB871F06911CB76D8EE056A8AC7C633343 (void);
// 0x00000362 System.Void UnityEngine.UI.ScrollRect::UpdateScrollbarLayout()
extern void ScrollRect_UpdateScrollbarLayout_mE84D1885FD9FD5A61CD83A2332E1ADAB6244B9E2 (void);
// 0x00000363 System.Void UnityEngine.UI.ScrollRect::UpdateBounds()
extern void ScrollRect_UpdateBounds_mA6F591EEFAA6000373EA6879A756A0C6F8C1976D (void);
// 0x00000364 System.Void UnityEngine.UI.ScrollRect::AdjustBounds(UnityEngine.Bounds&,UnityEngine.Vector2&,UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void ScrollRect_AdjustBounds_mAA4402E720AEC7EB8FC9282AD89888E4C3866E9C (void);
// 0x00000365 UnityEngine.Bounds UnityEngine.UI.ScrollRect::GetBounds()
extern void ScrollRect_GetBounds_m4E34C67E606612B3B541AC10CABD1A8DD60BFB51 (void);
// 0x00000366 UnityEngine.Bounds UnityEngine.UI.ScrollRect::InternalGetBounds(UnityEngine.Vector3[],UnityEngine.Matrix4x4&)
extern void ScrollRect_InternalGetBounds_m57F907604A74BB8C930F0E8E83643B58B4F70EF4 (void);
// 0x00000367 UnityEngine.Vector2 UnityEngine.UI.ScrollRect::CalculateOffset(UnityEngine.Vector2)
extern void ScrollRect_CalculateOffset_m198A2DD190E762F54FFDF9ADB4F9D09C3C72C49D (void);
// 0x00000368 UnityEngine.Vector2 UnityEngine.UI.ScrollRect::InternalCalculateOffset(UnityEngine.Bounds&,UnityEngine.Bounds&,System.Boolean,System.Boolean,UnityEngine.UI.ScrollRect/MovementType,UnityEngine.Vector2&)
extern void ScrollRect_InternalCalculateOffset_mB96285CE22E7699375AF4A02B612794774262AB4 (void);
// 0x00000369 System.Void UnityEngine.UI.ScrollRect::SetDirty()
extern void ScrollRect_SetDirty_m658BB2DDBC1B094D7554F0F799C64C92051AE709 (void);
// 0x0000036A System.Void UnityEngine.UI.ScrollRect::SetDirtyCaching()
extern void ScrollRect_SetDirtyCaching_m4CDF1D381FD4358E9399A1B8951B7BC5E6A83283 (void);
// 0x0000036B UnityEngine.Transform UnityEngine.UI.ScrollRect::UnityEngine.UI.ICanvasElement.get_transform()
extern void ScrollRect_UnityEngine_UI_ICanvasElement_get_transform_m5BCD58D5BF9AF3D8FB743417F783A815344B38B0 (void);
// 0x0000036C UnityEngine.RectTransform UnityEngine.UI.Scrollbar::get_handleRect()
extern void Scrollbar_get_handleRect_m104FE0AF1CA77701926B9247530BBDE16CD03421 (void);
// 0x0000036D System.Void UnityEngine.UI.Scrollbar::set_handleRect(UnityEngine.RectTransform)
extern void Scrollbar_set_handleRect_m7AB0A8D449A11E4F2CE86DAB09E7352D04C00EE9 (void);
// 0x0000036E UnityEngine.UI.Scrollbar/Direction UnityEngine.UI.Scrollbar::get_direction()
extern void Scrollbar_get_direction_m9DE22D72DE14200D3B7F70410865872034DB3C26 (void);
// 0x0000036F System.Void UnityEngine.UI.Scrollbar::set_direction(UnityEngine.UI.Scrollbar/Direction)
extern void Scrollbar_set_direction_mAD47D121E56813030F0CCAC88FB12468624A2B25 (void);
// 0x00000370 System.Void UnityEngine.UI.Scrollbar::.ctor()
extern void Scrollbar__ctor_mF899CAEC1EA445CFBE93142D08B7DDE294A394BE (void);
// 0x00000371 System.Single UnityEngine.UI.Scrollbar::get_value()
extern void Scrollbar_get_value_m96DA69C1452450B3BFCD269836BE9F1F396642ED (void);
// 0x00000372 System.Void UnityEngine.UI.Scrollbar::set_value(System.Single)
extern void Scrollbar_set_value_m8A103799361CED9ACECFFAF853C68D9E0D243DC8 (void);
// 0x00000373 System.Void UnityEngine.UI.Scrollbar::SetValueWithoutNotify(System.Single)
extern void Scrollbar_SetValueWithoutNotify_mFA921565D87E028FFECBE8A9421BD50F8789B82E (void);
// 0x00000374 System.Single UnityEngine.UI.Scrollbar::get_size()
extern void Scrollbar_get_size_mBAE39F739D8E11802B84BFDC04AF6BD9E10168FB (void);
// 0x00000375 System.Void UnityEngine.UI.Scrollbar::set_size(System.Single)
extern void Scrollbar_set_size_mA94BF8336B8F6C4809982100D33BF1680E07340A (void);
// 0x00000376 System.Int32 UnityEngine.UI.Scrollbar::get_numberOfSteps()
extern void Scrollbar_get_numberOfSteps_m6A4DFE194F885E38CBD60C633882CC0D0818C21E (void);
// 0x00000377 System.Void UnityEngine.UI.Scrollbar::set_numberOfSteps(System.Int32)
extern void Scrollbar_set_numberOfSteps_m44C345A60D892B318BDF22076D22DE7F45B550A5 (void);
// 0x00000378 UnityEngine.UI.Scrollbar/ScrollEvent UnityEngine.UI.Scrollbar::get_onValueChanged()
extern void Scrollbar_get_onValueChanged_mC58EA55182B24E42CEBC360FBA3F0533B3CF0FF8 (void);
// 0x00000379 System.Void UnityEngine.UI.Scrollbar::set_onValueChanged(UnityEngine.UI.Scrollbar/ScrollEvent)
extern void Scrollbar_set_onValueChanged_m9A0A5750096730E93E55B5BF7BF4BB1AF77A8314 (void);
// 0x0000037A System.Single UnityEngine.UI.Scrollbar::get_stepSize()
extern void Scrollbar_get_stepSize_mCEAB36BF3B7DB02E28BE1F044B3116767D1F678F (void);
// 0x0000037B System.Void UnityEngine.UI.Scrollbar::Rebuild(UnityEngine.UI.CanvasUpdate)
extern void Scrollbar_Rebuild_m2F2C370CBADB47225372A7DA2B7AAFE320AF839D (void);
// 0x0000037C System.Void UnityEngine.UI.Scrollbar::LayoutComplete()
extern void Scrollbar_LayoutComplete_m0F182E65D4A7E689D82FB8B807FF6D04CA87889F (void);
// 0x0000037D System.Void UnityEngine.UI.Scrollbar::GraphicUpdateComplete()
extern void Scrollbar_GraphicUpdateComplete_m4504E7FA7C8FFDAB250C78FD1121F6093AD8FAE0 (void);
// 0x0000037E System.Void UnityEngine.UI.Scrollbar::OnEnable()
extern void Scrollbar_OnEnable_m7632B6295FE24FB5489CFEEBCDF4AF6109AD01A4 (void);
// 0x0000037F System.Void UnityEngine.UI.Scrollbar::OnDisable()
extern void Scrollbar_OnDisable_m5C653E01256FB6253109072F879604EB7BA53B19 (void);
// 0x00000380 System.Void UnityEngine.UI.Scrollbar::Update()
extern void Scrollbar_Update_m22C117DBA8474791D2772F87AD56E872753F4A55 (void);
// 0x00000381 System.Void UnityEngine.UI.Scrollbar::UpdateCachedReferences()
extern void Scrollbar_UpdateCachedReferences_m4676B3AFD6D448508A7388AD4EC43E54709127AC (void);
// 0x00000382 System.Void UnityEngine.UI.Scrollbar::Set(System.Single,System.Boolean)
extern void Scrollbar_Set_m597C78A582A3786A25765F81CFEDCBFA5261C506 (void);
// 0x00000383 System.Void UnityEngine.UI.Scrollbar::OnRectTransformDimensionsChange()
extern void Scrollbar_OnRectTransformDimensionsChange_m5BE96046811DD03D777703D7306718366794FC40 (void);
// 0x00000384 UnityEngine.UI.Scrollbar/Axis UnityEngine.UI.Scrollbar::get_axis()
extern void Scrollbar_get_axis_m45122AD4E1A73A6555181B4A6A9C86DE2EE07EE3 (void);
// 0x00000385 System.Boolean UnityEngine.UI.Scrollbar::get_reverseValue()
extern void Scrollbar_get_reverseValue_mA71942063142A7A250D755D8179CBBFE355D84B4 (void);
// 0x00000386 System.Void UnityEngine.UI.Scrollbar::UpdateVisuals()
extern void Scrollbar_UpdateVisuals_m21FB151B8BBCEC58345DAC492639EF4AFFB2AD09 (void);
// 0x00000387 System.Void UnityEngine.UI.Scrollbar::UpdateDrag(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_UpdateDrag_mF199AC7C5D77295535B35D0C6FB3DCEA66E13B1C (void);
// 0x00000388 System.Void UnityEngine.UI.Scrollbar::DoUpdateDrag(UnityEngine.Vector2,System.Single)
extern void Scrollbar_DoUpdateDrag_m7158863F17F6C85F8B6F09096E7A39B6D806FA52 (void);
// 0x00000389 System.Boolean UnityEngine.UI.Scrollbar::MayDrag(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_MayDrag_mFB01E597C203C999B4DDF6AD4C9E0E703B2F6B09 (void);
// 0x0000038A System.Void UnityEngine.UI.Scrollbar::OnBeginDrag(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_OnBeginDrag_m3B76D8C6F5845106DEDBF22E50C08391387424D5 (void);
// 0x0000038B System.Void UnityEngine.UI.Scrollbar::OnDrag(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_OnDrag_mC88986297DC288FB4B2E463E75EBA59F98DF1E7B (void);
// 0x0000038C System.Void UnityEngine.UI.Scrollbar::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_OnPointerDown_m8412C431E9FEBA656505F4C906C5FEA73C7D9E8A (void);
// 0x0000038D System.Collections.IEnumerator UnityEngine.UI.Scrollbar::ClickRepeat(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_ClickRepeat_mDC154D3144E7BF8C44CA99EF8BC8CD4C8E56F60D (void);
// 0x0000038E System.Collections.IEnumerator UnityEngine.UI.Scrollbar::ClickRepeat(UnityEngine.Vector2,UnityEngine.Camera)
extern void Scrollbar_ClickRepeat_m76E29E37C680B8A5633C9AAB8581CAEEDD83AA11 (void);
// 0x0000038F System.Void UnityEngine.UI.Scrollbar::OnPointerUp(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_OnPointerUp_mCD49D3A5F456198389E204C50CE3C36EA5960E5A (void);
// 0x00000390 System.Void UnityEngine.UI.Scrollbar::OnMove(UnityEngine.EventSystems.AxisEventData)
extern void Scrollbar_OnMove_m1249139D24A32892FCDABBF6ADD2E0BE2CD7C6A4 (void);
// 0x00000391 UnityEngine.UI.Selectable UnityEngine.UI.Scrollbar::FindSelectableOnLeft()
extern void Scrollbar_FindSelectableOnLeft_m374B5705442CC40C149835019C9EAB55C079F6BB (void);
// 0x00000392 UnityEngine.UI.Selectable UnityEngine.UI.Scrollbar::FindSelectableOnRight()
extern void Scrollbar_FindSelectableOnRight_mC2CAC3EB7EA1FC16155EF3E90B6E088B5E09FD5B (void);
// 0x00000393 UnityEngine.UI.Selectable UnityEngine.UI.Scrollbar::FindSelectableOnUp()
extern void Scrollbar_FindSelectableOnUp_m9ADBB11544C5D9D09414A397C4B22B19E60C252F (void);
// 0x00000394 UnityEngine.UI.Selectable UnityEngine.UI.Scrollbar::FindSelectableOnDown()
extern void Scrollbar_FindSelectableOnDown_m3A2776AE65F7CDFE6F3AF88B607F06A39B35C7D2 (void);
// 0x00000395 System.Void UnityEngine.UI.Scrollbar::OnInitializePotentialDrag(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_OnInitializePotentialDrag_m293B574719705C39D4D3E61CDBF367795015DB6E (void);
// 0x00000396 System.Void UnityEngine.UI.Scrollbar::SetDirection(UnityEngine.UI.Scrollbar/Direction,System.Boolean)
extern void Scrollbar_SetDirection_m04E971B5F25701C119EE60595560A5A821BEDB80 (void);
// 0x00000397 UnityEngine.Transform UnityEngine.UI.Scrollbar::UnityEngine.UI.ICanvasElement.get_transform()
extern void Scrollbar_UnityEngine_UI_ICanvasElement_get_transform_m582D531E9319A901C4C02AB8BE873C0F286AAC11 (void);
// 0x00000398 UnityEngine.UI.Selectable[] UnityEngine.UI.Selectable::get_allSelectablesArray()
extern void Selectable_get_allSelectablesArray_m04E41DC3D73950382018953096CCCB4666D75D78 (void);
// 0x00000399 System.Int32 UnityEngine.UI.Selectable::get_allSelectableCount()
extern void Selectable_get_allSelectableCount_m5C8899307F8D8CB131ECF96189CD705E8BE19583 (void);
// 0x0000039A System.Collections.Generic.List`1<UnityEngine.UI.Selectable> UnityEngine.UI.Selectable::get_allSelectables()
extern void Selectable_get_allSelectables_m9F82EDDAB37348696DD42FEF5CB8DD1B40EB91AC (void);
// 0x0000039B System.Int32 UnityEngine.UI.Selectable::AllSelectablesNoAlloc(UnityEngine.UI.Selectable[])
extern void Selectable_AllSelectablesNoAlloc_mD71A0DD1083855505636B761F0818C64FD111106 (void);
// 0x0000039C UnityEngine.UI.Navigation UnityEngine.UI.Selectable::get_navigation()
extern void Selectable_get_navigation_mE0FE811B11269EFDEE21C98701059F786580FB50 (void);
// 0x0000039D System.Void UnityEngine.UI.Selectable::set_navigation(UnityEngine.UI.Navigation)
extern void Selectable_set_navigation_m40A501995B245DC9F28F2B5BE7B97849D77A15E0 (void);
// 0x0000039E UnityEngine.UI.Selectable/Transition UnityEngine.UI.Selectable::get_transition()
extern void Selectable_get_transition_mC5883DD4A0EC4A58F41285A8684B018309041D9E (void);
// 0x0000039F System.Void UnityEngine.UI.Selectable::set_transition(UnityEngine.UI.Selectable/Transition)
extern void Selectable_set_transition_m63DF4D4E58FE8DB9AF1FF233A51794FF595B9FA1 (void);
// 0x000003A0 UnityEngine.UI.ColorBlock UnityEngine.UI.Selectable::get_colors()
extern void Selectable_get_colors_m9E63E13A7B6C40CB0F20414FFBE15873BE5F3E4E (void);
// 0x000003A1 System.Void UnityEngine.UI.Selectable::set_colors(UnityEngine.UI.ColorBlock)
extern void Selectable_set_colors_m81723DC8CD15819135F76C107C118C668213D80E (void);
// 0x000003A2 UnityEngine.UI.SpriteState UnityEngine.UI.Selectable::get_spriteState()
extern void Selectable_get_spriteState_m0A341E18A903DAEF82259637F2D09B1CEC4DFD85 (void);
// 0x000003A3 System.Void UnityEngine.UI.Selectable::set_spriteState(UnityEngine.UI.SpriteState)
extern void Selectable_set_spriteState_m5393CBF0D75932E2CDA1CBCA934ED0DFDA857915 (void);
// 0x000003A4 UnityEngine.UI.AnimationTriggers UnityEngine.UI.Selectable::get_animationTriggers()
extern void Selectable_get_animationTriggers_m6F8F01A53FACD447624E24686E89F05EBEBF64E3 (void);
// 0x000003A5 System.Void UnityEngine.UI.Selectable::set_animationTriggers(UnityEngine.UI.AnimationTriggers)
extern void Selectable_set_animationTriggers_mAD7F1E48392417058B69CF8C7EAD793AFC75B05F (void);
// 0x000003A6 UnityEngine.UI.Graphic UnityEngine.UI.Selectable::get_targetGraphic()
extern void Selectable_get_targetGraphic_mB12CA26D04922ADB483397992561CA3941E78F92 (void);
// 0x000003A7 System.Void UnityEngine.UI.Selectable::set_targetGraphic(UnityEngine.UI.Graphic)
extern void Selectable_set_targetGraphic_mDA4746F7DF1665B6BF49CE3B026DE84640CA7AC5 (void);
// 0x000003A8 System.Boolean UnityEngine.UI.Selectable::get_interactable()
extern void Selectable_get_interactable_m0120339F2B195B7992F459FD79A72CA95B7808EE (void);
// 0x000003A9 System.Void UnityEngine.UI.Selectable::set_interactable(System.Boolean)
extern void Selectable_set_interactable_m91B2707F7B4F46F851C3100A65BEFAA557DCDFDE (void);
// 0x000003AA System.Boolean UnityEngine.UI.Selectable::get_isPointerInside()
extern void Selectable_get_isPointerInside_mCA6F9E1EEAF058D94E6E6BE884547E8D8E0DF8ED (void);
// 0x000003AB System.Void UnityEngine.UI.Selectable::set_isPointerInside(System.Boolean)
extern void Selectable_set_isPointerInside_m1167C721135FA817A58A522347E09F5A1C1A18DB (void);
// 0x000003AC System.Boolean UnityEngine.UI.Selectable::get_isPointerDown()
extern void Selectable_get_isPointerDown_m3975C3D82569067F116D62D0C337AAC5962C36C5 (void);
// 0x000003AD System.Void UnityEngine.UI.Selectable::set_isPointerDown(System.Boolean)
extern void Selectable_set_isPointerDown_m2A0A87D0CE5F9DA9E2394F724E7CFB4B181449A5 (void);
// 0x000003AE System.Boolean UnityEngine.UI.Selectable::get_hasSelection()
extern void Selectable_get_hasSelection_m2DB863F8B2D560B2D757FB9AB6E4054AE4FBF877 (void);
// 0x000003AF System.Void UnityEngine.UI.Selectable::set_hasSelection(System.Boolean)
extern void Selectable_set_hasSelection_mB1AADF443993B6349B39E96F6AE2D43B6809DFD8 (void);
// 0x000003B0 System.Void UnityEngine.UI.Selectable::.ctor()
extern void Selectable__ctor_m1E7B3EB14D7DC765A511C053C0F65A37755EC4B9 (void);
// 0x000003B1 UnityEngine.UI.Image UnityEngine.UI.Selectable::get_image()
extern void Selectable_get_image_m74FFCB0802A2E8380B33314F53A9748370D1C9F7 (void);
// 0x000003B2 System.Void UnityEngine.UI.Selectable::set_image(UnityEngine.UI.Image)
extern void Selectable_set_image_m1891A62E7B98B11323E1461BFE7C8BAFA8A27DA4 (void);
// 0x000003B3 UnityEngine.Animator UnityEngine.UI.Selectable::get_animator()
extern void Selectable_get_animator_m6117A378EE32B632B32C7441887BABF3ABA1C9A8 (void);
// 0x000003B4 System.Void UnityEngine.UI.Selectable::Awake()
extern void Selectable_Awake_mCF6C8CFE3E1F040F6B2C16EEE601AEB06D736C1D (void);
// 0x000003B5 System.Void UnityEngine.UI.Selectable::OnCanvasGroupChanged()
extern void Selectable_OnCanvasGroupChanged_m2B8B50B4EDB1010F0D528ABFA086E21A2810F072 (void);
// 0x000003B6 System.Boolean UnityEngine.UI.Selectable::IsInteractable()
extern void Selectable_IsInteractable_m4075B87AE967894F94D87C9A47F6F314225B2B47 (void);
// 0x000003B7 System.Void UnityEngine.UI.Selectable::OnDidApplyAnimationProperties()
extern void Selectable_OnDidApplyAnimationProperties_mACD23D97F62122F07F56C97301D1BA0394DAEF30 (void);
// 0x000003B8 System.Void UnityEngine.UI.Selectable::OnEnable()
extern void Selectable_OnEnable_m63C9B777E61D9AC975344E4F2B344486A1A359C6 (void);
// 0x000003B9 System.Void UnityEngine.UI.Selectable::OnTransformParentChanged()
extern void Selectable_OnTransformParentChanged_m18FB4CECAE86051DDB942189E370244D3D3E9A8E (void);
// 0x000003BA System.Void UnityEngine.UI.Selectable::OnSetProperty()
extern void Selectable_OnSetProperty_mE35632CDB4A1D3E3327EDBBF21CFD3192E5060C5 (void);
// 0x000003BB System.Void UnityEngine.UI.Selectable::OnDisable()
extern void Selectable_OnDisable_m4D4535A97B291959E391BCC56D51BF75B7B0F1B9 (void);
// 0x000003BC UnityEngine.UI.Selectable/SelectionState UnityEngine.UI.Selectable::get_currentSelectionState()
extern void Selectable_get_currentSelectionState_m37B79D51884A49924B92D1AE1BAA354C55CA1FD0 (void);
// 0x000003BD System.Void UnityEngine.UI.Selectable::InstantClearState()
extern void Selectable_InstantClearState_m91C43C9233166E21CF2ECEBD620DFE9E00041C47 (void);
// 0x000003BE System.Void UnityEngine.UI.Selectable::DoStateTransition(UnityEngine.UI.Selectable/SelectionState,System.Boolean)
extern void Selectable_DoStateTransition_mEC025D35C6671DA32750475C88DFE7651CE4B7AB (void);
// 0x000003BF UnityEngine.UI.Selectable UnityEngine.UI.Selectable::FindSelectable(UnityEngine.Vector3)
extern void Selectable_FindSelectable_m7197D69C5F25246DD57F86B660218D9F64F4902A (void);
// 0x000003C0 UnityEngine.Vector3 UnityEngine.UI.Selectable::GetPointOnRectEdge(UnityEngine.RectTransform,UnityEngine.Vector2)
extern void Selectable_GetPointOnRectEdge_mD500D4CD3E1541B610D04181241091241A0F5A28 (void);
// 0x000003C1 System.Void UnityEngine.UI.Selectable::Navigate(UnityEngine.EventSystems.AxisEventData,UnityEngine.UI.Selectable)
extern void Selectable_Navigate_m4FDD4FFCD48CFD630D17C04637502A2805CDB9CA (void);
// 0x000003C2 UnityEngine.UI.Selectable UnityEngine.UI.Selectable::FindSelectableOnLeft()
extern void Selectable_FindSelectableOnLeft_m501FD2B988BBFFDAD318800A4D164FB21F1AE315 (void);
// 0x000003C3 UnityEngine.UI.Selectable UnityEngine.UI.Selectable::FindSelectableOnRight()
extern void Selectable_FindSelectableOnRight_mA5550ED566545FF1E5113E935F4F57B63F3760FA (void);
// 0x000003C4 UnityEngine.UI.Selectable UnityEngine.UI.Selectable::FindSelectableOnUp()
extern void Selectable_FindSelectableOnUp_m26D12F3EBE3D07C4D69C639DE4D219B40886E8FA (void);
// 0x000003C5 UnityEngine.UI.Selectable UnityEngine.UI.Selectable::FindSelectableOnDown()
extern void Selectable_FindSelectableOnDown_m2EC533E6757FC29A2FABAB68A5E8D56394FE2637 (void);
// 0x000003C6 System.Void UnityEngine.UI.Selectable::OnMove(UnityEngine.EventSystems.AxisEventData)
extern void Selectable_OnMove_m8AAE7D2F2A2059EED12925394E398B65F251AA4E (void);
// 0x000003C7 System.Void UnityEngine.UI.Selectable::StartColorTween(UnityEngine.Color,System.Boolean)
extern void Selectable_StartColorTween_m1BA85AE34B9A886B74238F05F370835CE94CD5D9 (void);
// 0x000003C8 System.Void UnityEngine.UI.Selectable::DoSpriteSwap(UnityEngine.Sprite)
extern void Selectable_DoSpriteSwap_mF4F4977E6609789F67C5A40C7A184CAD5707F752 (void);
// 0x000003C9 System.Void UnityEngine.UI.Selectable::TriggerAnimation(System.String)
extern void Selectable_TriggerAnimation_m438985D7B825F426888769754D50A4A2C637AFD3 (void);
// 0x000003CA System.Boolean UnityEngine.UI.Selectable::IsHighlighted()
extern void Selectable_IsHighlighted_mC11E539C4FC416D05B0733B0A641ABA5F276BE44 (void);
// 0x000003CB System.Boolean UnityEngine.UI.Selectable::IsPressed()
extern void Selectable_IsPressed_m217CD91BBE84B4D4C3A457EBA36A964DA8D5762E (void);
// 0x000003CC System.Void UnityEngine.UI.Selectable::EvaluateAndTransitionToSelectionState()
extern void Selectable_EvaluateAndTransitionToSelectionState_m925817B538D603A5A14AE0EC7DC3C3ABE1462B0B (void);
// 0x000003CD System.Void UnityEngine.UI.Selectable::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
extern void Selectable_OnPointerDown_mF81D9CFD8AC52A2EE73E6A65CC51AC93E44D0321 (void);
// 0x000003CE System.Void UnityEngine.UI.Selectable::OnPointerUp(UnityEngine.EventSystems.PointerEventData)
extern void Selectable_OnPointerUp_m8E67DADBC60C97A24608D5C158A94DF12BDD3A54 (void);
// 0x000003CF System.Void UnityEngine.UI.Selectable::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void Selectable_OnPointerEnter_m25A9DDB384226E415785C3A6CB0A0FE61483EE03 (void);
// 0x000003D0 System.Void UnityEngine.UI.Selectable::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void Selectable_OnPointerExit_m0C898C493D18958AA9CD049A5FAAB8DBAD026DEA (void);
// 0x000003D1 System.Void UnityEngine.UI.Selectable::OnSelect(UnityEngine.EventSystems.BaseEventData)
extern void Selectable_OnSelect_m9CFD4A5A15A6D16E75E5D6FC73CCE7869A2D23C8 (void);
// 0x000003D2 System.Void UnityEngine.UI.Selectable::OnDeselect(UnityEngine.EventSystems.BaseEventData)
extern void Selectable_OnDeselect_m09801707C815FFFFEAD78D16AC1187F7C51C656D (void);
// 0x000003D3 System.Void UnityEngine.UI.Selectable::Select()
extern void Selectable_Select_m41FDB7D52E825BDE2C34B18C0EE7A80915A9F9EC (void);
// 0x000003D4 System.Void UnityEngine.UI.Selectable::.cctor()
extern void Selectable__cctor_mD2F3280F120072463AB6F5DA01107C71B6764F5D (void);
// 0x000003D5 System.Boolean UnityEngine.UI.SetPropertyUtility::SetColor(UnityEngine.Color&,UnityEngine.Color)
extern void SetPropertyUtility_SetColor_m7A4396D8CC55463527EE7B872A25AC763334D566 (void);
// 0x000003D6 System.Boolean UnityEngine.UI.SetPropertyUtility::SetStruct(T&,T)
// 0x000003D7 System.Boolean UnityEngine.UI.SetPropertyUtility::SetClass(T&,T)
// 0x000003D8 UnityEngine.RectTransform UnityEngine.UI.Slider::get_fillRect()
extern void Slider_get_fillRect_mEDD45CFE2E622B61B82469DBA18B52FC3C3C279D (void);
// 0x000003D9 System.Void UnityEngine.UI.Slider::set_fillRect(UnityEngine.RectTransform)
extern void Slider_set_fillRect_mD84E7633BC3F88D77B10F78C5B6731674B98110B (void);
// 0x000003DA UnityEngine.RectTransform UnityEngine.UI.Slider::get_handleRect()
extern void Slider_get_handleRect_m2EFF3788BEBE513F7C5CCD3E494F37C153F2AAD8 (void);
// 0x000003DB System.Void UnityEngine.UI.Slider::set_handleRect(UnityEngine.RectTransform)
extern void Slider_set_handleRect_m5BFDDDC79CBCDFD3A85969E4793E6775EC8A54CE (void);
// 0x000003DC UnityEngine.UI.Slider/Direction UnityEngine.UI.Slider::get_direction()
extern void Slider_get_direction_mE9A02803187D68D400284913BC6F93F587610022 (void);
// 0x000003DD System.Void UnityEngine.UI.Slider::set_direction(UnityEngine.UI.Slider/Direction)
extern void Slider_set_direction_mA51E204E4880C34EAC54578285F6C25C8C7D1170 (void);
// 0x000003DE System.Single UnityEngine.UI.Slider::get_minValue()
extern void Slider_get_minValue_m39F8A4DDD14BE2AF97ACD326FACFF2E169377DF7 (void);
// 0x000003DF System.Void UnityEngine.UI.Slider::set_minValue(System.Single)
extern void Slider_set_minValue_m795F45748FA2890925E28E87AB23EEC89E15756F (void);
// 0x000003E0 System.Single UnityEngine.UI.Slider::get_maxValue()
extern void Slider_get_maxValue_mC3AE4128A6DC12217BEEBF168C92808E9EEFEB2F (void);
// 0x000003E1 System.Void UnityEngine.UI.Slider::set_maxValue(System.Single)
extern void Slider_set_maxValue_m3517BF6A1127298F11582535887B6FE5AA7C57D3 (void);
// 0x000003E2 System.Boolean UnityEngine.UI.Slider::get_wholeNumbers()
extern void Slider_get_wholeNumbers_m136600AF2452CA26E86DDC3D0D54CCEFD3814F63 (void);
// 0x000003E3 System.Void UnityEngine.UI.Slider::set_wholeNumbers(System.Boolean)
extern void Slider_set_wholeNumbers_m6822D70D08748A8CF82A24B2AB86C83AA2E3FEE1 (void);
// 0x000003E4 System.Single UnityEngine.UI.Slider::get_value()
extern void Slider_get_value_m0F777FFC198C6D9A822F89C2192D7A519CD2BD53 (void);
// 0x000003E5 System.Void UnityEngine.UI.Slider::set_value(System.Single)
extern void Slider_set_value_mE113ED73D32B7F474080173006FBF2D67B82718F (void);
// 0x000003E6 System.Void UnityEngine.UI.Slider::SetValueWithoutNotify(System.Single)
extern void Slider_SetValueWithoutNotify_mD18769CA2D2AAD631F59972C1C759038138091C6 (void);
// 0x000003E7 System.Single UnityEngine.UI.Slider::get_normalizedValue()
extern void Slider_get_normalizedValue_m72EE50CB45B6B56B31A47E75D1F95B48937A7E2F (void);
// 0x000003E8 System.Void UnityEngine.UI.Slider::set_normalizedValue(System.Single)
extern void Slider_set_normalizedValue_mF932B150739F3C38E125175E81FD7C0F11C44A23 (void);
// 0x000003E9 UnityEngine.UI.Slider/SliderEvent UnityEngine.UI.Slider::get_onValueChanged()
extern void Slider_get_onValueChanged_m9D9177CDBF349783372AABF032F2D2B3178A84D6 (void);
// 0x000003EA System.Void UnityEngine.UI.Slider::set_onValueChanged(UnityEngine.UI.Slider/SliderEvent)
extern void Slider_set_onValueChanged_m27899FC1F664132955022FD71B640765F756BA30 (void);
// 0x000003EB System.Single UnityEngine.UI.Slider::get_stepSize()
extern void Slider_get_stepSize_mD4640C1F82F7734407999F331AB6E007967364CC (void);
// 0x000003EC System.Void UnityEngine.UI.Slider::.ctor()
extern void Slider__ctor_mB9749A83A0FB05CF9F59D00CB5F9DAA1FDF87D64 (void);
// 0x000003ED System.Void UnityEngine.UI.Slider::Rebuild(UnityEngine.UI.CanvasUpdate)
extern void Slider_Rebuild_m070D814D4008AC677F2DEC291A3191AF1CAC8C6E (void);
// 0x000003EE System.Void UnityEngine.UI.Slider::LayoutComplete()
extern void Slider_LayoutComplete_mE739FE417F0D246B71B8B0DEC01C71F26D8D7CFB (void);
// 0x000003EF System.Void UnityEngine.UI.Slider::GraphicUpdateComplete()
extern void Slider_GraphicUpdateComplete_mBEE6AAC8FFCB0949AA25AAD4D1008A67C95CFDB3 (void);
// 0x000003F0 System.Void UnityEngine.UI.Slider::OnEnable()
extern void Slider_OnEnable_m94A7E2FF6F581C3992875AA18F681A9A72EC719C (void);
// 0x000003F1 System.Void UnityEngine.UI.Slider::OnDisable()
extern void Slider_OnDisable_m0A25AFB7921324B5B3C611F0DB30B88ED4D5F92F (void);
// 0x000003F2 System.Void UnityEngine.UI.Slider::Update()
extern void Slider_Update_m75AE1C642DD5404ADA40E0045E2D467459BB28C4 (void);
// 0x000003F3 System.Void UnityEngine.UI.Slider::OnDidApplyAnimationProperties()
extern void Slider_OnDidApplyAnimationProperties_m969003FC5EA26B90195B76D17C20B8356E0F2355 (void);
// 0x000003F4 System.Void UnityEngine.UI.Slider::UpdateCachedReferences()
extern void Slider_UpdateCachedReferences_mAD4CB104043152029834B94B8BE74FAC82F2969D (void);
// 0x000003F5 System.Single UnityEngine.UI.Slider::ClampValue(System.Single)
extern void Slider_ClampValue_m31CCF27E40BB02B82F2E9555DCC35C9790184EFC (void);
// 0x000003F6 System.Void UnityEngine.UI.Slider::Set(System.Single,System.Boolean)
extern void Slider_Set_mA0A17D8C3C828B8DEFF462B664FC98F563EB6732 (void);
// 0x000003F7 System.Void UnityEngine.UI.Slider::OnRectTransformDimensionsChange()
extern void Slider_OnRectTransformDimensionsChange_mAE8973B662B2A466599391B4E025AFFC2B699995 (void);
// 0x000003F8 UnityEngine.UI.Slider/Axis UnityEngine.UI.Slider::get_axis()
extern void Slider_get_axis_m9F710E0C68A9BB669EEAEC975162175F7739EB0D (void);
// 0x000003F9 System.Boolean UnityEngine.UI.Slider::get_reverseValue()
extern void Slider_get_reverseValue_mC323FAACCF39EECD0D66012C8A455D2CB8135154 (void);
// 0x000003FA System.Void UnityEngine.UI.Slider::UpdateVisuals()
extern void Slider_UpdateVisuals_mE375780E83D08FA084D10A457861251A235CBA2A (void);
// 0x000003FB System.Void UnityEngine.UI.Slider::UpdateDrag(UnityEngine.EventSystems.PointerEventData,UnityEngine.Camera)
extern void Slider_UpdateDrag_m48423493426B22F202FC78B7AF92B95398111E9B (void);
// 0x000003FC System.Boolean UnityEngine.UI.Slider::MayDrag(UnityEngine.EventSystems.PointerEventData)
extern void Slider_MayDrag_m9BDCF2F984E31CEFD030350E6051812195C75D6F (void);
// 0x000003FD System.Void UnityEngine.UI.Slider::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
extern void Slider_OnPointerDown_mCD894094C24BA933D5E34543598D6F484C0E62E2 (void);
// 0x000003FE System.Void UnityEngine.UI.Slider::OnDrag(UnityEngine.EventSystems.PointerEventData)
extern void Slider_OnDrag_m9ECE82FD5564D048B5F2E3FFF6ECCE2602189CD4 (void);
// 0x000003FF System.Void UnityEngine.UI.Slider::OnMove(UnityEngine.EventSystems.AxisEventData)
extern void Slider_OnMove_mD523157E7F7722B098B6164B558C14B0C6B38384 (void);
// 0x00000400 UnityEngine.UI.Selectable UnityEngine.UI.Slider::FindSelectableOnLeft()
extern void Slider_FindSelectableOnLeft_m1712ADA199F792D4C30D0094AA9A43D3441C7471 (void);
// 0x00000401 UnityEngine.UI.Selectable UnityEngine.UI.Slider::FindSelectableOnRight()
extern void Slider_FindSelectableOnRight_m42B9D352422ABEB7719BD3F63821A6166261C646 (void);
// 0x00000402 UnityEngine.UI.Selectable UnityEngine.UI.Slider::FindSelectableOnUp()
extern void Slider_FindSelectableOnUp_mC66B25E4FB7290FCF82048F6AA857F0C6ECC3FA7 (void);
// 0x00000403 UnityEngine.UI.Selectable UnityEngine.UI.Slider::FindSelectableOnDown()
extern void Slider_FindSelectableOnDown_mD2F38D581CB5AFA849AFE901EA512579A2799E6D (void);
// 0x00000404 System.Void UnityEngine.UI.Slider::OnInitializePotentialDrag(UnityEngine.EventSystems.PointerEventData)
extern void Slider_OnInitializePotentialDrag_mA0F17D75D4449731C8497D93FD27A655300DBD53 (void);
// 0x00000405 System.Void UnityEngine.UI.Slider::SetDirection(UnityEngine.UI.Slider/Direction,System.Boolean)
extern void Slider_SetDirection_m71F1505A3E095AF24BDEE69116C88D95F51F2E10 (void);
// 0x00000406 UnityEngine.Transform UnityEngine.UI.Slider::UnityEngine.UI.ICanvasElement.get_transform()
extern void Slider_UnityEngine_UI_ICanvasElement_get_transform_m47384BECFD0D74507A4118F086EFA66216799287 (void);
// 0x00000407 UnityEngine.Sprite UnityEngine.UI.SpriteState::get_highlightedSprite()
extern void SpriteState_get_highlightedSprite_mB8CB5AD077F9FDA5A7DA9B0700B70FEB471B15F0 (void);
// 0x00000408 System.Void UnityEngine.UI.SpriteState::set_highlightedSprite(UnityEngine.Sprite)
extern void SpriteState_set_highlightedSprite_m44A452FACA739422110D9B8C2E51E8874A730B1D (void);
// 0x00000409 UnityEngine.Sprite UnityEngine.UI.SpriteState::get_pressedSprite()
extern void SpriteState_get_pressedSprite_m42EB6FFB954E6BDC6384B5DCDD7348DE4F7D44EB (void);
// 0x0000040A System.Void UnityEngine.UI.SpriteState::set_pressedSprite(UnityEngine.Sprite)
extern void SpriteState_set_pressedSprite_mB3C2505D0D31FBB5549444AF739D887B399535F6 (void);
// 0x0000040B UnityEngine.Sprite UnityEngine.UI.SpriteState::get_selectedSprite()
extern void SpriteState_get_selectedSprite_mC69216B3ABE6539D061E34707C086FA76F28FF5B (void);
// 0x0000040C System.Void UnityEngine.UI.SpriteState::set_selectedSprite(UnityEngine.Sprite)
extern void SpriteState_set_selectedSprite_mEA22F605F22D4302EE742C2500B891DC442A0EB5 (void);
// 0x0000040D UnityEngine.Sprite UnityEngine.UI.SpriteState::get_disabledSprite()
extern void SpriteState_get_disabledSprite_m08ED7B54CD394C0CE044519A296600DFF14D0B57 (void);
// 0x0000040E System.Void UnityEngine.UI.SpriteState::set_disabledSprite(UnityEngine.Sprite)
extern void SpriteState_set_disabledSprite_m4F8989570A957B357527421B89EFF14CA2228E14 (void);
// 0x0000040F System.Boolean UnityEngine.UI.SpriteState::Equals(UnityEngine.UI.SpriteState)
extern void SpriteState_Equals_mBD4F9DE44FE87CA763874C9C8C0FAC60E1686592 (void);
// 0x00000410 UnityEngine.Material UnityEngine.UI.StencilMaterial::Add(UnityEngine.Material,System.Int32)
extern void StencilMaterial_Add_m0CAC8A2810CE464C942A113C2C98B4D0DFD490C6 (void);
// 0x00000411 UnityEngine.Material UnityEngine.UI.StencilMaterial::Add(UnityEngine.Material,System.Int32,UnityEngine.Rendering.StencilOp,UnityEngine.Rendering.CompareFunction,UnityEngine.Rendering.ColorWriteMask)
extern void StencilMaterial_Add_mC3BA91DE802960AD78E0121510054F66D5907957 (void);
// 0x00000412 UnityEngine.Material UnityEngine.UI.StencilMaterial::Add(UnityEngine.Material,System.Int32,UnityEngine.Rendering.StencilOp,UnityEngine.Rendering.CompareFunction,UnityEngine.Rendering.ColorWriteMask,System.Int32,System.Int32)
extern void StencilMaterial_Add_mAB4F4B762B5FA96473A30706AC2570FAF86D4746 (void);
// 0x00000413 System.Void UnityEngine.UI.StencilMaterial::Remove(UnityEngine.Material)
extern void StencilMaterial_Remove_m3D0EEC517780E1528A9D4F3AABF3B78BF59B5282 (void);
// 0x00000414 System.Void UnityEngine.UI.StencilMaterial::ClearAll()
extern void StencilMaterial_ClearAll_m0E04E813DE65150C047EF22F090BEB6C00DED77B (void);
// 0x00000415 System.Void UnityEngine.UI.StencilMaterial::.cctor()
extern void StencilMaterial__cctor_m55BD7A7538EFDC49FDF2AF3C1F43D7D0615AF13D (void);
// 0x00000416 System.Void UnityEngine.UI.Text::.ctor()
extern void Text__ctor_mC95797286B600CF862FC75F9E65F48267313865F (void);
// 0x00000417 UnityEngine.TextGenerator UnityEngine.UI.Text::get_cachedTextGenerator()
extern void Text_get_cachedTextGenerator_mC2FED5B2D9A7BF6D4372FDC993D0B7F0EA3C1DA8 (void);
// 0x00000418 UnityEngine.TextGenerator UnityEngine.UI.Text::get_cachedTextGeneratorForLayout()
extern void Text_get_cachedTextGeneratorForLayout_m0F227772707238FF803F6A14F7B06B17D87A8BC5 (void);
// 0x00000419 UnityEngine.Texture UnityEngine.UI.Text::get_mainTexture()
extern void Text_get_mainTexture_m2DB4BB9E001F9251B8B95887CC17CA78DAEB5C45 (void);
// 0x0000041A System.Void UnityEngine.UI.Text::FontTextureChanged()
extern void Text_FontTextureChanged_mFD9E41BBD0E8875A640F7554A4A233F4F91D8D32 (void);
// 0x0000041B UnityEngine.Font UnityEngine.UI.Text::get_font()
extern void Text_get_font_mC5492E71F03FA7CD2B9C42672B662FF2383A7919 (void);
// 0x0000041C System.Void UnityEngine.UI.Text::set_font(UnityEngine.Font)
extern void Text_set_font_m77D86B27FDEE1FD2D96A7419F11CF9B249A50D66 (void);
// 0x0000041D System.String UnityEngine.UI.Text::get_text()
extern void Text_get_text_mAC04085D2550B32FF25ED8C7FBE012B527D4F8E5 (void);
// 0x0000041E System.Void UnityEngine.UI.Text::set_text(System.String)
extern void Text_set_text_m06205D43AD79670752504410AEA7DB65F3495261 (void);
// 0x0000041F System.Boolean UnityEngine.UI.Text::get_supportRichText()
extern void Text_get_supportRichText_m773629D045B3AB8B019607FD62CF6FF5E084BE47 (void);
// 0x00000420 System.Void UnityEngine.UI.Text::set_supportRichText(System.Boolean)
extern void Text_set_supportRichText_m8854F111655576BEB5010C2E20DBA3F6CDD4A728 (void);
// 0x00000421 System.Boolean UnityEngine.UI.Text::get_resizeTextForBestFit()
extern void Text_get_resizeTextForBestFit_mA8C9E2BEB9842156E49EBD769CD195DFFBDA6BB6 (void);
// 0x00000422 System.Void UnityEngine.UI.Text::set_resizeTextForBestFit(System.Boolean)
extern void Text_set_resizeTextForBestFit_mAE249035B12F07D09257F84A5ABA473C0E76596D (void);
// 0x00000423 System.Int32 UnityEngine.UI.Text::get_resizeTextMinSize()
extern void Text_get_resizeTextMinSize_m9B6868F8F5FDDB892FAB0606A84D0A4F60CC2A55 (void);
// 0x00000424 System.Void UnityEngine.UI.Text::set_resizeTextMinSize(System.Int32)
extern void Text_set_resizeTextMinSize_m5120DA2BCA50601607C9E8C5626BF4E22B741F76 (void);
// 0x00000425 System.Int32 UnityEngine.UI.Text::get_resizeTextMaxSize()
extern void Text_get_resizeTextMaxSize_m425BDDA1A72EDC3E2D3BA30C4B55F8D4FD7163CD (void);
// 0x00000426 System.Void UnityEngine.UI.Text::set_resizeTextMaxSize(System.Int32)
extern void Text_set_resizeTextMaxSize_mFEFAD8F77C8C7A2C7FF8C3EACB7D6FF6BAD921E8 (void);
// 0x00000427 UnityEngine.TextAnchor UnityEngine.UI.Text::get_alignment()
extern void Text_get_alignment_m764224AECDEEF22CCC70D507944D753FBCF58D97 (void);
// 0x00000428 System.Void UnityEngine.UI.Text::set_alignment(UnityEngine.TextAnchor)
extern void Text_set_alignment_m561721B60004841C883CE9E1C981616E08AB1900 (void);
// 0x00000429 System.Boolean UnityEngine.UI.Text::get_alignByGeometry()
extern void Text_get_alignByGeometry_m9F2147D31569144BC67429F00C4D5458CC75326B (void);
// 0x0000042A System.Void UnityEngine.UI.Text::set_alignByGeometry(System.Boolean)
extern void Text_set_alignByGeometry_mCC0F6C643A459A43FEDE07106208D07993411079 (void);
// 0x0000042B System.Int32 UnityEngine.UI.Text::get_fontSize()
extern void Text_get_fontSize_m54D89E58101CB7F2B51110A6161E8C36D5373428 (void);
// 0x0000042C System.Void UnityEngine.UI.Text::set_fontSize(System.Int32)
extern void Text_set_fontSize_m7551E066F44B292BBF8EFC7EEF3CBEE1D1AAFB06 (void);
// 0x0000042D UnityEngine.HorizontalWrapMode UnityEngine.UI.Text::get_horizontalOverflow()
extern void Text_get_horizontalOverflow_mEBD747C7A0B0DEF7AEC55307A8EDA6DD1ECCC5B2 (void);
// 0x0000042E System.Void UnityEngine.UI.Text::set_horizontalOverflow(UnityEngine.HorizontalWrapMode)
extern void Text_set_horizontalOverflow_m25E21FB646B7B4802055E363BE35A76B1C0601CF (void);
// 0x0000042F UnityEngine.VerticalWrapMode UnityEngine.UI.Text::get_verticalOverflow()
extern void Text_get_verticalOverflow_mA8582227054F2DB4071BDC70204103C98C1D7D79 (void);
// 0x00000430 System.Void UnityEngine.UI.Text::set_verticalOverflow(UnityEngine.VerticalWrapMode)
extern void Text_set_verticalOverflow_m4DF07E06D460D0D9182627CCA3619AA1E1C11E94 (void);
// 0x00000431 System.Single UnityEngine.UI.Text::get_lineSpacing()
extern void Text_get_lineSpacing_m45E1C10CB772BB56DA0DC2A8FEE7A7CC9B3C5105 (void);
// 0x00000432 System.Void UnityEngine.UI.Text::set_lineSpacing(System.Single)
extern void Text_set_lineSpacing_m0B40346036180A5375F33075B3366F56F1C52801 (void);
// 0x00000433 UnityEngine.FontStyle UnityEngine.UI.Text::get_fontStyle()
extern void Text_get_fontStyle_mA223DF2A20DDBB2755624498CFD8C99E22A981CA (void);
// 0x00000434 System.Void UnityEngine.UI.Text::set_fontStyle(UnityEngine.FontStyle)
extern void Text_set_fontStyle_mEB69FC3AD201D282D5DC1985A6B3656B79542030 (void);
// 0x00000435 System.Single UnityEngine.UI.Text::get_pixelsPerUnit()
extern void Text_get_pixelsPerUnit_m66B1F16660BDE8F058F59B80B196F5A10B8BFA11 (void);
// 0x00000436 System.Void UnityEngine.UI.Text::OnEnable()
extern void Text_OnEnable_m6D5C18FAA3B6F62B55A83D44A20949C1CF5CE7FD (void);
// 0x00000437 System.Void UnityEngine.UI.Text::OnDisable()
extern void Text_OnDisable_m0B0965F6DA3A71683822989744E5705CD1641FE5 (void);
// 0x00000438 System.Void UnityEngine.UI.Text::UpdateGeometry()
extern void Text_UpdateGeometry_mA8A037291FE143D329C85EAC881FA56F84DD73E7 (void);
// 0x00000439 System.Void UnityEngine.UI.Text::AssignDefaultFont()
extern void Text_AssignDefaultFont_m96292009E24D108CA2889748CBB06B34CF854B69 (void);
// 0x0000043A UnityEngine.TextGenerationSettings UnityEngine.UI.Text::GetGenerationSettings(UnityEngine.Vector2)
extern void Text_GetGenerationSettings_m601D90FFD85B04F8DD7DA4D701080AAB77F2FAAD (void);
// 0x0000043B UnityEngine.Vector2 UnityEngine.UI.Text::GetTextAnchorPivot(UnityEngine.TextAnchor)
extern void Text_GetTextAnchorPivot_m46E0F5CDDA2E0366DBB463A2D46F3F334FC1D058 (void);
// 0x0000043C System.Void UnityEngine.UI.Text::OnPopulateMesh(UnityEngine.UI.VertexHelper)
extern void Text_OnPopulateMesh_m29E980A07D59D8151E7497E11FD5EE15AF85FF6F (void);
// 0x0000043D System.Void UnityEngine.UI.Text::CalculateLayoutInputHorizontal()
extern void Text_CalculateLayoutInputHorizontal_m7B2DA73FF1503750666D8468BE7102EEDA1EDD65 (void);
// 0x0000043E System.Void UnityEngine.UI.Text::CalculateLayoutInputVertical()
extern void Text_CalculateLayoutInputVertical_mC194E8A8CFACDAE1F7DA8D2F3168FB14315A3A50 (void);
// 0x0000043F System.Single UnityEngine.UI.Text::get_minWidth()
extern void Text_get_minWidth_m46490002BA829F128F9B6190FAC94839CAFF48DC (void);
// 0x00000440 System.Single UnityEngine.UI.Text::get_preferredWidth()
extern void Text_get_preferredWidth_mB995B7D7B8D1808D2CC91B7D8CDE6072390DDF4F (void);
// 0x00000441 System.Single UnityEngine.UI.Text::get_flexibleWidth()
extern void Text_get_flexibleWidth_m78EA0BBCDDEF992B51E387CAB6C31E72CDF70A6F (void);
// 0x00000442 System.Single UnityEngine.UI.Text::get_minHeight()
extern void Text_get_minHeight_m76435DC5706971E701498CC565CB3096F5DB2C7C (void);
// 0x00000443 System.Single UnityEngine.UI.Text::get_preferredHeight()
extern void Text_get_preferredHeight_mD5E92B056D52BDD6BCCD9F799C402605A6E5578A (void);
// 0x00000444 System.Single UnityEngine.UI.Text::get_flexibleHeight()
extern void Text_get_flexibleHeight_m77EAAD745212A4E7FD27B6415E222BE5B76792B9 (void);
// 0x00000445 System.Int32 UnityEngine.UI.Text::get_layoutPriority()
extern void Text_get_layoutPriority_m83D4EEEC3869BC520693077152DA06BB916F90F6 (void);
// 0x00000446 System.Void UnityEngine.UI.Text::.cctor()
extern void Text__cctor_m3CBFDFC22A6A1860DF15ADC7E2E4E6616447EFCD (void);
// 0x00000447 UnityEngine.UI.ToggleGroup UnityEngine.UI.Toggle::get_group()
extern void Toggle_get_group_m8A53B9EF413E699F639789C84035237AA9E6F614 (void);
// 0x00000448 System.Void UnityEngine.UI.Toggle::set_group(UnityEngine.UI.ToggleGroup)
extern void Toggle_set_group_m79CCF30AB22683B835A9FC60668B62E804887138 (void);
// 0x00000449 System.Void UnityEngine.UI.Toggle::.ctor()
extern void Toggle__ctor_m6071227A758B1F396BA3794940A43A18370821DF (void);
// 0x0000044A System.Void UnityEngine.UI.Toggle::Rebuild(UnityEngine.UI.CanvasUpdate)
extern void Toggle_Rebuild_m5112CD920031EC8E296631D0825CC0171DF4CD1D (void);
// 0x0000044B System.Void UnityEngine.UI.Toggle::LayoutComplete()
extern void Toggle_LayoutComplete_m6BD1146C8118A6E439509669D6D66DFB9C8C29EC (void);
// 0x0000044C System.Void UnityEngine.UI.Toggle::GraphicUpdateComplete()
extern void Toggle_GraphicUpdateComplete_m116EDA905EAFB6F70F25185E343611C127D2D95D (void);
// 0x0000044D System.Void UnityEngine.UI.Toggle::OnDestroy()
extern void Toggle_OnDestroy_m9754D2593E4DB02B19EEFCAEA8769D57B9307BE6 (void);
// 0x0000044E System.Void UnityEngine.UI.Toggle::OnEnable()
extern void Toggle_OnEnable_mC49A4F8CC585002FB544314DA6ED5AEEF90CC606 (void);
// 0x0000044F System.Void UnityEngine.UI.Toggle::OnDisable()
extern void Toggle_OnDisable_m1F8B403A7836271B53223A5112E59033F1F970C8 (void);
// 0x00000450 System.Void UnityEngine.UI.Toggle::OnDidApplyAnimationProperties()
extern void Toggle_OnDidApplyAnimationProperties_m039EA4C84F62E2C815E59BE4B9DACFD6CF19D1E5 (void);
// 0x00000451 System.Void UnityEngine.UI.Toggle::SetToggleGroup(UnityEngine.UI.ToggleGroup,System.Boolean)
extern void Toggle_SetToggleGroup_mDA126E6B5A5DAED335E42E8BAEF4AD3DD0369AF5 (void);
// 0x00000452 System.Boolean UnityEngine.UI.Toggle::get_isOn()
extern void Toggle_get_isOn_mC0C6AA83480A8DEFC7ADB2BC4FE1FCF0D92CA964 (void);
// 0x00000453 System.Void UnityEngine.UI.Toggle::set_isOn(System.Boolean)
extern void Toggle_set_isOn_m520D16B143619437D7997316584A029D7C3CABF8 (void);
// 0x00000454 System.Void UnityEngine.UI.Toggle::SetIsOnWithoutNotify(System.Boolean)
extern void Toggle_SetIsOnWithoutNotify_mE889EC3B1C7E271C822D07F5F73CB023EDFD87B4 (void);
// 0x00000455 System.Void UnityEngine.UI.Toggle::Set(System.Boolean,System.Boolean)
extern void Toggle_Set_m48ADB027F8B3C1B761EB6947B2DE48BC40977413 (void);
// 0x00000456 System.Void UnityEngine.UI.Toggle::PlayEffect(System.Boolean)
extern void Toggle_PlayEffect_mD786A6A6C18AFD30E7CEAAA65FD3CA027A6AC1C7 (void);
// 0x00000457 System.Void UnityEngine.UI.Toggle::Start()
extern void Toggle_Start_m218BE913F96CC0BEDAF517F3B15DB704307E920E (void);
// 0x00000458 System.Void UnityEngine.UI.Toggle::InternalToggle()
extern void Toggle_InternalToggle_m5E9A8D95C789BAC57A1AA00F08CF0DD3DDB9D7A9 (void);
// 0x00000459 System.Void UnityEngine.UI.Toggle::OnPointerClick(UnityEngine.EventSystems.PointerEventData)
extern void Toggle_OnPointerClick_m9910AE088F9E1DA3141AA096508BAE749875F917 (void);
// 0x0000045A System.Void UnityEngine.UI.Toggle::OnSubmit(UnityEngine.EventSystems.BaseEventData)
extern void Toggle_OnSubmit_m586CC315CDCA1E0A45918AA0C6BFA917C6265939 (void);
// 0x0000045B UnityEngine.Transform UnityEngine.UI.Toggle::UnityEngine.UI.ICanvasElement.get_transform()
extern void Toggle_UnityEngine_UI_ICanvasElement_get_transform_m0C71617F839B3BCEEA765EF98476562CF609835D (void);
// 0x0000045C System.Boolean UnityEngine.UI.ToggleGroup::get_allowSwitchOff()
extern void ToggleGroup_get_allowSwitchOff_mB9E04E1842B8293F8B25956D0AF14F8B8B5F5D94 (void);
// 0x0000045D System.Void UnityEngine.UI.ToggleGroup::set_allowSwitchOff(System.Boolean)
extern void ToggleGroup_set_allowSwitchOff_m2D7F870F2BA9CB14E92C2198014862B303C63F16 (void);
// 0x0000045E System.Void UnityEngine.UI.ToggleGroup::.ctor()
extern void ToggleGroup__ctor_mAE46954152026CB11A1F336EA4963BCA9A5FEFA1 (void);
// 0x0000045F System.Void UnityEngine.UI.ToggleGroup::Start()
extern void ToggleGroup_Start_mED5FF12C3F8C51D3D3F2387EDC90D8DCB547CB5F (void);
// 0x00000460 System.Void UnityEngine.UI.ToggleGroup::ValidateToggleIsInGroup(UnityEngine.UI.Toggle)
extern void ToggleGroup_ValidateToggleIsInGroup_mD4CA76641EF05E60429FFF845F19D107C603627D (void);
// 0x00000461 System.Void UnityEngine.UI.ToggleGroup::NotifyToggleOn(UnityEngine.UI.Toggle,System.Boolean)
extern void ToggleGroup_NotifyToggleOn_m16EABEAEDA4F5BDAEEEFBECF7E802CA7151A82E3 (void);
// 0x00000462 System.Void UnityEngine.UI.ToggleGroup::UnregisterToggle(UnityEngine.UI.Toggle)
extern void ToggleGroup_UnregisterToggle_m724862AAE8CE184E7336D54F44C5ACBC9858D20A (void);
// 0x00000463 System.Void UnityEngine.UI.ToggleGroup::RegisterToggle(UnityEngine.UI.Toggle)
extern void ToggleGroup_RegisterToggle_m1CC85EE0BE4DA4B993F5C04DBC87F0421BCA1ED3 (void);
// 0x00000464 System.Void UnityEngine.UI.ToggleGroup::EnsureValidState()
extern void ToggleGroup_EnsureValidState_m074ACF3B8A6E2B4FAEFE382BC505F7B0CCEF74C4 (void);
// 0x00000465 System.Boolean UnityEngine.UI.ToggleGroup::AnyTogglesOn()
extern void ToggleGroup_AnyTogglesOn_m4EDBE46AC4C4458B91462F963FA34B9AD8DA4F4B (void);
// 0x00000466 System.Collections.Generic.IEnumerable`1<UnityEngine.UI.Toggle> UnityEngine.UI.ToggleGroup::ActiveToggles()
extern void ToggleGroup_ActiveToggles_mDBD4CB3FCEEB4F5C7ECB5E6D0F7EA17FDDF54300 (void);
// 0x00000467 System.Void UnityEngine.UI.ToggleGroup::SetAllTogglesOff(System.Boolean)
extern void ToggleGroup_SetAllTogglesOff_m5DB321BD06A6B66ADA0B0022766A561BD0AE7BC6 (void);
// 0x00000468 System.Void UnityEngine.UI.ListPool`1::Clear(System.Collections.Generic.List`1<T>)
// 0x00000469 System.Collections.Generic.List`1<T> UnityEngine.UI.ListPool`1::Get()
// 0x0000046A System.Void UnityEngine.UI.ListPool`1::Release(System.Collections.Generic.List`1<T>)
// 0x0000046B System.Void UnityEngine.UI.ListPool`1::.cctor()
// 0x0000046C System.Int32 UnityEngine.UI.ObjectPool`1::get_countAll()
// 0x0000046D System.Void UnityEngine.UI.ObjectPool`1::set_countAll(System.Int32)
// 0x0000046E System.Int32 UnityEngine.UI.ObjectPool`1::get_countActive()
// 0x0000046F System.Int32 UnityEngine.UI.ObjectPool`1::get_countInactive()
// 0x00000470 System.Void UnityEngine.UI.ObjectPool`1::.ctor(UnityEngine.Events.UnityAction`1<T>,UnityEngine.Events.UnityAction`1<T>)
// 0x00000471 T UnityEngine.UI.ObjectPool`1::Get()
// 0x00000472 System.Void UnityEngine.UI.ObjectPool`1::Release(T)
// 0x00000473 System.Void UnityEngine.UI.ReflectionMethodsCache::.ctor()
extern void ReflectionMethodsCache__ctor_m4D4F63AC8FE19E72E654B2CA99A866FDD7992795 (void);
// 0x00000474 UnityEngine.UI.ReflectionMethodsCache UnityEngine.UI.ReflectionMethodsCache::get_Singleton()
extern void ReflectionMethodsCache_get_Singleton_m6C50C55DEEA425161B73545918267BB90B7FCB9B (void);
// 0x00000475 System.Void UnityEngine.UI.ReflectionMethodsCache::.cctor()
extern void ReflectionMethodsCache__cctor_mD5ADC515BEA2AF24353BD7045D1BC482DE1F08C5 (void);
// 0x00000476 System.Void UnityEngine.UI.VertexHelper::.ctor()
extern void VertexHelper__ctor_mF43AA93AF0E1C7EC27B0D6E2207707382A53C115 (void);
// 0x00000477 System.Void UnityEngine.UI.VertexHelper::.ctor(UnityEngine.Mesh)
extern void VertexHelper__ctor_m4FF21AED0081C159CB153B73D0DE4D7AFEC2655D (void);
// 0x00000478 System.Void UnityEngine.UI.VertexHelper::InitializeListIfRequired()
extern void VertexHelper_InitializeListIfRequired_m083C55BC590E01F63EF24171AAFBF57EA8C69AB0 (void);
// 0x00000479 System.Void UnityEngine.UI.VertexHelper::Dispose()
extern void VertexHelper_Dispose_m03C8CF87F673E27160B27FC2AC64DECD2B7F0749 (void);
// 0x0000047A System.Void UnityEngine.UI.VertexHelper::Clear()
extern void VertexHelper_Clear_mDEF52B52B9F138C32027CAA42A0C9302FC899455 (void);
// 0x0000047B System.Int32 UnityEngine.UI.VertexHelper::get_currentVertCount()
extern void VertexHelper_get_currentVertCount_m99ACD97A171FCB5046C7608CAD7399A8E0A6FD3F (void);
// 0x0000047C System.Int32 UnityEngine.UI.VertexHelper::get_currentIndexCount()
extern void VertexHelper_get_currentIndexCount_m071AFF6C0DB763292367B1C2926B41996EF164C9 (void);
// 0x0000047D System.Void UnityEngine.UI.VertexHelper::PopulateUIVertex(UnityEngine.UIVertex&,System.Int32)
extern void VertexHelper_PopulateUIVertex_m75E49AE0377BABEE2C3D1CCA1624DE5668B5C42C (void);
// 0x0000047E System.Void UnityEngine.UI.VertexHelper::SetUIVertex(UnityEngine.UIVertex,System.Int32)
extern void VertexHelper_SetUIVertex_m71EA6FEB875252F25180FA7F3849A962C6231976 (void);
// 0x0000047F System.Void UnityEngine.UI.VertexHelper::FillMesh(UnityEngine.Mesh)
extern void VertexHelper_FillMesh_mBA946D1CEDC24DCCD8A593CF77D0B54D14FDB74B (void);
// 0x00000480 System.Void UnityEngine.UI.VertexHelper::AddVert(UnityEngine.Vector3,UnityEngine.Color32,UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.Vector3,UnityEngine.Vector4)
extern void VertexHelper_AddVert_m9CC5667FED5B7550564C37BBB61E2D9B558C7733 (void);
// 0x00000481 System.Void UnityEngine.UI.VertexHelper::AddVert(UnityEngine.Vector3,UnityEngine.Color32,UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.Vector3,UnityEngine.Vector4)
extern void VertexHelper_AddVert_mD0E98F14CE110C3D1D3DB60E9F7B84D7F4F8616C (void);
// 0x00000482 System.Void UnityEngine.UI.VertexHelper::AddVert(UnityEngine.Vector3,UnityEngine.Color32,UnityEngine.Vector2)
extern void VertexHelper_AddVert_m8133C9A62368C1FA8DD53EB3A42A612AF694E8A6 (void);
// 0x00000483 System.Void UnityEngine.UI.VertexHelper::AddVert(UnityEngine.UIVertex)
extern void VertexHelper_AddVert_m7FB2655449034894FE6FFAD2E1F4A678DB8C4FB3 (void);
// 0x00000484 System.Void UnityEngine.UI.VertexHelper::AddTriangle(System.Int32,System.Int32,System.Int32)
extern void VertexHelper_AddTriangle_mCC7AD55263B747D7653590BC9220D6369D168AF4 (void);
// 0x00000485 System.Void UnityEngine.UI.VertexHelper::AddUIVertexQuad(UnityEngine.UIVertex[])
extern void VertexHelper_AddUIVertexQuad_mDECEEA1FE0985C87BBDF905D8F29F9C2434B14E0 (void);
// 0x00000486 System.Void UnityEngine.UI.VertexHelper::AddUIVertexStream(System.Collections.Generic.List`1<UnityEngine.UIVertex>,System.Collections.Generic.List`1<System.Int32>)
extern void VertexHelper_AddUIVertexStream_mAAA730380EE6D6988274BDD8E86FD0B24BD19BCD (void);
// 0x00000487 System.Void UnityEngine.UI.VertexHelper::AddUIVertexTriangleStream(System.Collections.Generic.List`1<UnityEngine.UIVertex>)
extern void VertexHelper_AddUIVertexTriangleStream_m5A9D5AAECF1B6326FCED054EAC66701416641912 (void);
// 0x00000488 System.Void UnityEngine.UI.VertexHelper::GetUIVertexStream(System.Collections.Generic.List`1<UnityEngine.UIVertex>)
extern void VertexHelper_GetUIVertexStream_m88D1624450F08F926008DAF833DBA2A80BC80FF2 (void);
// 0x00000489 System.Void UnityEngine.UI.VertexHelper::.cctor()
extern void VertexHelper__cctor_mFB392B47FC06B93EE482011E40BE32F0E87CCC17 (void);
// 0x0000048A System.Void UnityEngine.UI.BaseVertexEffect::ModifyVertices(System.Collections.Generic.List`1<UnityEngine.UIVertex>)
// 0x0000048B System.Void UnityEngine.UI.BaseVertexEffect::.ctor()
extern void BaseVertexEffect__ctor_m9356F0465FF34D591F7F41774A4626014230F46F (void);
// 0x0000048C UnityEngine.UI.Graphic UnityEngine.UI.BaseMeshEffect::get_graphic()
extern void BaseMeshEffect_get_graphic_mDD7D8CD6F220B9DE656145A1346EA9799255BE21 (void);
// 0x0000048D System.Void UnityEngine.UI.BaseMeshEffect::OnEnable()
extern void BaseMeshEffect_OnEnable_mEFEC953AFEB543E262347EFCF0FDF0ACAD8FEABC (void);
// 0x0000048E System.Void UnityEngine.UI.BaseMeshEffect::OnDisable()
extern void BaseMeshEffect_OnDisable_m92E4E2BAB5D8D713D63A74657C630AE41F48BF7A (void);
// 0x0000048F System.Void UnityEngine.UI.BaseMeshEffect::OnDidApplyAnimationProperties()
extern void BaseMeshEffect_OnDidApplyAnimationProperties_m91A58D830823680102ABE042673306DEDDD0568C (void);
// 0x00000490 System.Void UnityEngine.UI.BaseMeshEffect::ModifyMesh(UnityEngine.Mesh)
extern void BaseMeshEffect_ModifyMesh_mFA7C06FDE36C1C1DE82D2FE6AE36031B668A74F9 (void);
// 0x00000491 System.Void UnityEngine.UI.BaseMeshEffect::ModifyMesh(UnityEngine.UI.VertexHelper)
// 0x00000492 System.Void UnityEngine.UI.BaseMeshEffect::.ctor()
extern void BaseMeshEffect__ctor_m544B1FC50DE8DE4A5725C0CE17AD1F2BFE951B9E (void);
// 0x00000493 System.Void UnityEngine.UI.IVertexModifier::ModifyVertices(System.Collections.Generic.List`1<UnityEngine.UIVertex>)
// 0x00000494 System.Void UnityEngine.UI.IMeshModifier::ModifyMesh(UnityEngine.Mesh)
// 0x00000495 System.Void UnityEngine.UI.IMeshModifier::ModifyMesh(UnityEngine.UI.VertexHelper)
// 0x00000496 System.Void UnityEngine.UI.Outline::.ctor()
extern void Outline__ctor_m76F9BA58973343AD9E785DBDF781215E3D3D65D4 (void);
// 0x00000497 System.Void UnityEngine.UI.Outline::ModifyMesh(UnityEngine.UI.VertexHelper)
extern void Outline_ModifyMesh_m6A282A1ABD8F14845A69A4C65AC61DF57C89BBC5 (void);
// 0x00000498 System.Void UnityEngine.UI.PositionAsUV1::.ctor()
extern void PositionAsUV1__ctor_mF252120BE2353EBFC62C00CE7995049118A2B14A (void);
// 0x00000499 System.Void UnityEngine.UI.PositionAsUV1::ModifyMesh(UnityEngine.UI.VertexHelper)
extern void PositionAsUV1_ModifyMesh_m4407B9AE1603556116C6352738769D00CDA11419 (void);
// 0x0000049A System.Void UnityEngine.UI.Shadow::.ctor()
extern void Shadow__ctor_m776322C362BCFCD3EF098209CE8D98C32772E52A (void);
// 0x0000049B UnityEngine.Color UnityEngine.UI.Shadow::get_effectColor()
extern void Shadow_get_effectColor_mC7BF6CDDEC9998A03E993ED9216092782C66EC16 (void);
// 0x0000049C System.Void UnityEngine.UI.Shadow::set_effectColor(UnityEngine.Color)
extern void Shadow_set_effectColor_mB590179B73124FC979887516F9D8773BE7A6B776 (void);
// 0x0000049D UnityEngine.Vector2 UnityEngine.UI.Shadow::get_effectDistance()
extern void Shadow_get_effectDistance_m4B496C7CE07930847630E0E636E3C255D78B08BB (void);
// 0x0000049E System.Void UnityEngine.UI.Shadow::set_effectDistance(UnityEngine.Vector2)
extern void Shadow_set_effectDistance_m06F578865EBE71228AE60DD7E8D1B10DE4589F8E (void);
// 0x0000049F System.Boolean UnityEngine.UI.Shadow::get_useGraphicAlpha()
extern void Shadow_get_useGraphicAlpha_mC1F216671CC11DC92B9CCCC6AE884A1A2D30AE3E (void);
// 0x000004A0 System.Void UnityEngine.UI.Shadow::set_useGraphicAlpha(System.Boolean)
extern void Shadow_set_useGraphicAlpha_m700B8D7D0DD8726B36D415997B123E275B83D6C4 (void);
// 0x000004A1 System.Void UnityEngine.UI.Shadow::ApplyShadowZeroAlloc(System.Collections.Generic.List`1<UnityEngine.UIVertex>,UnityEngine.Color32,System.Int32,System.Int32,System.Single,System.Single)
extern void Shadow_ApplyShadowZeroAlloc_mE8BF57D4B5976303B5A5516E893A7DEFFE38675F (void);
// 0x000004A2 System.Void UnityEngine.UI.Shadow::ApplyShadow(System.Collections.Generic.List`1<UnityEngine.UIVertex>,UnityEngine.Color32,System.Int32,System.Int32,System.Single,System.Single)
extern void Shadow_ApplyShadow_mAF02B8482E4012D667AE5326C4DB4B1FEAFFA39D (void);
// 0x000004A3 System.Void UnityEngine.UI.Shadow::ModifyMesh(UnityEngine.UI.VertexHelper)
extern void Shadow_ModifyMesh_m8C99018A8D5D3652249C7C6DC0E9E7AD0CA5BC0C (void);
// 0x000004A4 System.Void UnityEngine.UI.Collections.IndexedSet`1::Add(T)
// 0x000004A5 System.Boolean UnityEngine.UI.Collections.IndexedSet`1::AddUnique(T)
// 0x000004A6 System.Boolean UnityEngine.UI.Collections.IndexedSet`1::Remove(T)
// 0x000004A7 System.Collections.Generic.IEnumerator`1<T> UnityEngine.UI.Collections.IndexedSet`1::GetEnumerator()
// 0x000004A8 System.Collections.IEnumerator UnityEngine.UI.Collections.IndexedSet`1::System.Collections.IEnumerable.GetEnumerator()
// 0x000004A9 System.Void UnityEngine.UI.Collections.IndexedSet`1::Clear()
// 0x000004AA System.Boolean UnityEngine.UI.Collections.IndexedSet`1::Contains(T)
// 0x000004AB System.Void UnityEngine.UI.Collections.IndexedSet`1::CopyTo(T[],System.Int32)
// 0x000004AC System.Int32 UnityEngine.UI.Collections.IndexedSet`1::get_Count()
// 0x000004AD System.Boolean UnityEngine.UI.Collections.IndexedSet`1::get_IsReadOnly()
// 0x000004AE System.Int32 UnityEngine.UI.Collections.IndexedSet`1::IndexOf(T)
// 0x000004AF System.Void UnityEngine.UI.Collections.IndexedSet`1::Insert(System.Int32,T)
// 0x000004B0 System.Void UnityEngine.UI.Collections.IndexedSet`1::RemoveAt(System.Int32)
// 0x000004B1 T UnityEngine.UI.Collections.IndexedSet`1::get_Item(System.Int32)
// 0x000004B2 System.Void UnityEngine.UI.Collections.IndexedSet`1::set_Item(System.Int32,T)
// 0x000004B3 System.Void UnityEngine.UI.Collections.IndexedSet`1::RemoveAll(System.Predicate`1<T>)
// 0x000004B4 System.Void UnityEngine.UI.Collections.IndexedSet`1::Sort(System.Comparison`1<T>)
// 0x000004B5 System.Void UnityEngine.UI.Collections.IndexedSet`1::.ctor()
// 0x000004B6 System.Void UnityEngine.UI.CoroutineTween.ITweenValue::TweenValue(System.Single)
// 0x000004B7 System.Boolean UnityEngine.UI.CoroutineTween.ITweenValue::get_ignoreTimeScale()
// 0x000004B8 System.Single UnityEngine.UI.CoroutineTween.ITweenValue::get_duration()
// 0x000004B9 System.Boolean UnityEngine.UI.CoroutineTween.ITweenValue::ValidTarget()
// 0x000004BA UnityEngine.Color UnityEngine.UI.CoroutineTween.ColorTween::get_startColor()
extern void ColorTween_get_startColor_mA979B663DFD611DAC95F4A7B98AA36E24EE5E3D6 (void);
// 0x000004BB System.Void UnityEngine.UI.CoroutineTween.ColorTween::set_startColor(UnityEngine.Color)
extern void ColorTween_set_startColor_mD976BED0C47332CB811EA6B68230FFAB69DCE82D (void);
// 0x000004BC UnityEngine.Color UnityEngine.UI.CoroutineTween.ColorTween::get_targetColor()
extern void ColorTween_get_targetColor_m2620FDCF03617764286DCDF8000AA3BE59C9E7AF (void);
// 0x000004BD System.Void UnityEngine.UI.CoroutineTween.ColorTween::set_targetColor(UnityEngine.Color)
extern void ColorTween_set_targetColor_m9BA400CD92F2182DFEDEA4494B66501C7596DD69 (void);
// 0x000004BE UnityEngine.UI.CoroutineTween.ColorTween/ColorTweenMode UnityEngine.UI.CoroutineTween.ColorTween::get_tweenMode()
extern void ColorTween_get_tweenMode_m908DEFB153497AC18AD08CB73AFF655C1F6D05FB (void);
// 0x000004BF System.Void UnityEngine.UI.CoroutineTween.ColorTween::set_tweenMode(UnityEngine.UI.CoroutineTween.ColorTween/ColorTweenMode)
extern void ColorTween_set_tweenMode_m88B5C1FA53770422C80E61B0958CA7B94E6D8B27 (void);
// 0x000004C0 System.Single UnityEngine.UI.CoroutineTween.ColorTween::get_duration()
extern void ColorTween_get_duration_mC4A1E3C2EA46A5C657A2B9DA240C796F770ECC5F (void);
// 0x000004C1 System.Void UnityEngine.UI.CoroutineTween.ColorTween::set_duration(System.Single)
extern void ColorTween_set_duration_m069BFDD0F6EABA4869ABC1F4620C54F749950E3D (void);
// 0x000004C2 System.Boolean UnityEngine.UI.CoroutineTween.ColorTween::get_ignoreTimeScale()
extern void ColorTween_get_ignoreTimeScale_m6A06826E19314EFE9783E505C75CFC76E42E8F05 (void);
// 0x000004C3 System.Void UnityEngine.UI.CoroutineTween.ColorTween::set_ignoreTimeScale(System.Boolean)
extern void ColorTween_set_ignoreTimeScale_m42071C6EB064666F7FF945EEC5B5261836E8E593 (void);
// 0x000004C4 System.Void UnityEngine.UI.CoroutineTween.ColorTween::TweenValue(System.Single)
extern void ColorTween_TweenValue_m20FCBA50CE9328956973861A9CB0A1FD97265A58 (void);
// 0x000004C5 System.Void UnityEngine.UI.CoroutineTween.ColorTween::AddOnChangedCallback(UnityEngine.Events.UnityAction`1<UnityEngine.Color>)
extern void ColorTween_AddOnChangedCallback_m8B7B35D5B912C0BCEFB275B54A3A2EB8D1DD7DE8 (void);
// 0x000004C6 System.Boolean UnityEngine.UI.CoroutineTween.ColorTween::GetIgnoreTimescale()
extern void ColorTween_GetIgnoreTimescale_m5100D5725C73E6DB3718A2CF33C9CB46CA27731E (void);
// 0x000004C7 System.Single UnityEngine.UI.CoroutineTween.ColorTween::GetDuration()
extern void ColorTween_GetDuration_m327EABA3FBCD9635DCD360834176D3AEDBFA88B0 (void);
// 0x000004C8 System.Boolean UnityEngine.UI.CoroutineTween.ColorTween::ValidTarget()
extern void ColorTween_ValidTarget_mCFF8428CFF8D45A85E4EE612263E751ED0B5987C (void);
// 0x000004C9 System.Single UnityEngine.UI.CoroutineTween.FloatTween::get_startValue()
extern void FloatTween_get_startValue_m6DC736717E2EAD27CE41A6CD292B6D28AE1DED1E (void);
// 0x000004CA System.Void UnityEngine.UI.CoroutineTween.FloatTween::set_startValue(System.Single)
extern void FloatTween_set_startValue_m34ECE8005F47D60A3F5AF976FF28881A2200B549 (void);
// 0x000004CB System.Single UnityEngine.UI.CoroutineTween.FloatTween::get_targetValue()
extern void FloatTween_get_targetValue_m15E266DEA747D1DD8F49681E9E6AFD7FADBEB027 (void);
// 0x000004CC System.Void UnityEngine.UI.CoroutineTween.FloatTween::set_targetValue(System.Single)
extern void FloatTween_set_targetValue_m04567CCFC5510BA34D68C7A2C4AE32D400D59C3E (void);
// 0x000004CD System.Single UnityEngine.UI.CoroutineTween.FloatTween::get_duration()
extern void FloatTween_get_duration_mBECFBEC57BDC30B54D0638873BA3313A8F7232F5 (void);
// 0x000004CE System.Void UnityEngine.UI.CoroutineTween.FloatTween::set_duration(System.Single)
extern void FloatTween_set_duration_m7E3C3B6D6F9D1C5D9AE051ED64915029E8B4F094 (void);
// 0x000004CF System.Boolean UnityEngine.UI.CoroutineTween.FloatTween::get_ignoreTimeScale()
extern void FloatTween_get_ignoreTimeScale_mA7B69D72E1D52EF1890C89D5690D345B852C7239 (void);
// 0x000004D0 System.Void UnityEngine.UI.CoroutineTween.FloatTween::set_ignoreTimeScale(System.Boolean)
extern void FloatTween_set_ignoreTimeScale_m6826FE67438AA7F1E4ECB85EC83812BC2F6F092B (void);
// 0x000004D1 System.Void UnityEngine.UI.CoroutineTween.FloatTween::TweenValue(System.Single)
extern void FloatTween_TweenValue_m4E4418FB7FBDC7CBF96D95518DFACF25BCBE8EB3 (void);
// 0x000004D2 System.Void UnityEngine.UI.CoroutineTween.FloatTween::AddOnChangedCallback(UnityEngine.Events.UnityAction`1<System.Single>)
extern void FloatTween_AddOnChangedCallback_m56955D43A7CDE997CE447A1C69CA708E8190E9AE (void);
// 0x000004D3 System.Boolean UnityEngine.UI.CoroutineTween.FloatTween::GetIgnoreTimescale()
extern void FloatTween_GetIgnoreTimescale_mB93B6C1BAD120F59F58DFE9409A64DE3A4790D88 (void);
// 0x000004D4 System.Single UnityEngine.UI.CoroutineTween.FloatTween::GetDuration()
extern void FloatTween_GetDuration_m81D2D1E8D8AEDFDF03B54F1AF71A74824480B178 (void);
// 0x000004D5 System.Boolean UnityEngine.UI.CoroutineTween.FloatTween::ValidTarget()
extern void FloatTween_ValidTarget_m917EB0D30E72AC75D90D1D8F11B1D7EBBD00ECAE (void);
// 0x000004D6 System.Collections.IEnumerator UnityEngine.UI.CoroutineTween.TweenRunner`1::Start(T)
// 0x000004D7 System.Void UnityEngine.UI.CoroutineTween.TweenRunner`1::Init(UnityEngine.MonoBehaviour)
// 0x000004D8 System.Void UnityEngine.UI.CoroutineTween.TweenRunner`1::StartTween(T)
// 0x000004D9 System.Void UnityEngine.UI.CoroutineTween.TweenRunner`1::StopTween()
// 0x000004DA System.Void UnityEngine.UI.CoroutineTween.TweenRunner`1::.ctor()
// 0x000004DB UnityEngine.Vector2 UnityEngine.EventSystems.AxisEventData::get_moveVector()
extern void AxisEventData_get_moveVector_mCB9151FF8AFE8DC43886E715AD4B9932644DC171 (void);
// 0x000004DC System.Void UnityEngine.EventSystems.AxisEventData::set_moveVector(UnityEngine.Vector2)
extern void AxisEventData_set_moveVector_m355ADAD19DE3EA67459EAE40FAEAEBE93414FEA3 (void);
// 0x000004DD UnityEngine.EventSystems.MoveDirection UnityEngine.EventSystems.AxisEventData::get_moveDir()
extern void AxisEventData_get_moveDir_mD9CF8343509BAE60C581138D824F9C53659DBBD4 (void);
// 0x000004DE System.Void UnityEngine.EventSystems.AxisEventData::set_moveDir(UnityEngine.EventSystems.MoveDirection)
extern void AxisEventData_set_moveDir_mD16579255C9B76717A3B349BCFBB371044E23EFA (void);
// 0x000004DF System.Void UnityEngine.EventSystems.AxisEventData::.ctor(UnityEngine.EventSystems.EventSystem)
extern void AxisEventData__ctor_m6854820EBB8321AD2472069A2D55A2242D0A51B1 (void);
// 0x000004E0 System.Void UnityEngine.EventSystems.AbstractEventData::Reset()
extern void AbstractEventData_Reset_mFD0C0918347F74594FE8C791C5A939FEB953308D (void);
// 0x000004E1 System.Void UnityEngine.EventSystems.AbstractEventData::Use()
extern void AbstractEventData_Use_mB892C2F5FE39571FAFFB247C795233438B15A17B (void);
// 0x000004E2 System.Boolean UnityEngine.EventSystems.AbstractEventData::get_used()
extern void AbstractEventData_get_used_mC9500818C43B1C96B532F4D5DF316D25ADC1CACA (void);
// 0x000004E3 System.Void UnityEngine.EventSystems.AbstractEventData::.ctor()
extern void AbstractEventData__ctor_mD80BC34325B6235E48E02789647C69D4F283434E (void);
// 0x000004E4 System.Void UnityEngine.EventSystems.BaseEventData::.ctor(UnityEngine.EventSystems.EventSystem)
extern void BaseEventData__ctor_mA58C6566C43F8624C85203FAE2B27528C584675E (void);
// 0x000004E5 UnityEngine.EventSystems.BaseInputModule UnityEngine.EventSystems.BaseEventData::get_currentInputModule()
extern void BaseEventData_get_currentInputModule_m0887B0CB20374A4AA10D4C1B480E305581533512 (void);
// 0x000004E6 UnityEngine.GameObject UnityEngine.EventSystems.BaseEventData::get_selectedObject()
extern void BaseEventData_get_selectedObject_m234C3A09897246D2BF97D43017C9AE476BD91770 (void);
// 0x000004E7 System.Void UnityEngine.EventSystems.BaseEventData::set_selectedObject(UnityEngine.GameObject)
extern void BaseEventData_set_selectedObject_mE98E9692C6A7AF46D33C625CEAFDF56AFEE5FEA3 (void);
// 0x000004E8 UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::get_pointerEnter()
extern void PointerEventData_get_pointerEnter_m47E87ACB1557B6380D0E66F57C2F9FFFD5E86DC2 (void);
// 0x000004E9 System.Void UnityEngine.EventSystems.PointerEventData::set_pointerEnter(UnityEngine.GameObject)
extern void PointerEventData_set_pointerEnter_mB891C530B173BCDF4FDD5CC757A30AE498D77360 (void);
// 0x000004EA UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::get_lastPress()
extern void PointerEventData_get_lastPress_m6B005D786FC5B30ECD8D5BC068420D0C361357F4 (void);
// 0x000004EB System.Void UnityEngine.EventSystems.PointerEventData::set_lastPress(UnityEngine.GameObject)
extern void PointerEventData_set_lastPress_m0E97AFEEB05C4DDEDA0465481CFE09EFDF617319 (void);
// 0x000004EC UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::get_rawPointerPress()
extern void PointerEventData_get_rawPointerPress_m6CECEFBAD7C50F04BD65172000B0BB916578B494 (void);
// 0x000004ED System.Void UnityEngine.EventSystems.PointerEventData::set_rawPointerPress(UnityEngine.GameObject)
extern void PointerEventData_set_rawPointerPress_mEBAE6DDF7485B81E092BDE13462926FB5C251BB2 (void);
// 0x000004EE UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::get_pointerDrag()
extern void PointerEventData_get_pointerDrag_m20299CC70BC6DA11AFDB8A33A957AC306FBEE5C7 (void);
// 0x000004EF System.Void UnityEngine.EventSystems.PointerEventData::set_pointerDrag(UnityEngine.GameObject)
extern void PointerEventData_set_pointerDrag_mAA21AD97ABF508FD1D2313C36CAEF3A969F1D35D (void);
// 0x000004F0 UnityEngine.EventSystems.RaycastResult UnityEngine.EventSystems.PointerEventData::get_pointerCurrentRaycast()
extern void PointerEventData_get_pointerCurrentRaycast_mE58F786484E13AF2E6C2706E20C889E7453E3A7A (void);
// 0x000004F1 System.Void UnityEngine.EventSystems.PointerEventData::set_pointerCurrentRaycast(UnityEngine.EventSystems.RaycastResult)
extern void PointerEventData_set_pointerCurrentRaycast_mA63CA749AC5410AF7D28F4C924BA3372E12F61FC (void);
// 0x000004F2 UnityEngine.EventSystems.RaycastResult UnityEngine.EventSystems.PointerEventData::get_pointerPressRaycast()
extern void PointerEventData_get_pointerPressRaycast_m722BCA823E0405C9DF20312CDFBBEB5B1B05B7AE (void);
// 0x000004F3 System.Void UnityEngine.EventSystems.PointerEventData::set_pointerPressRaycast(UnityEngine.EventSystems.RaycastResult)
extern void PointerEventData_set_pointerPressRaycast_m2F371C6E5AB2AAB39C6F7F889594D480D797D5FD (void);
// 0x000004F4 System.Boolean UnityEngine.EventSystems.PointerEventData::get_eligibleForClick()
extern void PointerEventData_get_eligibleForClick_m2DAAE590F749D77C50A3665B848B6F778518E29A (void);
// 0x000004F5 System.Void UnityEngine.EventSystems.PointerEventData::set_eligibleForClick(System.Boolean)
extern void PointerEventData_set_eligibleForClick_m40B82588BC83E4CF72209B9B1A50585CCE82ABD2 (void);
// 0x000004F6 System.Int32 UnityEngine.EventSystems.PointerEventData::get_pointerId()
extern void PointerEventData_get_pointerId_mD351BA661F70CDBB48AA5E80496179069E620D97 (void);
// 0x000004F7 System.Void UnityEngine.EventSystems.PointerEventData::set_pointerId(System.Int32)
extern void PointerEventData_set_pointerId_m078CD15662E127124C86C88ACB3C5B44E61F1A54 (void);
// 0x000004F8 UnityEngine.Vector2 UnityEngine.EventSystems.PointerEventData::get_position()
extern void PointerEventData_get_position_mF25FC495A9C968C65BF34B5984616CBFB6332D55 (void);
// 0x000004F9 System.Void UnityEngine.EventSystems.PointerEventData::set_position(UnityEngine.Vector2)
extern void PointerEventData_set_position_m9BDCBF26C28C01F781ACB8FC87448CB4ADD0BBD5 (void);
// 0x000004FA UnityEngine.Vector2 UnityEngine.EventSystems.PointerEventData::get_delta()
extern void PointerEventData_get_delta_mC5D62E985D40A7708316C6E07B699B96D9C8184E (void);
// 0x000004FB System.Void UnityEngine.EventSystems.PointerEventData::set_delta(UnityEngine.Vector2)
extern void PointerEventData_set_delta_mC9CBC11B2F8147F7E94590769271297EE018682F (void);
// 0x000004FC UnityEngine.Vector2 UnityEngine.EventSystems.PointerEventData::get_pressPosition()
extern void PointerEventData_get_pressPosition_m7C8D5A54C81C801EB577A60718C4211DFA1A3624 (void);
// 0x000004FD System.Void UnityEngine.EventSystems.PointerEventData::set_pressPosition(UnityEngine.Vector2)
extern void PointerEventData_set_pressPosition_m3F5805FAD17E1BC44B84795506DE7EBA7215A46C (void);
// 0x000004FE UnityEngine.Vector3 UnityEngine.EventSystems.PointerEventData::get_worldPosition()
extern void PointerEventData_get_worldPosition_mF0DC1B57F31BB6FB8FFDD666603FF0909940EFA8 (void);
// 0x000004FF System.Void UnityEngine.EventSystems.PointerEventData::set_worldPosition(UnityEngine.Vector3)
extern void PointerEventData_set_worldPosition_m69BBE1250B8D37869B056EDD7FE6DED1A5B8438E (void);
// 0x00000500 UnityEngine.Vector3 UnityEngine.EventSystems.PointerEventData::get_worldNormal()
extern void PointerEventData_get_worldNormal_m310D7AC52A1EBD88080267B39ADA66A6EC778D26 (void);
// 0x00000501 System.Void UnityEngine.EventSystems.PointerEventData::set_worldNormal(UnityEngine.Vector3)
extern void PointerEventData_set_worldNormal_mA59C3E7AA9F72E8484C51AB6F276EE53AA7CEF49 (void);
// 0x00000502 System.Single UnityEngine.EventSystems.PointerEventData::get_clickTime()
extern void PointerEventData_get_clickTime_m22DF8D2239FF9E101B69E3C27710B3512328BBF3 (void);
// 0x00000503 System.Void UnityEngine.EventSystems.PointerEventData::set_clickTime(System.Single)
extern void PointerEventData_set_clickTime_m65041A6875D4A8091A0F7195D8E3D11F1DE49FFD (void);
// 0x00000504 System.Int32 UnityEngine.EventSystems.PointerEventData::get_clickCount()
extern void PointerEventData_get_clickCount_m171A2D241BD02AC43908420497688C5B354BF6E9 (void);
// 0x00000505 System.Void UnityEngine.EventSystems.PointerEventData::set_clickCount(System.Int32)
extern void PointerEventData_set_clickCount_mE77013E6A569F7BE54306B6AE6DE6B24396789F0 (void);
// 0x00000506 UnityEngine.Vector2 UnityEngine.EventSystems.PointerEventData::get_scrollDelta()
extern void PointerEventData_get_scrollDelta_mF473A122C860EC5279F6F5D085912BDA6418690B (void);
// 0x00000507 System.Void UnityEngine.EventSystems.PointerEventData::set_scrollDelta(UnityEngine.Vector2)
extern void PointerEventData_set_scrollDelta_mC28D770F77171619EADE3FADA463866F6E4F3733 (void);
// 0x00000508 System.Boolean UnityEngine.EventSystems.PointerEventData::get_useDragThreshold()
extern void PointerEventData_get_useDragThreshold_mD34A3546D654B48F02FA3920DBEC208891257482 (void);
// 0x00000509 System.Void UnityEngine.EventSystems.PointerEventData::set_useDragThreshold(System.Boolean)
extern void PointerEventData_set_useDragThreshold_mB742BB006F245766C00371FF33B680FF3F0F48F1 (void);
// 0x0000050A System.Boolean UnityEngine.EventSystems.PointerEventData::get_dragging()
extern void PointerEventData_get_dragging_mDB8CAFA859F6B7AC6EABAE340FA047BC2620927F (void);
// 0x0000050B System.Void UnityEngine.EventSystems.PointerEventData::set_dragging(System.Boolean)
extern void PointerEventData_set_dragging_m34110A723023758249425A1F3C98EFA27BF19F45 (void);
// 0x0000050C UnityEngine.EventSystems.PointerEventData/InputButton UnityEngine.EventSystems.PointerEventData::get_button()
extern void PointerEventData_get_button_mC662D5DAC02F0ED6AE9205259116CC91BB92BD3E (void);
// 0x0000050D System.Void UnityEngine.EventSystems.PointerEventData::set_button(UnityEngine.EventSystems.PointerEventData/InputButton)
extern void PointerEventData_set_button_m240561B7D92B4AD898CDBD887828B48BBDD0DD2A (void);
// 0x0000050E System.Void UnityEngine.EventSystems.PointerEventData::.ctor(UnityEngine.EventSystems.EventSystem)
extern void PointerEventData__ctor_m121A903CE81C0758A49C721F7C1668362BFAE7E4 (void);
// 0x0000050F System.Boolean UnityEngine.EventSystems.PointerEventData::IsPointerMoving()
extern void PointerEventData_IsPointerMoving_m898C7306913917BFE04B3CF7A7A463EE94979D68 (void);
// 0x00000510 System.Boolean UnityEngine.EventSystems.PointerEventData::IsScrolling()
extern void PointerEventData_IsScrolling_m47CCF26BC0D686E601614A08253EDA068B7690B3 (void);
// 0x00000511 UnityEngine.Camera UnityEngine.EventSystems.PointerEventData::get_enterEventCamera()
extern void PointerEventData_get_enterEventCamera_m4DCBA203F50F1F4D30118573061FD4634D4B4915 (void);
// 0x00000512 UnityEngine.Camera UnityEngine.EventSystems.PointerEventData::get_pressEventCamera()
extern void PointerEventData_get_pressEventCamera_mC505603722C7C3CBEE8C56029C2CA6C5CC769E76 (void);
// 0x00000513 UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::get_pointerPress()
extern void PointerEventData_get_pointerPress_m7B8C9E16E2B9E86C4DA93A2A2E3A58E56536406B (void);
// 0x00000514 System.Void UnityEngine.EventSystems.PointerEventData::set_pointerPress(UnityEngine.GameObject)
extern void PointerEventData_set_pointerPress_m053AF3BF19752D9271AAC6A633B2718C61870D33 (void);
// 0x00000515 System.String UnityEngine.EventSystems.PointerEventData::ToString()
extern void PointerEventData_ToString_mFFD67D75B8BC560CBFE5E4D417D7F44124493991 (void);
// 0x00000516 System.Void UnityEngine.EventSystems.IPointerEnterHandler::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
// 0x00000517 System.Void UnityEngine.EventSystems.IPointerExitHandler::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
// 0x00000518 System.Void UnityEngine.EventSystems.IPointerDownHandler::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
// 0x00000519 System.Void UnityEngine.EventSystems.IPointerUpHandler::OnPointerUp(UnityEngine.EventSystems.PointerEventData)
// 0x0000051A System.Void UnityEngine.EventSystems.IPointerClickHandler::OnPointerClick(UnityEngine.EventSystems.PointerEventData)
// 0x0000051B System.Void UnityEngine.EventSystems.IBeginDragHandler::OnBeginDrag(UnityEngine.EventSystems.PointerEventData)
// 0x0000051C System.Void UnityEngine.EventSystems.IInitializePotentialDragHandler::OnInitializePotentialDrag(UnityEngine.EventSystems.PointerEventData)
// 0x0000051D System.Void UnityEngine.EventSystems.IDragHandler::OnDrag(UnityEngine.EventSystems.PointerEventData)
// 0x0000051E System.Void UnityEngine.EventSystems.IEndDragHandler::OnEndDrag(UnityEngine.EventSystems.PointerEventData)
// 0x0000051F System.Void UnityEngine.EventSystems.IDropHandler::OnDrop(UnityEngine.EventSystems.PointerEventData)
// 0x00000520 System.Void UnityEngine.EventSystems.IScrollHandler::OnScroll(UnityEngine.EventSystems.PointerEventData)
// 0x00000521 System.Void UnityEngine.EventSystems.IUpdateSelectedHandler::OnUpdateSelected(UnityEngine.EventSystems.BaseEventData)
// 0x00000522 System.Void UnityEngine.EventSystems.ISelectHandler::OnSelect(UnityEngine.EventSystems.BaseEventData)
// 0x00000523 System.Void UnityEngine.EventSystems.IDeselectHandler::OnDeselect(UnityEngine.EventSystems.BaseEventData)
// 0x00000524 System.Void UnityEngine.EventSystems.IMoveHandler::OnMove(UnityEngine.EventSystems.AxisEventData)
// 0x00000525 System.Void UnityEngine.EventSystems.ISubmitHandler::OnSubmit(UnityEngine.EventSystems.BaseEventData)
// 0x00000526 System.Void UnityEngine.EventSystems.ICancelHandler::OnCancel(UnityEngine.EventSystems.BaseEventData)
// 0x00000527 UnityEngine.EventSystems.EventSystem UnityEngine.EventSystems.EventSystem::get_current()
extern void EventSystem_get_current_m3151477735829089F66A3E46AD6DAB14CFDDE7BD (void);
// 0x00000528 System.Void UnityEngine.EventSystems.EventSystem::set_current(UnityEngine.EventSystems.EventSystem)
extern void EventSystem_set_current_mB077A890E5CB75D7987793733E17B95F12AF006E (void);
// 0x00000529 System.Boolean UnityEngine.EventSystems.EventSystem::get_sendNavigationEvents()
extern void EventSystem_get_sendNavigationEvents_m0DB01018B4EF41A51D0AD481DD07F381ED2223DF (void);
// 0x0000052A System.Void UnityEngine.EventSystems.EventSystem::set_sendNavigationEvents(System.Boolean)
extern void EventSystem_set_sendNavigationEvents_m64D25EBFE249DB5A9DC1B285321B92880B8EC75D (void);
// 0x0000052B System.Int32 UnityEngine.EventSystems.EventSystem::get_pixelDragThreshold()
extern void EventSystem_get_pixelDragThreshold_mE7B5BD351A7B6CD3881D212B84351F23C54AC724 (void);
// 0x0000052C System.Void UnityEngine.EventSystems.EventSystem::set_pixelDragThreshold(System.Int32)
extern void EventSystem_set_pixelDragThreshold_mD5A11B879BA7EEFE0B4F91E0CED2AC59799E10D5 (void);
// 0x0000052D UnityEngine.EventSystems.BaseInputModule UnityEngine.EventSystems.EventSystem::get_currentInputModule()
extern void EventSystem_get_currentInputModule_mAA917C940E32ECAC4324D6824A9E0A951F16D891 (void);
// 0x0000052E UnityEngine.GameObject UnityEngine.EventSystems.EventSystem::get_firstSelectedGameObject()
extern void EventSystem_get_firstSelectedGameObject_m8CAFDA874F89BDA34E0984860046C1C171B200E1 (void);
// 0x0000052F System.Void UnityEngine.EventSystems.EventSystem::set_firstSelectedGameObject(UnityEngine.GameObject)
extern void EventSystem_set_firstSelectedGameObject_m27C825634467206443B41E4D133DBCE4E4A31EAE (void);
// 0x00000530 UnityEngine.GameObject UnityEngine.EventSystems.EventSystem::get_currentSelectedGameObject()
extern void EventSystem_get_currentSelectedGameObject_mE28E78D268403602DE1FB6F059EE3E9CDB7325A4 (void);
// 0x00000531 UnityEngine.GameObject UnityEngine.EventSystems.EventSystem::get_lastSelectedGameObject()
extern void EventSystem_get_lastSelectedGameObject_m761188B5E33641891010B7BBBEEDDB1F267A6A29 (void);
// 0x00000532 System.Boolean UnityEngine.EventSystems.EventSystem::get_isFocused()
extern void EventSystem_get_isFocused_m421DE003FCADF582AF1D7F0B8B036513E9743294 (void);
// 0x00000533 System.Void UnityEngine.EventSystems.EventSystem::.ctor()
extern void EventSystem__ctor_mC74FA56B3E82BA853040EEE86272224F686C13F1 (void);
// 0x00000534 System.Void UnityEngine.EventSystems.EventSystem::UpdateModules()
extern void EventSystem_UpdateModules_mF34D9E9C84AE5FF0968292C4E3390AD0AB89DBA9 (void);
// 0x00000535 System.Boolean UnityEngine.EventSystems.EventSystem::get_alreadySelecting()
extern void EventSystem_get_alreadySelecting_mEDDA8DD718BFE62CCE2520CE17304B7EC80CE9B2 (void);
// 0x00000536 System.Void UnityEngine.EventSystems.EventSystem::SetSelectedGameObject(UnityEngine.GameObject,UnityEngine.EventSystems.BaseEventData)
extern void EventSystem_SetSelectedGameObject_m3347D67C1A6386E6D7AF89773DC2960953B9C702 (void);
// 0x00000537 UnityEngine.EventSystems.BaseEventData UnityEngine.EventSystems.EventSystem::get_baseEventDataCache()
extern void EventSystem_get_baseEventDataCache_m2B14076E5EF918BE1A94F16DE1A827AC1401BC89 (void);
// 0x00000538 System.Void UnityEngine.EventSystems.EventSystem::SetSelectedGameObject(UnityEngine.GameObject)
extern void EventSystem_SetSelectedGameObject_mF38F3DE62EC3450270C3053C9EBAB425550B07A0 (void);
// 0x00000539 System.Int32 UnityEngine.EventSystems.EventSystem::RaycastComparer(UnityEngine.EventSystems.RaycastResult,UnityEngine.EventSystems.RaycastResult)
extern void EventSystem_RaycastComparer_mBB4C501E79DC58EABE34056EEB4A56843DEA6AB3 (void);
// 0x0000053A System.Void UnityEngine.EventSystems.EventSystem::RaycastAll(UnityEngine.EventSystems.PointerEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void EventSystem_RaycastAll_mF78E1781C8161DEEF24B6B3FCCC1037787F9A439 (void);
// 0x0000053B System.Boolean UnityEngine.EventSystems.EventSystem::IsPointerOverGameObject()
extern void EventSystem_IsPointerOverGameObject_mA47031510BEEA565F5892CC04ACE303804BD7631 (void);
// 0x0000053C System.Boolean UnityEngine.EventSystems.EventSystem::IsPointerOverGameObject(System.Int32)
extern void EventSystem_IsPointerOverGameObject_m00CDF0FF5EA712D14B7966DD8270931A13EABA91 (void);
// 0x0000053D System.Void UnityEngine.EventSystems.EventSystem::OnEnable()
extern void EventSystem_OnEnable_mB3C6CDEC37085FFB96914A768A444B2A97BC891E (void);
// 0x0000053E System.Void UnityEngine.EventSystems.EventSystem::OnDisable()
extern void EventSystem_OnDisable_mF4AB795E6BBF4DD6EDA359E954F04D8498B707C0 (void);
// 0x0000053F System.Void UnityEngine.EventSystems.EventSystem::TickModules()
extern void EventSystem_TickModules_m7C60756590E96EBA52FEA961ED6F3548E40C9231 (void);
// 0x00000540 System.Void UnityEngine.EventSystems.EventSystem::OnApplicationFocus(System.Boolean)
extern void EventSystem_OnApplicationFocus_mEAB25CFE6171088D62CAA9BE8697B9E24FE5B7F8 (void);
// 0x00000541 System.Void UnityEngine.EventSystems.EventSystem::Update()
extern void EventSystem_Update_m12CAEF521A10D406D1A6EA01E00DD851683C7208 (void);
// 0x00000542 System.Void UnityEngine.EventSystems.EventSystem::ChangeEventModule(UnityEngine.EventSystems.BaseInputModule)
extern void EventSystem_ChangeEventModule_m4A3010299F57C492A10AABF29568BC2CD6185DE6 (void);
// 0x00000543 System.String UnityEngine.EventSystems.EventSystem::ToString()
extern void EventSystem_ToString_m3BA75E77167F875764A87DE354FA4E7F57452F8E (void);
// 0x00000544 System.Void UnityEngine.EventSystems.EventSystem::.cctor()
extern void EventSystem__cctor_mBE0C93B74BB6A494F3E0A52CF9DFA06795C04649 (void);
// 0x00000545 System.Collections.Generic.List`1<UnityEngine.EventSystems.EventTrigger/Entry> UnityEngine.EventSystems.EventTrigger::get_delegates()
extern void EventTrigger_get_delegates_m481E829B584E900AED42FF84647DB48EECD65AEC (void);
// 0x00000546 System.Void UnityEngine.EventSystems.EventTrigger::set_delegates(System.Collections.Generic.List`1<UnityEngine.EventSystems.EventTrigger/Entry>)
extern void EventTrigger_set_delegates_mC1312F8132D21C5E517EA38677B1C65680F486CD (void);
// 0x00000547 System.Void UnityEngine.EventSystems.EventTrigger::.ctor()
extern void EventTrigger__ctor_m73D31D2C96C8A96300D462E6BD864529E7411F78 (void);
// 0x00000548 System.Collections.Generic.List`1<UnityEngine.EventSystems.EventTrigger/Entry> UnityEngine.EventSystems.EventTrigger::get_triggers()
extern void EventTrigger_get_triggers_mC7BC90E3D01E4107C3BCA70DC6B1E11E5BCDBB40 (void);
// 0x00000549 System.Void UnityEngine.EventSystems.EventTrigger::set_triggers(System.Collections.Generic.List`1<UnityEngine.EventSystems.EventTrigger/Entry>)
extern void EventTrigger_set_triggers_mC0AB6B03331A1D1E51AB9C0457DA7A4C3006DFEA (void);
// 0x0000054A System.Void UnityEngine.EventSystems.EventTrigger::Execute(UnityEngine.EventSystems.EventTriggerType,UnityEngine.EventSystems.BaseEventData)
extern void EventTrigger_Execute_m92E8047B596BC17676C740C5FDB8F737A7FFF0B7 (void);
// 0x0000054B System.Void UnityEngine.EventSystems.EventTrigger::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnPointerEnter_m87C0E1EED47AD32E9431AA5A5FFE5711E005AD02 (void);
// 0x0000054C System.Void UnityEngine.EventSystems.EventTrigger::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnPointerExit_m11160DE36D06FD05397916242A3EA0BE6C13E9AA (void);
// 0x0000054D System.Void UnityEngine.EventSystems.EventTrigger::OnDrag(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnDrag_mA652B1ECA52E24F78C30946EAA553A9F7FE06C84 (void);
// 0x0000054E System.Void UnityEngine.EventSystems.EventTrigger::OnDrop(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnDrop_mD71D70D5754646A0282AE1725139D61D2CEB2219 (void);
// 0x0000054F System.Void UnityEngine.EventSystems.EventTrigger::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnPointerDown_m4860D9041126B46ABE6EADCC1267DA58806056F6 (void);
// 0x00000550 System.Void UnityEngine.EventSystems.EventTrigger::OnPointerUp(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnPointerUp_m23AF1FFE2A5CA913602895E319FF338AEBC4A70B (void);
// 0x00000551 System.Void UnityEngine.EventSystems.EventTrigger::OnPointerClick(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnPointerClick_m5862B8B10A07AAD930F554B1B08F6B0ACBBA552A (void);
// 0x00000552 System.Void UnityEngine.EventSystems.EventTrigger::OnSelect(UnityEngine.EventSystems.BaseEventData)
extern void EventTrigger_OnSelect_m3CF793D81A2A45E3A5324D57FB93F12C4144E344 (void);
// 0x00000553 System.Void UnityEngine.EventSystems.EventTrigger::OnDeselect(UnityEngine.EventSystems.BaseEventData)
extern void EventTrigger_OnDeselect_m14E6CBAE7884FFF19688722EE0762D5C479BA9C7 (void);
// 0x00000554 System.Void UnityEngine.EventSystems.EventTrigger::OnScroll(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnScroll_m049CE9599C751C0C2C571DB33A0449636982029A (void);
// 0x00000555 System.Void UnityEngine.EventSystems.EventTrigger::OnMove(UnityEngine.EventSystems.AxisEventData)
extern void EventTrigger_OnMove_m6B457F494B0EA1B5CE6175610B98984D7A54A26D (void);
// 0x00000556 System.Void UnityEngine.EventSystems.EventTrigger::OnUpdateSelected(UnityEngine.EventSystems.BaseEventData)
extern void EventTrigger_OnUpdateSelected_m6F065ADE4F9F5CE823D8E59C5B1FB98A262351E1 (void);
// 0x00000557 System.Void UnityEngine.EventSystems.EventTrigger::OnInitializePotentialDrag(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnInitializePotentialDrag_m133B4AB3DFC9A5DB7F4DD3754481CCA8D12962F8 (void);
// 0x00000558 System.Void UnityEngine.EventSystems.EventTrigger::OnBeginDrag(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnBeginDrag_m6490661EB3B73834B141F1CE27E11AF2683083BC (void);
// 0x00000559 System.Void UnityEngine.EventSystems.EventTrigger::OnEndDrag(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnEndDrag_m1D5E2CFD8FC9CCBE29EF95B3CE93C306D9BDE960 (void);
// 0x0000055A System.Void UnityEngine.EventSystems.EventTrigger::OnSubmit(UnityEngine.EventSystems.BaseEventData)
extern void EventTrigger_OnSubmit_mAAC2057B87AA87005AE4EAEE24D72AFD12AAB861 (void);
// 0x0000055B System.Void UnityEngine.EventSystems.EventTrigger::OnCancel(UnityEngine.EventSystems.BaseEventData)
extern void EventTrigger_OnCancel_m0F73AD82791AC96D815215FDDE33FFE4D1AC85C0 (void);
// 0x0000055C T UnityEngine.EventSystems.ExecuteEvents::ValidateEventData(UnityEngine.EventSystems.BaseEventData)
// 0x0000055D System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IPointerEnterHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m8C29CBED5B91CAD66E8D07CC11888DFCAFB6A8C1 (void);
// 0x0000055E System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IPointerExitHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_mA09B43D4EA5330792B77CC2B0CFBEA06A57EA489 (void);
// 0x0000055F System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IPointerDownHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_mE604FE0C916D5B3418A30A7B18306DEE7DF10097 (void);
// 0x00000560 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IPointerUpHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_mF019AE64D09B592293ECE5537030CDF5961D7366 (void);
// 0x00000561 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IPointerClickHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m24768528CCF25F4ADB0E66538ABF950C8EE2E9B0 (void);
// 0x00000562 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IInitializePotentialDragHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m7F9A4B2EC9FA8F9F8BBF628E9C8D87587A0BEC98 (void);
// 0x00000563 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IBeginDragHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m31B26038791B68FE23D77DCAC81A550D53575EDA (void);
// 0x00000564 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IDragHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m49C3D013D962BE7E16C2E92608FFCC7C9E5303F0 (void);
// 0x00000565 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IEndDragHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_mE1EDD9426C52F61B04E53838FFFC0C85ADE5832A (void);
// 0x00000566 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IDropHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m6CE9E8ECBC0242714839AD54F32974AF36D273FE (void);
// 0x00000567 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IScrollHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_mF0BD313BC5A34C5BC0DB806AFA3D59F2757ADDF1 (void);
// 0x00000568 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IUpdateSelectedHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m954DCF87A2B6CBF6FEB9B676500EA148F69B20FC (void);
// 0x00000569 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.ISelectHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_mE52644D5E736A355F742C46C1C6C888559EA87D5 (void);
// 0x0000056A System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IDeselectHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m43A103804A0A03E85B931F982D8B86A3B6734BC9 (void);
// 0x0000056B System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IMoveHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_mE1DC393C080EA6FC93D0D3E25217AF69FD29E26E (void);
// 0x0000056C System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.ISubmitHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m22ADACB5A0899E5FEA1846D4084F2C7F78292BC8 (void);
// 0x0000056D System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.ICancelHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_mF6CE7B6F06A92AE4208A2E6E9B842F7A991A79A0 (void);
// 0x0000056E UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IPointerEnterHandler> UnityEngine.EventSystems.ExecuteEvents::get_pointerEnterHandler()
extern void ExecuteEvents_get_pointerEnterHandler_mFD5296E38EB1C5EB6D16CB83913430FEEBF889A5 (void);
// 0x0000056F UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IPointerExitHandler> UnityEngine.EventSystems.ExecuteEvents::get_pointerExitHandler()
extern void ExecuteEvents_get_pointerExitHandler_mE5EC9537676A055EEE178A4E6B58D96F9B4AC301 (void);
// 0x00000570 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IPointerDownHandler> UnityEngine.EventSystems.ExecuteEvents::get_pointerDownHandler()
extern void ExecuteEvents_get_pointerDownHandler_m8AE9CA906C86BBBEB75BA2D05F5DAB01F62519E3 (void);
// 0x00000571 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IPointerUpHandler> UnityEngine.EventSystems.ExecuteEvents::get_pointerUpHandler()
extern void ExecuteEvents_get_pointerUpHandler_m7EDDD1128DC04344CECEBCB9B6B7CD064F7FAED2 (void);
// 0x00000572 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IPointerClickHandler> UnityEngine.EventSystems.ExecuteEvents::get_pointerClickHandler()
extern void ExecuteEvents_get_pointerClickHandler_mA657195AEC7D0A42036CBCAC9AD48F215C3C69E3 (void);
// 0x00000573 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IInitializePotentialDragHandler> UnityEngine.EventSystems.ExecuteEvents::get_initializePotentialDrag()
extern void ExecuteEvents_get_initializePotentialDrag_m5B3D899EB08DA227EFBFC67778DDB98D7505C6D4 (void);
// 0x00000574 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IBeginDragHandler> UnityEngine.EventSystems.ExecuteEvents::get_beginDragHandler()
extern void ExecuteEvents_get_beginDragHandler_m7F238765714F73899EAFDF0BA203D9A8A57AED31 (void);
// 0x00000575 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IDragHandler> UnityEngine.EventSystems.ExecuteEvents::get_dragHandler()
extern void ExecuteEvents_get_dragHandler_m41B7D77771806788CD773C83C2E5A53D5ED5B179 (void);
// 0x00000576 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IEndDragHandler> UnityEngine.EventSystems.ExecuteEvents::get_endDragHandler()
extern void ExecuteEvents_get_endDragHandler_m23B60D3E3873043263069A3C3145393475690769 (void);
// 0x00000577 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IDropHandler> UnityEngine.EventSystems.ExecuteEvents::get_dropHandler()
extern void ExecuteEvents_get_dropHandler_mC2362B96C6CD3628B83722F4B7C73E707C6C1EAF (void);
// 0x00000578 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IScrollHandler> UnityEngine.EventSystems.ExecuteEvents::get_scrollHandler()
extern void ExecuteEvents_get_scrollHandler_m48E5B17388986BD59EC7A7BF27E3D30A9FD057F7 (void);
// 0x00000579 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IUpdateSelectedHandler> UnityEngine.EventSystems.ExecuteEvents::get_updateSelectedHandler()
extern void ExecuteEvents_get_updateSelectedHandler_mE18DBB058B1EDC75D4F690A1E35003749BBC0567 (void);
// 0x0000057A UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.ISelectHandler> UnityEngine.EventSystems.ExecuteEvents::get_selectHandler()
extern void ExecuteEvents_get_selectHandler_m26186C0D78CA4A8AFA0789A09F488F7E186BE1C8 (void);
// 0x0000057B UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IDeselectHandler> UnityEngine.EventSystems.ExecuteEvents::get_deselectHandler()
extern void ExecuteEvents_get_deselectHandler_mEAA9E3701CC972EFDD20B30E9B3CD9302B2FD668 (void);
// 0x0000057C UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IMoveHandler> UnityEngine.EventSystems.ExecuteEvents::get_moveHandler()
extern void ExecuteEvents_get_moveHandler_m113A4222FC10723B2E38398E182C02F6624D6F24 (void);
// 0x0000057D UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.ISubmitHandler> UnityEngine.EventSystems.ExecuteEvents::get_submitHandler()
extern void ExecuteEvents_get_submitHandler_m734C2BE2F7CDA7F5C42897E3C8023D3C7E1EDF88 (void);
// 0x0000057E UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.ICancelHandler> UnityEngine.EventSystems.ExecuteEvents::get_cancelHandler()
extern void ExecuteEvents_get_cancelHandler_m5DB4A9513FB8B9248AE555F7D8E8043175B8D995 (void);
// 0x0000057F System.Void UnityEngine.EventSystems.ExecuteEvents::GetEventChain(UnityEngine.GameObject,System.Collections.Generic.IList`1<UnityEngine.Transform>)
extern void ExecuteEvents_GetEventChain_m27DBBF6D0FE769C131AB96781E9BFFEDA545F155 (void);
// 0x00000580 System.Boolean UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.GameObject,UnityEngine.EventSystems.BaseEventData,UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<T>)
// 0x00000581 UnityEngine.GameObject UnityEngine.EventSystems.ExecuteEvents::ExecuteHierarchy(UnityEngine.GameObject,UnityEngine.EventSystems.BaseEventData,UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<T>)
// 0x00000582 System.Boolean UnityEngine.EventSystems.ExecuteEvents::ShouldSendToComponent(UnityEngine.Component)
// 0x00000583 System.Void UnityEngine.EventSystems.ExecuteEvents::GetEventList(UnityEngine.GameObject,System.Collections.Generic.IList`1<UnityEngine.EventSystems.IEventSystemHandler>)
// 0x00000584 System.Boolean UnityEngine.EventSystems.ExecuteEvents::CanHandleEvent(UnityEngine.GameObject)
// 0x00000585 UnityEngine.GameObject UnityEngine.EventSystems.ExecuteEvents::GetEventHandler(UnityEngine.GameObject)
// 0x00000586 System.Void UnityEngine.EventSystems.ExecuteEvents::.cctor()
extern void ExecuteEvents__cctor_m1F04FDEC642AA1676F07BF0863D7F25530477378 (void);
// 0x00000587 System.String UnityEngine.EventSystems.BaseInput::get_compositionString()
extern void BaseInput_get_compositionString_m9DC95F28875FFB09CD8B1FC080B916BB6F9F976E (void);
// 0x00000588 UnityEngine.IMECompositionMode UnityEngine.EventSystems.BaseInput::get_imeCompositionMode()
extern void BaseInput_get_imeCompositionMode_mC26A90D1DDE30CEE508412D8F1FEA5AD37671DA8 (void);
// 0x00000589 System.Void UnityEngine.EventSystems.BaseInput::set_imeCompositionMode(UnityEngine.IMECompositionMode)
extern void BaseInput_set_imeCompositionMode_m1FD535BFD2D74C77DA7D0D0332114913CBA1C135 (void);
// 0x0000058A UnityEngine.Vector2 UnityEngine.EventSystems.BaseInput::get_compositionCursorPos()
extern void BaseInput_get_compositionCursorPos_m08E6856B2A7240E1FEF880323757BDF8A4917046 (void);
// 0x0000058B System.Void UnityEngine.EventSystems.BaseInput::set_compositionCursorPos(UnityEngine.Vector2)
extern void BaseInput_set_compositionCursorPos_mF2EAEC3ADCB2E035CC6A0ECCA932BBED50B427DD (void);
// 0x0000058C System.Boolean UnityEngine.EventSystems.BaseInput::get_mousePresent()
extern void BaseInput_get_mousePresent_mEE423E6330086DF0B673E700381CD4AA57A8181F (void);
// 0x0000058D System.Boolean UnityEngine.EventSystems.BaseInput::GetMouseButtonDown(System.Int32)
extern void BaseInput_GetMouseButtonDown_m670DD4F91F0C9D697BAA92B89B45D6458D8A86AD (void);
// 0x0000058E System.Boolean UnityEngine.EventSystems.BaseInput::GetMouseButtonUp(System.Int32)
extern void BaseInput_GetMouseButtonUp_mA793A56A84790D6CAF523A0C611A7AF527CBE4B8 (void);
// 0x0000058F System.Boolean UnityEngine.EventSystems.BaseInput::GetMouseButton(System.Int32)
extern void BaseInput_GetMouseButton_m8CBB85496076E5E0A6B47B28C07E096C4BD751DA (void);
// 0x00000590 UnityEngine.Vector2 UnityEngine.EventSystems.BaseInput::get_mousePosition()
extern void BaseInput_get_mousePosition_m020D1FB7D27B45D19303B7B9E05038F2C7DA02ED (void);
// 0x00000591 UnityEngine.Vector2 UnityEngine.EventSystems.BaseInput::get_mouseScrollDelta()
extern void BaseInput_get_mouseScrollDelta_mBF6C6F5DD4C626413DEB5081A34D58C2F178389F (void);
// 0x00000592 System.Boolean UnityEngine.EventSystems.BaseInput::get_touchSupported()
extern void BaseInput_get_touchSupported_mAD828BCFAAC2647C27C21971D0E51A3415CE9F9D (void);
// 0x00000593 System.Int32 UnityEngine.EventSystems.BaseInput::get_touchCount()
extern void BaseInput_get_touchCount_mDF25D855BCD418823ED1E0CA96455EC28A684AB5 (void);
// 0x00000594 UnityEngine.Touch UnityEngine.EventSystems.BaseInput::GetTouch(System.Int32)
extern void BaseInput_GetTouch_mC6D307829A73C58B16FA7D06928BE8D3528796DD (void);
// 0x00000595 System.Single UnityEngine.EventSystems.BaseInput::GetAxisRaw(System.String)
extern void BaseInput_GetAxisRaw_mEC8AE52DA69BAAF0CA88EFBDB93A7B2BEDE607F1 (void);
// 0x00000596 System.Boolean UnityEngine.EventSystems.BaseInput::GetButtonDown(System.String)
extern void BaseInput_GetButtonDown_m41F5626DD501ECFA5348918F63C20A9649E8F862 (void);
// 0x00000597 System.Void UnityEngine.EventSystems.BaseInput::.ctor()
extern void BaseInput__ctor_m097A1D35CC42538881FAF0E45AFF6FB974377F19 (void);
// 0x00000598 UnityEngine.EventSystems.BaseInput UnityEngine.EventSystems.BaseInputModule::get_input()
extern void BaseInputModule_get_input_m385A99609A705346D5288D047EE17374ED406BE7 (void);
// 0x00000599 UnityEngine.EventSystems.BaseInput UnityEngine.EventSystems.BaseInputModule::get_inputOverride()
extern void BaseInputModule_get_inputOverride_m3C63C410A33009ACB7EAFB776066F734110391B8 (void);
// 0x0000059A System.Void UnityEngine.EventSystems.BaseInputModule::set_inputOverride(UnityEngine.EventSystems.BaseInput)
extern void BaseInputModule_set_inputOverride_mC8698C7F93A5E54139938F0D2E6447CEA08779CA (void);
// 0x0000059B UnityEngine.EventSystems.EventSystem UnityEngine.EventSystems.BaseInputModule::get_eventSystem()
extern void BaseInputModule_get_eventSystem_mEF6DEC17FF56D786AA217A52FCCFE8C6F38546BE (void);
// 0x0000059C System.Void UnityEngine.EventSystems.BaseInputModule::OnEnable()
extern void BaseInputModule_OnEnable_mFCB40D263C78C819D0F1A17B5679662DD31245A4 (void);
// 0x0000059D System.Void UnityEngine.EventSystems.BaseInputModule::OnDisable()
extern void BaseInputModule_OnDisable_m4E5FE43DDC5E6471DAAD8435D20E9F684E5FE6CE (void);
// 0x0000059E System.Void UnityEngine.EventSystems.BaseInputModule::Process()
// 0x0000059F UnityEngine.EventSystems.RaycastResult UnityEngine.EventSystems.BaseInputModule::FindFirstRaycast(System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void BaseInputModule_FindFirstRaycast_m8688F6932686AD7A5910C912787ED4239A70CD57 (void);
// 0x000005A0 UnityEngine.EventSystems.MoveDirection UnityEngine.EventSystems.BaseInputModule::DetermineMoveDirection(System.Single,System.Single)
extern void BaseInputModule_DetermineMoveDirection_mFF256A4F65F2B3E650E232F70C1B05F46DF181F2 (void);
// 0x000005A1 UnityEngine.EventSystems.MoveDirection UnityEngine.EventSystems.BaseInputModule::DetermineMoveDirection(System.Single,System.Single,System.Single)
extern void BaseInputModule_DetermineMoveDirection_mD3EE701CE69F63DEBBF2B9D3FB62F550A4DAD8D8 (void);
// 0x000005A2 UnityEngine.GameObject UnityEngine.EventSystems.BaseInputModule::FindCommonRoot(UnityEngine.GameObject,UnityEngine.GameObject)
extern void BaseInputModule_FindCommonRoot_m1995190ADC1341F180811C5213F1CA522B6282A5 (void);
// 0x000005A3 System.Void UnityEngine.EventSystems.BaseInputModule::HandlePointerExitAndEnter(UnityEngine.EventSystems.PointerEventData,UnityEngine.GameObject)
extern void BaseInputModule_HandlePointerExitAndEnter_mFA61D8BA9B2377B56E3844CE8E3C15DF4C1959CB (void);
// 0x000005A4 UnityEngine.EventSystems.AxisEventData UnityEngine.EventSystems.BaseInputModule::GetAxisEventData(System.Single,System.Single,System.Single)
extern void BaseInputModule_GetAxisEventData_m2D7FF7016AC9AA5042343C19FF2CE5A33CF351F9 (void);
// 0x000005A5 UnityEngine.EventSystems.BaseEventData UnityEngine.EventSystems.BaseInputModule::GetBaseEventData()
extern void BaseInputModule_GetBaseEventData_mB945B5DF7A5C2B825C7D542D944A7795D8F5F93F (void);
// 0x000005A6 System.Boolean UnityEngine.EventSystems.BaseInputModule::IsPointerOverGameObject(System.Int32)
extern void BaseInputModule_IsPointerOverGameObject_mEEDB14B0E8930015C4DC60A4AA362F71C07F95AF (void);
// 0x000005A7 System.Boolean UnityEngine.EventSystems.BaseInputModule::ShouldActivateModule()
extern void BaseInputModule_ShouldActivateModule_m8EB1E427EFD3E7AC2341EE52DE4E51FD8D6EF548 (void);
// 0x000005A8 System.Void UnityEngine.EventSystems.BaseInputModule::DeactivateModule()
extern void BaseInputModule_DeactivateModule_m83781CF60B00AD9DA46E96D72321C4983EFA85FF (void);
// 0x000005A9 System.Void UnityEngine.EventSystems.BaseInputModule::ActivateModule()
extern void BaseInputModule_ActivateModule_m83647D8599561B6CA562F24EA7088E37DAC2AD29 (void);
// 0x000005AA System.Void UnityEngine.EventSystems.BaseInputModule::UpdateModule()
extern void BaseInputModule_UpdateModule_mD72D1FB1F26A50F07144B74397831EB6691F3F65 (void);
// 0x000005AB System.Boolean UnityEngine.EventSystems.BaseInputModule::IsModuleSupported()
extern void BaseInputModule_IsModuleSupported_m219E09AAE063439B142750898517669B36510EF0 (void);
// 0x000005AC System.Void UnityEngine.EventSystems.BaseInputModule::.ctor()
extern void BaseInputModule__ctor_m8F78B6153670F05181D1B348C4259C45DCF4C231 (void);
// 0x000005AD System.Boolean UnityEngine.EventSystems.PointerInputModule::GetPointerData(System.Int32,UnityEngine.EventSystems.PointerEventData&,System.Boolean)
extern void PointerInputModule_GetPointerData_mF40B733CA91DCC168F7417BD9C264D21F82C2E94 (void);
// 0x000005AE System.Void UnityEngine.EventSystems.PointerInputModule::RemovePointerData(UnityEngine.EventSystems.PointerEventData)
extern void PointerInputModule_RemovePointerData_m17E63DD11FE440D4D88078B4895137C942C52C3A (void);
// 0x000005AF UnityEngine.EventSystems.PointerEventData UnityEngine.EventSystems.PointerInputModule::GetTouchPointerEventData(UnityEngine.Touch,System.Boolean&,System.Boolean&)
extern void PointerInputModule_GetTouchPointerEventData_m27D309E699986AE28F15FF944CCADC4EA2E9BC11 (void);
// 0x000005B0 System.Void UnityEngine.EventSystems.PointerInputModule::CopyFromTo(UnityEngine.EventSystems.PointerEventData,UnityEngine.EventSystems.PointerEventData)
extern void PointerInputModule_CopyFromTo_m33310425F20BE45DA17DA8E1E07FFE461F410F82 (void);
// 0x000005B1 UnityEngine.EventSystems.PointerEventData/FramePressState UnityEngine.EventSystems.PointerInputModule::StateForMouseButton(System.Int32)
extern void PointerInputModule_StateForMouseButton_m0B66950A94543E8F6D16AC6546E7009AEE0B8E2C (void);
// 0x000005B2 UnityEngine.EventSystems.PointerInputModule/MouseState UnityEngine.EventSystems.PointerInputModule::GetMousePointerEventData()
extern void PointerInputModule_GetMousePointerEventData_mA8B6C810AE130118AA18CD4BD35F8F5BCE0D7E07 (void);
// 0x000005B3 UnityEngine.EventSystems.PointerInputModule/MouseState UnityEngine.EventSystems.PointerInputModule::GetMousePointerEventData(System.Int32)
extern void PointerInputModule_GetMousePointerEventData_mA6DE4DDE2C99B16D77DB3DD2F541C1DC23A18EB4 (void);
// 0x000005B4 UnityEngine.EventSystems.PointerEventData UnityEngine.EventSystems.PointerInputModule::GetLastPointerEventData(System.Int32)
extern void PointerInputModule_GetLastPointerEventData_mEC097EFC007EA8900D2346665F277C1E4A8D94BD (void);
// 0x000005B5 System.Boolean UnityEngine.EventSystems.PointerInputModule::ShouldStartDrag(UnityEngine.Vector2,UnityEngine.Vector2,System.Single,System.Boolean)
extern void PointerInputModule_ShouldStartDrag_mA947D41C459516DE49CD25B0E856832956AEF02F (void);
// 0x000005B6 System.Void UnityEngine.EventSystems.PointerInputModule::ProcessMove(UnityEngine.EventSystems.PointerEventData)
extern void PointerInputModule_ProcessMove_mE19CAFF568799ED491CE71939D6EFD2535ACB0A5 (void);
// 0x000005B7 System.Void UnityEngine.EventSystems.PointerInputModule::ProcessDrag(UnityEngine.EventSystems.PointerEventData)
extern void PointerInputModule_ProcessDrag_m2A544286EF20A04D6E42FFCFD0F73DD89F9614A2 (void);
// 0x000005B8 System.Boolean UnityEngine.EventSystems.PointerInputModule::IsPointerOverGameObject(System.Int32)
extern void PointerInputModule_IsPointerOverGameObject_m559779A0E006BBB28F99A6AB59011FA397320B46 (void);
// 0x000005B9 System.Void UnityEngine.EventSystems.PointerInputModule::ClearSelection()
extern void PointerInputModule_ClearSelection_m90CD812546D41142C4E9C599D7DD39A887F3F5C1 (void);
// 0x000005BA System.String UnityEngine.EventSystems.PointerInputModule::ToString()
extern void PointerInputModule_ToString_mF269BDD6927D4E4F92586120C558234BACE12BF8 (void);
// 0x000005BB System.Void UnityEngine.EventSystems.PointerInputModule::DeselectIfSelectionChanged(UnityEngine.GameObject,UnityEngine.EventSystems.BaseEventData)
extern void PointerInputModule_DeselectIfSelectionChanged_mD24AB70C8C12903D513ABB8BAE132E707B0F0A70 (void);
// 0x000005BC System.Void UnityEngine.EventSystems.PointerInputModule::.ctor()
extern void PointerInputModule__ctor_m05A4A9E4BF8053B1444986BF3EB27D8007AE9275 (void);
// 0x000005BD System.Void UnityEngine.EventSystems.StandaloneInputModule::.ctor()
extern void StandaloneInputModule__ctor_m53DF966585A2888088BF07BB7DDE26BA84BA67D0 (void);
// 0x000005BE UnityEngine.EventSystems.StandaloneInputModule/InputMode UnityEngine.EventSystems.StandaloneInputModule::get_inputMode()
extern void StandaloneInputModule_get_inputMode_m9E4FF00674C049A7F600D0CC5D278F474232B3D4 (void);
// 0x000005BF System.Boolean UnityEngine.EventSystems.StandaloneInputModule::get_allowActivationOnMobileDevice()
extern void StandaloneInputModule_get_allowActivationOnMobileDevice_m761DA40A5C7688BB6F8EABD989D74B2239B8776E (void);
// 0x000005C0 System.Void UnityEngine.EventSystems.StandaloneInputModule::set_allowActivationOnMobileDevice(System.Boolean)
extern void StandaloneInputModule_set_allowActivationOnMobileDevice_m7E48DC59AE7F10E8ACCBC9A86E66E245B513413A (void);
// 0x000005C1 System.Boolean UnityEngine.EventSystems.StandaloneInputModule::get_forceModuleActive()
extern void StandaloneInputModule_get_forceModuleActive_m7C481C9C4D478CB162E289F9D038859990973E6E (void);
// 0x000005C2 System.Void UnityEngine.EventSystems.StandaloneInputModule::set_forceModuleActive(System.Boolean)
extern void StandaloneInputModule_set_forceModuleActive_m41B816036BFFF624B371224005BA4D303B21F731 (void);
// 0x000005C3 System.Single UnityEngine.EventSystems.StandaloneInputModule::get_inputActionsPerSecond()
extern void StandaloneInputModule_get_inputActionsPerSecond_mE25D1FE801046F322B862161B338A9719A4B87DD (void);
// 0x000005C4 System.Void UnityEngine.EventSystems.StandaloneInputModule::set_inputActionsPerSecond(System.Single)
extern void StandaloneInputModule_set_inputActionsPerSecond_mD97110B0C4B4F72D6E2826BDDE28EDBB04323953 (void);
// 0x000005C5 System.Single UnityEngine.EventSystems.StandaloneInputModule::get_repeatDelay()
extern void StandaloneInputModule_get_repeatDelay_m95DD446349C273DFC8E3ECB25DC83248E6955597 (void);
// 0x000005C6 System.Void UnityEngine.EventSystems.StandaloneInputModule::set_repeatDelay(System.Single)
extern void StandaloneInputModule_set_repeatDelay_mA45CBEB7D208DCD103CD7817F5B4691647F53B90 (void);
// 0x000005C7 System.String UnityEngine.EventSystems.StandaloneInputModule::get_horizontalAxis()
extern void StandaloneInputModule_get_horizontalAxis_m7830DCFA78BDB86C6EB403D9B0A3AC6C2AEA202E (void);
// 0x000005C8 System.Void UnityEngine.EventSystems.StandaloneInputModule::set_horizontalAxis(System.String)
extern void StandaloneInputModule_set_horizontalAxis_m261CC906B1304D6D9B0086AE1C552834AB6F1D59 (void);
// 0x000005C9 System.String UnityEngine.EventSystems.StandaloneInputModule::get_verticalAxis()
extern void StandaloneInputModule_get_verticalAxis_m1493EE2972D3244EEA8D94E0D145E8E43C6BDF0D (void);
// 0x000005CA System.Void UnityEngine.EventSystems.StandaloneInputModule::set_verticalAxis(System.String)
extern void StandaloneInputModule_set_verticalAxis_m1E55CD609287D3DDA0289584C0FBDF9BAB891ABC (void);
// 0x000005CB System.String UnityEngine.EventSystems.StandaloneInputModule::get_submitButton()
extern void StandaloneInputModule_get_submitButton_mA466BE2B75CE6A39828DC3AB2E698F4BEE9EEDDF (void);
// 0x000005CC System.Void UnityEngine.EventSystems.StandaloneInputModule::set_submitButton(System.String)
extern void StandaloneInputModule_set_submitButton_mFB2699D16EE8E72E814B1807F70FAF6FCBCD2B6D (void);
// 0x000005CD System.String UnityEngine.EventSystems.StandaloneInputModule::get_cancelButton()
extern void StandaloneInputModule_get_cancelButton_m3FB17204BE25A393F920457C482A927AC216F1FE (void);
// 0x000005CE System.Void UnityEngine.EventSystems.StandaloneInputModule::set_cancelButton(System.String)
extern void StandaloneInputModule_set_cancelButton_m724FDEA363F0FFF56FBFD84AD8C1F4C57B67D2B9 (void);
// 0x000005CF System.Boolean UnityEngine.EventSystems.StandaloneInputModule::ShouldIgnoreEventsOnNoFocus()
extern void StandaloneInputModule_ShouldIgnoreEventsOnNoFocus_mEE9196582563D3B4F864A3FDDC41B3AF058DE1E8 (void);
// 0x000005D0 System.Void UnityEngine.EventSystems.StandaloneInputModule::UpdateModule()
extern void StandaloneInputModule_UpdateModule_m6BE8C301BEB10BD653F0D0EEB6522E3A8F3221BA (void);
// 0x000005D1 System.Void UnityEngine.EventSystems.StandaloneInputModule::ReleaseMouse(UnityEngine.EventSystems.PointerEventData,UnityEngine.GameObject)
extern void StandaloneInputModule_ReleaseMouse_mAB37571EEE6FE65733244890BE88FFF095DF8FED (void);
// 0x000005D2 System.Boolean UnityEngine.EventSystems.StandaloneInputModule::IsModuleSupported()
extern void StandaloneInputModule_IsModuleSupported_m44C18E994D6B97CDFBD841A9D7314B26B7AA340A (void);
// 0x000005D3 System.Boolean UnityEngine.EventSystems.StandaloneInputModule::ShouldActivateModule()
extern void StandaloneInputModule_ShouldActivateModule_mEA1D4CC786377AD4A1A9EC035BCABA9AC32B48C5 (void);
// 0x000005D4 System.Void UnityEngine.EventSystems.StandaloneInputModule::ActivateModule()
extern void StandaloneInputModule_ActivateModule_m75B8C7CF41074D98F23DBCBADBEC12204F101F04 (void);
// 0x000005D5 System.Void UnityEngine.EventSystems.StandaloneInputModule::DeactivateModule()
extern void StandaloneInputModule_DeactivateModule_m184C95BAB03E1AC58F7274A6CDDCDC70160301C3 (void);
// 0x000005D6 System.Void UnityEngine.EventSystems.StandaloneInputModule::Process()
extern void StandaloneInputModule_Process_mF637455BCED017FB359E090B58F15C490EFD2B54 (void);
// 0x000005D7 System.Boolean UnityEngine.EventSystems.StandaloneInputModule::ProcessTouchEvents()
extern void StandaloneInputModule_ProcessTouchEvents_m74C783AF0B4D517978ECCE3E8A1081F49D174F69 (void);
// 0x000005D8 System.Void UnityEngine.EventSystems.StandaloneInputModule::ProcessTouchPress(UnityEngine.EventSystems.PointerEventData,System.Boolean,System.Boolean)
extern void StandaloneInputModule_ProcessTouchPress_m46FBF040EAB0A0F8D832FEB600EF0B9C48E13F61 (void);
// 0x000005D9 System.Boolean UnityEngine.EventSystems.StandaloneInputModule::SendSubmitEventToSelectedObject()
extern void StandaloneInputModule_SendSubmitEventToSelectedObject_m29ACA510C925399B9D806ED171DA86E4F3A671E4 (void);
// 0x000005DA UnityEngine.Vector2 UnityEngine.EventSystems.StandaloneInputModule::GetRawMoveVector()
extern void StandaloneInputModule_GetRawMoveVector_m36E309DADA8C0BB4CA0710FAABE0F4E9B77C2F6A (void);
// 0x000005DB System.Boolean UnityEngine.EventSystems.StandaloneInputModule::SendMoveEventToSelectedObject()
extern void StandaloneInputModule_SendMoveEventToSelectedObject_mBD62EF30732300D347DA3D78B7473D6DCF15BC41 (void);
// 0x000005DC System.Void UnityEngine.EventSystems.StandaloneInputModule::ProcessMouseEvent()
extern void StandaloneInputModule_ProcessMouseEvent_m4CF90D3BE8DC50D135D42B31C70D3D2D30B47174 (void);
// 0x000005DD System.Boolean UnityEngine.EventSystems.StandaloneInputModule::ForceAutoSelect()
extern void StandaloneInputModule_ForceAutoSelect_mD5FAA93BE3D2052F0138940C25148BF184DB0952 (void);
// 0x000005DE System.Void UnityEngine.EventSystems.StandaloneInputModule::ProcessMouseEvent(System.Int32)
extern void StandaloneInputModule_ProcessMouseEvent_mBC7F5E60430C4594852FB785035D8FE5EAD9FF99 (void);
// 0x000005DF System.Boolean UnityEngine.EventSystems.StandaloneInputModule::SendUpdateEventToSelectedObject()
extern void StandaloneInputModule_SendUpdateEventToSelectedObject_m7180367BFB750772FECFBC7C621234B7FBF29C9D (void);
// 0x000005E0 System.Void UnityEngine.EventSystems.StandaloneInputModule::ProcessMousePress(UnityEngine.EventSystems.PointerInputModule/MouseButtonEventData)
extern void StandaloneInputModule_ProcessMousePress_mEB96E70EDB025F2AA37FEF2063CE248AC735C16F (void);
// 0x000005E1 UnityEngine.GameObject UnityEngine.EventSystems.StandaloneInputModule::GetCurrentFocusedGameObject()
extern void StandaloneInputModule_GetCurrentFocusedGameObject_mA354FCB4E2546E1F49D165207705A26D29EBB3D7 (void);
// 0x000005E2 System.Void UnityEngine.EventSystems.TouchInputModule::.ctor()
extern void TouchInputModule__ctor_m4DA98CF8160474EEF5179225D9435497BE81D570 (void);
// 0x000005E3 System.Boolean UnityEngine.EventSystems.TouchInputModule::get_allowActivationOnStandalone()
extern void TouchInputModule_get_allowActivationOnStandalone_m5AF75CB4497AD94C5EDC08571D5B26AAA4FDEC21 (void);
// 0x000005E4 System.Void UnityEngine.EventSystems.TouchInputModule::set_allowActivationOnStandalone(System.Boolean)
extern void TouchInputModule_set_allowActivationOnStandalone_m03444533ACC4BC73EBDD50489D1ECB99C0C780D0 (void);
// 0x000005E5 System.Boolean UnityEngine.EventSystems.TouchInputModule::get_forceModuleActive()
extern void TouchInputModule_get_forceModuleActive_m3DBB16E0B71B7567515CBE0089A91EF4A0B344C3 (void);
// 0x000005E6 System.Void UnityEngine.EventSystems.TouchInputModule::set_forceModuleActive(System.Boolean)
extern void TouchInputModule_set_forceModuleActive_m28F890F6675872621907FE867414D4DBDBDD9EB8 (void);
// 0x000005E7 System.Void UnityEngine.EventSystems.TouchInputModule::UpdateModule()
extern void TouchInputModule_UpdateModule_mCA26D9F764562DCBA511D947B1892AD93F5AF863 (void);
// 0x000005E8 System.Boolean UnityEngine.EventSystems.TouchInputModule::IsModuleSupported()
extern void TouchInputModule_IsModuleSupported_mE4B9FD3BA7947F9B783B8BC44CFE8537F8D25155 (void);
// 0x000005E9 System.Boolean UnityEngine.EventSystems.TouchInputModule::ShouldActivateModule()
extern void TouchInputModule_ShouldActivateModule_mA6B7B00937F0100D53F9F2D8C71CE288E292E071 (void);
// 0x000005EA System.Boolean UnityEngine.EventSystems.TouchInputModule::UseFakeInput()
extern void TouchInputModule_UseFakeInput_m2406557FC685547C9245C1052A1DF2B7D8AE0919 (void);
// 0x000005EB System.Void UnityEngine.EventSystems.TouchInputModule::Process()
extern void TouchInputModule_Process_m69909AB21CAA13E21A6C3E8723D168C55AB57C7D (void);
// 0x000005EC System.Void UnityEngine.EventSystems.TouchInputModule::FakeTouches()
extern void TouchInputModule_FakeTouches_m660D98593231941BBFB9C9A6D52F3F68C20A1731 (void);
// 0x000005ED System.Void UnityEngine.EventSystems.TouchInputModule::ProcessTouchEvents()
extern void TouchInputModule_ProcessTouchEvents_m2A417627C700B7BAE40700BEBC9A55D325A07A50 (void);
// 0x000005EE System.Void UnityEngine.EventSystems.TouchInputModule::ProcessTouchPress(UnityEngine.EventSystems.PointerEventData,System.Boolean,System.Boolean)
extern void TouchInputModule_ProcessTouchPress_m82D82ECA10567F5BC60F004814EECC7A09914FD6 (void);
// 0x000005EF System.Void UnityEngine.EventSystems.TouchInputModule::DeactivateModule()
extern void TouchInputModule_DeactivateModule_m0B4D1B126C28668E2F6AAC08544CBAB93C086734 (void);
// 0x000005F0 System.String UnityEngine.EventSystems.TouchInputModule::ToString()
extern void TouchInputModule_ToString_m33D845D0F7EB0AC832050B3B582010E7173741CC (void);
// 0x000005F1 UnityEngine.GameObject UnityEngine.EventSystems.RaycastResult::get_gameObject()
extern void RaycastResult_get_gameObject_m9D77DEDFF498BAFE29A5F88E9F238400D04C8FDD (void);
// 0x000005F2 System.Void UnityEngine.EventSystems.RaycastResult::set_gameObject(UnityEngine.GameObject)
extern void RaycastResult_set_gameObject_m4EB676328BEC6E2C3A2AFBA4B405CEDDEAEBBFFA (void);
// 0x000005F3 System.Boolean UnityEngine.EventSystems.RaycastResult::get_isValid()
extern void RaycastResult_get_isValid_m2F2241EF619EFFC0F609FAA35D4C64455712DE47 (void);
// 0x000005F4 System.Void UnityEngine.EventSystems.RaycastResult::Clear()
extern void RaycastResult_Clear_mDC3D08DD775DA02145E5AF6FE62465EBACEB4AAB (void);
// 0x000005F5 System.String UnityEngine.EventSystems.RaycastResult::ToString()
extern void RaycastResult_ToString_m0EE4380602D2025F27DB18ABE887E9CC7C39BB5B (void);
// 0x000005F6 System.Void UnityEngine.EventSystems.RaycasterManager::AddRaycaster(UnityEngine.EventSystems.BaseRaycaster)
extern void RaycasterManager_AddRaycaster_mE3A5D2AA12657F81E20AF477E084ED4C11E62A0F (void);
// 0x000005F7 System.Collections.Generic.List`1<UnityEngine.EventSystems.BaseRaycaster> UnityEngine.EventSystems.RaycasterManager::GetRaycasters()
extern void RaycasterManager_GetRaycasters_m3088F1DFEEDD695546B8CC290E34FD6093CD264D (void);
// 0x000005F8 System.Void UnityEngine.EventSystems.RaycasterManager::RemoveRaycasters(UnityEngine.EventSystems.BaseRaycaster)
extern void RaycasterManager_RemoveRaycasters_mF59A19B82C1D199DB38350293C5CAD6F92EBA1EE (void);
// 0x000005F9 System.Void UnityEngine.EventSystems.RaycasterManager::.cctor()
extern void RaycasterManager__cctor_mA898971B12280C6EA2064755CB72B2B714E63918 (void);
// 0x000005FA System.Void UnityEngine.EventSystems.BaseRaycaster::Raycast(UnityEngine.EventSystems.PointerEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
// 0x000005FB UnityEngine.Camera UnityEngine.EventSystems.BaseRaycaster::get_eventCamera()
// 0x000005FC System.Int32 UnityEngine.EventSystems.BaseRaycaster::get_priority()
extern void BaseRaycaster_get_priority_m711033A670FA9C2DD43A249A66FA6AEFEC9873F0 (void);
// 0x000005FD System.Int32 UnityEngine.EventSystems.BaseRaycaster::get_sortOrderPriority()
extern void BaseRaycaster_get_sortOrderPriority_m771068D9ED43707FEAFC054488B3F661DF97222C (void);
// 0x000005FE System.Int32 UnityEngine.EventSystems.BaseRaycaster::get_renderOrderPriority()
extern void BaseRaycaster_get_renderOrderPriority_m3627528E3042A9101E5820E892C8D7F30084E1E6 (void);
// 0x000005FF UnityEngine.EventSystems.BaseRaycaster UnityEngine.EventSystems.BaseRaycaster::get_rootRaycaster()
extern void BaseRaycaster_get_rootRaycaster_m4DF6B023C195A4E8E9AF8D8E411379A9052D80A5 (void);
// 0x00000600 System.String UnityEngine.EventSystems.BaseRaycaster::ToString()
extern void BaseRaycaster_ToString_m96F781EB5818707A7904AC3F061E5AAFE37F7DB5 (void);
// 0x00000601 System.Void UnityEngine.EventSystems.BaseRaycaster::OnEnable()
extern void BaseRaycaster_OnEnable_mE000A849F5B40F1059DBFDA84C7743E9467B0ADA (void);
// 0x00000602 System.Void UnityEngine.EventSystems.BaseRaycaster::OnDisable()
extern void BaseRaycaster_OnDisable_m83ED4E74E23400DCEE2DCEDBF85B96720725F5D7 (void);
// 0x00000603 System.Void UnityEngine.EventSystems.BaseRaycaster::OnCanvasHierarchyChanged()
extern void BaseRaycaster_OnCanvasHierarchyChanged_m1962CEE13C1E14C31A01B0A88157245364D322F8 (void);
// 0x00000604 System.Void UnityEngine.EventSystems.BaseRaycaster::OnTransformParentChanged()
extern void BaseRaycaster_OnTransformParentChanged_mC50B4405C2923E2B16247C1C85F5200CA3117539 (void);
// 0x00000605 System.Void UnityEngine.EventSystems.BaseRaycaster::.ctor()
extern void BaseRaycaster__ctor_mBD29DEB1B35BFC380759759DB78A5C9B8F695048 (void);
// 0x00000606 System.Void UnityEngine.EventSystems.Physics2DRaycaster::.ctor()
extern void Physics2DRaycaster__ctor_mDD17B4E09EB91C114786BBAEC903BA49871C4EA3 (void);
// 0x00000607 System.Void UnityEngine.EventSystems.Physics2DRaycaster::Raycast(UnityEngine.EventSystems.PointerEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void Physics2DRaycaster_Raycast_m8EE96E1D1C1C118DA04FF279BC0555ED7BE29D41 (void);
// 0x00000608 System.Void UnityEngine.EventSystems.PhysicsRaycaster::.ctor()
extern void PhysicsRaycaster__ctor_mE6B5EB334DE25F1DE5725599B3A990C8D5A54F70 (void);
// 0x00000609 UnityEngine.Camera UnityEngine.EventSystems.PhysicsRaycaster::get_eventCamera()
extern void PhysicsRaycaster_get_eventCamera_mA4D0809E09657E6B635FF54EA8178CA5280C297E (void);
// 0x0000060A System.Int32 UnityEngine.EventSystems.PhysicsRaycaster::get_depth()
extern void PhysicsRaycaster_get_depth_mE0E914B9A592003FF8CCCC84D285AD44BA93545B (void);
// 0x0000060B System.Int32 UnityEngine.EventSystems.PhysicsRaycaster::get_finalEventMask()
extern void PhysicsRaycaster_get_finalEventMask_m635B6C7C9CFA5B94FF623AC31044C57DDE0E6C2F (void);
// 0x0000060C UnityEngine.LayerMask UnityEngine.EventSystems.PhysicsRaycaster::get_eventMask()
extern void PhysicsRaycaster_get_eventMask_m11D96704635B15FCD194B02B421807362676BE98 (void);
// 0x0000060D System.Void UnityEngine.EventSystems.PhysicsRaycaster::set_eventMask(UnityEngine.LayerMask)
extern void PhysicsRaycaster_set_eventMask_mE4ADA4A1183945002A910222C1FA03314238ABD6 (void);
// 0x0000060E System.Int32 UnityEngine.EventSystems.PhysicsRaycaster::get_maxRayIntersections()
extern void PhysicsRaycaster_get_maxRayIntersections_m731D62B45F87B97DCBBE0DA728B8653E64995ABF (void);
// 0x0000060F System.Void UnityEngine.EventSystems.PhysicsRaycaster::set_maxRayIntersections(System.Int32)
extern void PhysicsRaycaster_set_maxRayIntersections_mA3D5632E679F880AEA21E74148FB9E315FB69D3A (void);
// 0x00000610 System.Boolean UnityEngine.EventSystems.PhysicsRaycaster::ComputeRayAndDistance(UnityEngine.EventSystems.PointerEventData,UnityEngine.Ray&,System.Int32&,System.Single&)
extern void PhysicsRaycaster_ComputeRayAndDistance_m3304D9B85EDCE08A7BC0F3EF435A5A36B2AE3026 (void);
// 0x00000611 System.Void UnityEngine.EventSystems.PhysicsRaycaster::Raycast(UnityEngine.EventSystems.PointerEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void PhysicsRaycaster_Raycast_mD390972E28043DD58583BC8B25ADC7C1BAD71CCC (void);
// 0x00000612 System.Void UnityEngine.EventSystems.UIBehaviour::Awake()
extern void UIBehaviour_Awake_m5DD9E48E9933AA28DAE1978B5FCC6B90BAF06FDC (void);
// 0x00000613 System.Void UnityEngine.EventSystems.UIBehaviour::OnEnable()
extern void UIBehaviour_OnEnable_mC9822F55BFE331807411109DA82D6AE5EF46E2C2 (void);
// 0x00000614 System.Void UnityEngine.EventSystems.UIBehaviour::Start()
extern void UIBehaviour_Start_mCF174BFBADA4B5806DD4FFF75984F1526AAF3884 (void);
// 0x00000615 System.Void UnityEngine.EventSystems.UIBehaviour::OnDisable()
extern void UIBehaviour_OnDisable_mDA7B89CA939C50BD6F81CC350C2969755B1576A0 (void);
// 0x00000616 System.Void UnityEngine.EventSystems.UIBehaviour::OnDestroy()
extern void UIBehaviour_OnDestroy_mAC124B1C2131BDD6B17D70DB2A90632A2355F498 (void);
// 0x00000617 System.Boolean UnityEngine.EventSystems.UIBehaviour::IsActive()
extern void UIBehaviour_IsActive_m9B5E4BBBFB0037F29906ADEEA6F9FD42BEC6B64C (void);
// 0x00000618 System.Void UnityEngine.EventSystems.UIBehaviour::OnRectTransformDimensionsChange()
extern void UIBehaviour_OnRectTransformDimensionsChange_m502F3C94E797FCA4C837036E3931118E5F713483 (void);
// 0x00000619 System.Void UnityEngine.EventSystems.UIBehaviour::OnBeforeTransformParentChanged()
extern void UIBehaviour_OnBeforeTransformParentChanged_m68E4722715DFFFBCF5E60258B0F72B29AF37F957 (void);
// 0x0000061A System.Void UnityEngine.EventSystems.UIBehaviour::OnTransformParentChanged()
extern void UIBehaviour_OnTransformParentChanged_m94918707543A748636155588EAE7D50A471D9EDE (void);
// 0x0000061B System.Void UnityEngine.EventSystems.UIBehaviour::OnDidApplyAnimationProperties()
extern void UIBehaviour_OnDidApplyAnimationProperties_m843205FEEE8B64554A393E916AC9D5CC2CFFE8CB (void);
// 0x0000061C System.Void UnityEngine.EventSystems.UIBehaviour::OnCanvasGroupChanged()
extern void UIBehaviour_OnCanvasGroupChanged_m199FB773259086C18FA2481F4EE7BDB7C3A14023 (void);
// 0x0000061D System.Void UnityEngine.EventSystems.UIBehaviour::OnCanvasHierarchyChanged()
extern void UIBehaviour_OnCanvasHierarchyChanged_m63F9F4A5B982D0417EEDCB780B12EC0946A68FB5 (void);
// 0x0000061E System.Boolean UnityEngine.EventSystems.UIBehaviour::IsDestroyed()
extern void UIBehaviour_IsDestroyed_mFBB1C4329F14CC34D7B0351E21D8419FFB4BA01B (void);
// 0x0000061F System.Void UnityEngine.EventSystems.UIBehaviour::.ctor()
extern void UIBehaviour__ctor_m270FFBC65602196134042BD4E24DB093883A1BAF (void);
// 0x00000620 System.Void UnityEngine.UI.Button/ButtonClickedEvent::.ctor()
extern void ButtonClickedEvent__ctor_m95CE43990A021F7E01F4697B71ABF3E73D6BD03B (void);
// 0x00000621 System.Void UnityEngine.UI.Button/<OnFinishSubmit>d__9::.ctor(System.Int32)
extern void U3COnFinishSubmitU3Ed__9__ctor_mBCBD6B7B3BDB9E9146CD76D7D64E3F2900E04247 (void);
// 0x00000622 System.Void UnityEngine.UI.Button/<OnFinishSubmit>d__9::System.IDisposable.Dispose()
extern void U3COnFinishSubmitU3Ed__9_System_IDisposable_Dispose_mA0AACD4958863BC4C20A97FB14B641922EDBE52F (void);
// 0x00000623 System.Boolean UnityEngine.UI.Button/<OnFinishSubmit>d__9::MoveNext()
extern void U3COnFinishSubmitU3Ed__9_MoveNext_m12F9C4E3C7FBDEB24B399B7E6935BC5E18856ED8 (void);
// 0x00000624 System.Object UnityEngine.UI.Button/<OnFinishSubmit>d__9::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3COnFinishSubmitU3Ed__9_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m8FC4B943F2051EFD53EADACDAD40C776ED503DE3 (void);
// 0x00000625 System.Void UnityEngine.UI.Button/<OnFinishSubmit>d__9::System.Collections.IEnumerator.Reset()
extern void U3COnFinishSubmitU3Ed__9_System_Collections_IEnumerator_Reset_m9A8F55E44A8F5C19F6F4C1B7648F139895665425 (void);
// 0x00000626 System.Object UnityEngine.UI.Button/<OnFinishSubmit>d__9::System.Collections.IEnumerator.get_Current()
extern void U3COnFinishSubmitU3Ed__9_System_Collections_IEnumerator_get_Current_m018D3968294D5F3F16924C7F53120C49474A9B97 (void);
// 0x00000627 UnityEngine.GameObject UnityEngine.UI.DefaultControls/IFactoryControls::CreateGameObject(System.String,System.Type[])
// 0x00000628 UnityEngine.GameObject UnityEngine.UI.DefaultControls/DefaultRuntimeFactory::CreateGameObject(System.String,System.Type[])
extern void DefaultRuntimeFactory_CreateGameObject_mEF7A906B56039410AAAE4F069426883DC028B7EB (void);
// 0x00000629 System.Void UnityEngine.UI.DefaultControls/DefaultRuntimeFactory::.ctor()
extern void DefaultRuntimeFactory__ctor_mA26CD855B0C0BDDA991CB78A064EA63A736B01F0 (void);
// 0x0000062A System.Void UnityEngine.UI.DefaultControls/DefaultRuntimeFactory::.cctor()
extern void DefaultRuntimeFactory__cctor_mE1EF2B3D2BB81BEC3BC4A4C058C835407C044A83 (void);
// 0x0000062B UnityEngine.UI.Text UnityEngine.UI.Dropdown/DropdownItem::get_text()
extern void DropdownItem_get_text_mABB014D2DEE9F6B24515DE71A08EBFA82BB44829 (void);
// 0x0000062C System.Void UnityEngine.UI.Dropdown/DropdownItem::set_text(UnityEngine.UI.Text)
extern void DropdownItem_set_text_m13D42A003AF95D99F2327E23532986F9FA1F0ABE (void);
// 0x0000062D UnityEngine.UI.Image UnityEngine.UI.Dropdown/DropdownItem::get_image()
extern void DropdownItem_get_image_m2879EEFCAB097FBA79BC4DA41ECBA4EBE3CB6185 (void);
// 0x0000062E System.Void UnityEngine.UI.Dropdown/DropdownItem::set_image(UnityEngine.UI.Image)
extern void DropdownItem_set_image_m7C2A0990EF4FA55AA50A963A93A31E0F28189766 (void);
// 0x0000062F UnityEngine.RectTransform UnityEngine.UI.Dropdown/DropdownItem::get_rectTransform()
extern void DropdownItem_get_rectTransform_mADBE4D843FE38C832CC1C9CFE03DC4D55B18E897 (void);
// 0x00000630 System.Void UnityEngine.UI.Dropdown/DropdownItem::set_rectTransform(UnityEngine.RectTransform)
extern void DropdownItem_set_rectTransform_m68DE1182C56F9C18124E9D2E7304879865B053C9 (void);
// 0x00000631 UnityEngine.UI.Toggle UnityEngine.UI.Dropdown/DropdownItem::get_toggle()
extern void DropdownItem_get_toggle_m6DAC29FD2E711343DBCDF240B3218BD6211886DE (void);
// 0x00000632 System.Void UnityEngine.UI.Dropdown/DropdownItem::set_toggle(UnityEngine.UI.Toggle)
extern void DropdownItem_set_toggle_m0EBE6629833FE4C6971885403B74CA15278BC0C9 (void);
// 0x00000633 System.Void UnityEngine.UI.Dropdown/DropdownItem::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void DropdownItem_OnPointerEnter_mC3E0428C434A3B627C94F704CDF7A0503A971DE1 (void);
// 0x00000634 System.Void UnityEngine.UI.Dropdown/DropdownItem::OnCancel(UnityEngine.EventSystems.BaseEventData)
extern void DropdownItem_OnCancel_m401BE297715C14DA0AED4DB0258E8429A4142AED (void);
// 0x00000635 System.Void UnityEngine.UI.Dropdown/DropdownItem::.ctor()
extern void DropdownItem__ctor_mD2D98375480B51AE8DC121299E662499ECA12EE6 (void);
// 0x00000636 System.String UnityEngine.UI.Dropdown/OptionData::get_text()
extern void OptionData_get_text_m2357EC665D55A54DDC6D7A150E2F74D95F915307 (void);
// 0x00000637 System.Void UnityEngine.UI.Dropdown/OptionData::set_text(System.String)
extern void OptionData_set_text_m294B34165F072EEF65BEB4700D5F1484A52DC30B (void);
// 0x00000638 UnityEngine.Sprite UnityEngine.UI.Dropdown/OptionData::get_image()
extern void OptionData_get_image_m0BF991D02528EE3C67FE841C3AA87EC1AE7D8E31 (void);
// 0x00000639 System.Void UnityEngine.UI.Dropdown/OptionData::set_image(UnityEngine.Sprite)
extern void OptionData_set_image_mF1FE39AF9BFE87422D0030C785F8631389B18701 (void);
// 0x0000063A System.Void UnityEngine.UI.Dropdown/OptionData::.ctor()
extern void OptionData__ctor_m5FF808A9DC863C8D595D5F6BD2DBDC02112F1606 (void);
// 0x0000063B System.Void UnityEngine.UI.Dropdown/OptionData::.ctor(System.String)
extern void OptionData__ctor_m72F6900DD27A92731D7B1FA02623D50440D747C3 (void);
// 0x0000063C System.Void UnityEngine.UI.Dropdown/OptionData::.ctor(UnityEngine.Sprite)
extern void OptionData__ctor_m376A2D81849FC01F09CCD5AB71BFDB596485B0A2 (void);
// 0x0000063D System.Void UnityEngine.UI.Dropdown/OptionData::.ctor(System.String,UnityEngine.Sprite)
extern void OptionData__ctor_m708D83F2BCCA7CBC3A9984B6A09128B73356FD3B (void);
// 0x0000063E System.Collections.Generic.List`1<UnityEngine.UI.Dropdown/OptionData> UnityEngine.UI.Dropdown/OptionDataList::get_options()
extern void OptionDataList_get_options_m3628E8C41BE97B1D4CB2B5C79CC127C5F6C82CCD (void);
// 0x0000063F System.Void UnityEngine.UI.Dropdown/OptionDataList::set_options(System.Collections.Generic.List`1<UnityEngine.UI.Dropdown/OptionData>)
extern void OptionDataList_set_options_mA01C00ADF9C913B4B1DB8B3FAA30F3D2DB31EF13 (void);
// 0x00000640 System.Void UnityEngine.UI.Dropdown/OptionDataList::.ctor()
extern void OptionDataList__ctor_mBD571B96180D97CDFDC446EE0E37ECFE76B3541A (void);
// 0x00000641 System.Void UnityEngine.UI.Dropdown/DropdownEvent::.ctor()
extern void DropdownEvent__ctor_m98DC282381C3C5B01E23CBCDC916E1E35913633C (void);
// 0x00000642 System.Void UnityEngine.UI.Dropdown/<>c__DisplayClass62_0::.ctor()
extern void U3CU3Ec__DisplayClass62_0__ctor_m5929C1C6009D2B9C3DDFDE80B361ACEE79669726 (void);
// 0x00000643 System.Void UnityEngine.UI.Dropdown/<>c__DisplayClass62_0::<Show>b__0(System.Boolean)
extern void U3CU3Ec__DisplayClass62_0_U3CShowU3Eb__0_m4658CA3C921911277414F27C3DBB031C3785EE68 (void);
// 0x00000644 System.Void UnityEngine.UI.Dropdown/<DelayedDestroyDropdownList>d__74::.ctor(System.Int32)
extern void U3CDelayedDestroyDropdownListU3Ed__74__ctor_m03CEC81B3046E88B824CD2BB0C86501875B704C8 (void);
// 0x00000645 System.Void UnityEngine.UI.Dropdown/<DelayedDestroyDropdownList>d__74::System.IDisposable.Dispose()
extern void U3CDelayedDestroyDropdownListU3Ed__74_System_IDisposable_Dispose_m93DD3230976C08FB2FF178D6D95AFBF1C68A6563 (void);
// 0x00000646 System.Boolean UnityEngine.UI.Dropdown/<DelayedDestroyDropdownList>d__74::MoveNext()
extern void U3CDelayedDestroyDropdownListU3Ed__74_MoveNext_mC00E6AFD4D66ACD103D5ED2C48122B62F15773AB (void);
// 0x00000647 System.Object UnityEngine.UI.Dropdown/<DelayedDestroyDropdownList>d__74::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CDelayedDestroyDropdownListU3Ed__74_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m5C30CA041CD316D3253B9CB66B6BD6B701C4A4FE (void);
// 0x00000648 System.Void UnityEngine.UI.Dropdown/<DelayedDestroyDropdownList>d__74::System.Collections.IEnumerator.Reset()
extern void U3CDelayedDestroyDropdownListU3Ed__74_System_Collections_IEnumerator_Reset_m74C17D4CEEEB9C55AB06699924515E8FF3A3F6EC (void);
// 0x00000649 System.Object UnityEngine.UI.Dropdown/<DelayedDestroyDropdownList>d__74::System.Collections.IEnumerator.get_Current()
extern void U3CDelayedDestroyDropdownListU3Ed__74_System_Collections_IEnumerator_get_Current_m1C2940A531BAB505629535360363D51C58DC412C (void);
// 0x0000064A System.Void UnityEngine.UI.GraphicRaycaster/<>c::.cctor()
extern void U3CU3Ec__cctor_m09851A52E0DB1A56F529BC8F005D78B94677D525 (void);
// 0x0000064B System.Void UnityEngine.UI.GraphicRaycaster/<>c::.ctor()
extern void U3CU3Ec__ctor_m04E92901B8E801154B3722C9E5E31E905E673D83 (void);
// 0x0000064C System.Int32 UnityEngine.UI.GraphicRaycaster/<>c::<Raycast>b__24_0(UnityEngine.UI.Graphic,UnityEngine.UI.Graphic)
extern void U3CU3Ec_U3CRaycastU3Eb__24_0_mB64ADCF5E31DFA898FDE3C24BAA00F8721EE915F (void);
// 0x0000064D System.Void UnityEngine.UI.InputField/OnValidateInput::.ctor(System.Object,System.IntPtr)
extern void OnValidateInput__ctor_mBB48714EA8D6CB0BF9C1CC4C5FAC4A3C0D919DA9 (void);
// 0x0000064E System.Char UnityEngine.UI.InputField/OnValidateInput::Invoke(System.String,System.Int32,System.Char)
extern void OnValidateInput_Invoke_m98D4EC458F62EA7382DCB4FB619BF6B8B8C9D986 (void);
// 0x0000064F System.IAsyncResult UnityEngine.UI.InputField/OnValidateInput::BeginInvoke(System.String,System.Int32,System.Char,System.AsyncCallback,System.Object)
extern void OnValidateInput_BeginInvoke_m0677E0E8084057293B39096DB67622649E15B77B (void);
// 0x00000650 System.Char UnityEngine.UI.InputField/OnValidateInput::EndInvoke(System.IAsyncResult)
extern void OnValidateInput_EndInvoke_m827F78F46319A1CAECBA5B5633B681D50B0EE6DA (void);
// 0x00000651 System.Void UnityEngine.UI.InputField/SubmitEvent::.ctor()
extern void SubmitEvent__ctor_m74537089F141326776A8E753F7D9ED8BC97A7285 (void);
// 0x00000652 System.Void UnityEngine.UI.InputField/OnChangeEvent::.ctor()
extern void OnChangeEvent__ctor_m9CE6922AF1E2E023088FDB57C76172CFA7090165 (void);
// 0x00000653 System.Void UnityEngine.UI.InputField/<CaretBlink>d__161::.ctor(System.Int32)
extern void U3CCaretBlinkU3Ed__161__ctor_mEE32F143BA27AA79DE5CBD24DE29E82E6E686F0B (void);
// 0x00000654 System.Void UnityEngine.UI.InputField/<CaretBlink>d__161::System.IDisposable.Dispose()
extern void U3CCaretBlinkU3Ed__161_System_IDisposable_Dispose_m98F4AA2B16FA9DFB7D6E4B8585539CC87A3922FF (void);
// 0x00000655 System.Boolean UnityEngine.UI.InputField/<CaretBlink>d__161::MoveNext()
extern void U3CCaretBlinkU3Ed__161_MoveNext_m7466BE75DA87CF3583561D803D2F11175E388476 (void);
// 0x00000656 System.Object UnityEngine.UI.InputField/<CaretBlink>d__161::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CCaretBlinkU3Ed__161_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m92F79A5BD86298B4D82B5CFD0459E471B631338D (void);
// 0x00000657 System.Void UnityEngine.UI.InputField/<CaretBlink>d__161::System.Collections.IEnumerator.Reset()
extern void U3CCaretBlinkU3Ed__161_System_Collections_IEnumerator_Reset_mF3537E69989F503BBE2B217E5B4AF1AD8F1E2D1E (void);
// 0x00000658 System.Object UnityEngine.UI.InputField/<CaretBlink>d__161::System.Collections.IEnumerator.get_Current()
extern void U3CCaretBlinkU3Ed__161_System_Collections_IEnumerator_get_Current_m109EAA38605D487FB5DCA78EFFFC2B6FE5C7FD23 (void);
// 0x00000659 System.Void UnityEngine.UI.InputField/<MouseDragOutsideRect>d__181::.ctor(System.Int32)
extern void U3CMouseDragOutsideRectU3Ed__181__ctor_m5895816668E36FCF68396450F3A4B5275286AC8E (void);
// 0x0000065A System.Void UnityEngine.UI.InputField/<MouseDragOutsideRect>d__181::System.IDisposable.Dispose()
extern void U3CMouseDragOutsideRectU3Ed__181_System_IDisposable_Dispose_mF021FCC22512C83D42703FE834AA2818C69B3483 (void);
// 0x0000065B System.Boolean UnityEngine.UI.InputField/<MouseDragOutsideRect>d__181::MoveNext()
extern void U3CMouseDragOutsideRectU3Ed__181_MoveNext_m1FB4B9D529753BB151092B532DC53D115385D805 (void);
// 0x0000065C System.Object UnityEngine.UI.InputField/<MouseDragOutsideRect>d__181::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CMouseDragOutsideRectU3Ed__181_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mAFDC6F4B29255C18CC6C1DDD6545A0D20A7E5C40 (void);
// 0x0000065D System.Void UnityEngine.UI.InputField/<MouseDragOutsideRect>d__181::System.Collections.IEnumerator.Reset()
extern void U3CMouseDragOutsideRectU3Ed__181_System_Collections_IEnumerator_Reset_m5148663FAB05E421112373BAD77616EDB87FAE23 (void);
// 0x0000065E System.Object UnityEngine.UI.InputField/<MouseDragOutsideRect>d__181::System.Collections.IEnumerator.get_Current()
extern void U3CMouseDragOutsideRectU3Ed__181_System_Collections_IEnumerator_get_Current_mC75B3F370A087B33E84851F4CB3D7909AC357ED1 (void);
// 0x0000065F System.Void UnityEngine.UI.LayoutGroup/<DelayedSetDirty>d__56::.ctor(System.Int32)
extern void U3CDelayedSetDirtyU3Ed__56__ctor_m529A39CB39042BBBE0EE03E4C8A3107229DC58C1 (void);
// 0x00000660 System.Void UnityEngine.UI.LayoutGroup/<DelayedSetDirty>d__56::System.IDisposable.Dispose()
extern void U3CDelayedSetDirtyU3Ed__56_System_IDisposable_Dispose_m70DD814B7FFBC17F3D9E3DACD96BFDB3457AF8BF (void);
// 0x00000661 System.Boolean UnityEngine.UI.LayoutGroup/<DelayedSetDirty>d__56::MoveNext()
extern void U3CDelayedSetDirtyU3Ed__56_MoveNext_m2781C1A3EE9B2EED7720D9968DF9A2CC42065359 (void);
// 0x00000662 System.Object UnityEngine.UI.LayoutGroup/<DelayedSetDirty>d__56::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CDelayedSetDirtyU3Ed__56_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m7737C45381E05C537F78B44351DCFCD4E81DB038 (void);
// 0x00000663 System.Void UnityEngine.UI.LayoutGroup/<DelayedSetDirty>d__56::System.Collections.IEnumerator.Reset()
extern void U3CDelayedSetDirtyU3Ed__56_System_Collections_IEnumerator_Reset_m1A72776AC2771716E1727638FF498FCDFFB8704A (void);
// 0x00000664 System.Object UnityEngine.UI.LayoutGroup/<DelayedSetDirty>d__56::System.Collections.IEnumerator.get_Current()
extern void U3CDelayedSetDirtyU3Ed__56_System_Collections_IEnumerator_get_Current_mCBF048846EEE3A89A3D52EEE0BEBAF8B9A4608F1 (void);
// 0x00000665 System.Void UnityEngine.UI.LayoutRebuilder/<>c::.cctor()
extern void U3CU3Ec__cctor_mC1EA7386950FAEFA79F38DA008A1F42AEF1939CA (void);
// 0x00000666 System.Void UnityEngine.UI.LayoutRebuilder/<>c::.ctor()
extern void U3CU3Ec__ctor_m084320279C0D4A109E26ED227B59EE5549AC7173 (void);
// 0x00000667 System.Void UnityEngine.UI.LayoutRebuilder/<>c::<.cctor>b__5_0(UnityEngine.UI.LayoutRebuilder)
extern void U3CU3Ec_U3C_cctorU3Eb__5_0_mF2DD128E53E9561C0A2917EF9155E6A14246BD3D (void);
// 0x00000668 System.Boolean UnityEngine.UI.LayoutRebuilder/<>c::<StripDisabledBehavioursFromList>b__10_0(UnityEngine.Component)
extern void U3CU3Ec_U3CStripDisabledBehavioursFromListU3Eb__10_0_m35B3C6C5477F634C10AEA30C9C2CE92FD230E0F8 (void);
// 0x00000669 System.Void UnityEngine.UI.LayoutRebuilder/<>c::<Rebuild>b__12_0(UnityEngine.Component)
extern void U3CU3Ec_U3CRebuildU3Eb__12_0_mE1965E7B777527BBC12ED56BB35F88CAA996DCD8 (void);
// 0x0000066A System.Void UnityEngine.UI.LayoutRebuilder/<>c::<Rebuild>b__12_1(UnityEngine.Component)
extern void U3CU3Ec_U3CRebuildU3Eb__12_1_m19527422BC1212F7965D5598BED02219A03AF933 (void);
// 0x0000066B System.Void UnityEngine.UI.LayoutRebuilder/<>c::<Rebuild>b__12_2(UnityEngine.Component)
extern void U3CU3Ec_U3CRebuildU3Eb__12_2_m690D9E696A8EBA4A51C10493E370BEB9F45E83B3 (void);
// 0x0000066C System.Void UnityEngine.UI.LayoutRebuilder/<>c::<Rebuild>b__12_3(UnityEngine.Component)
extern void U3CU3Ec_U3CRebuildU3Eb__12_3_m4A5765125712390B59375296E31ED10F214846AD (void);
// 0x0000066D System.Void UnityEngine.UI.LayoutUtility/<>c::.cctor()
extern void U3CU3Ec__cctor_mD80A5E583F0C1BAC67483C0D8BA610373CFBF0DD (void);
// 0x0000066E System.Void UnityEngine.UI.LayoutUtility/<>c::.ctor()
extern void U3CU3Ec__ctor_mCDA376F3170EEBBAA438CC23B7C179DC68C4D971 (void);
// 0x0000066F System.Single UnityEngine.UI.LayoutUtility/<>c::<GetMinWidth>b__3_0(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetMinWidthU3Eb__3_0_m2069017629E7B6ED1B09384A06C8485297BF556A (void);
// 0x00000670 System.Single UnityEngine.UI.LayoutUtility/<>c::<GetPreferredWidth>b__4_0(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetPreferredWidthU3Eb__4_0_m83F4E2D085E2C69291FB65A85CB791D66E6D3CAC (void);
// 0x00000671 System.Single UnityEngine.UI.LayoutUtility/<>c::<GetPreferredWidth>b__4_1(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetPreferredWidthU3Eb__4_1_m721CC8A71D9AFD03BBF7895BFB96447FA3D979DF (void);
// 0x00000672 System.Single UnityEngine.UI.LayoutUtility/<>c::<GetFlexibleWidth>b__5_0(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetFlexibleWidthU3Eb__5_0_m01ECFD6FA8A4ADF08229656881AED4A23916F31F (void);
// 0x00000673 System.Single UnityEngine.UI.LayoutUtility/<>c::<GetMinHeight>b__6_0(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetMinHeightU3Eb__6_0_mC491799C5F4CA7F6198F2EC054798A876D7DBBF8 (void);
// 0x00000674 System.Single UnityEngine.UI.LayoutUtility/<>c::<GetPreferredHeight>b__7_0(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetPreferredHeightU3Eb__7_0_m09ED4C4B779BE9FEA5D8CCBBF0D9BC2332FDDAAC (void);
// 0x00000675 System.Single UnityEngine.UI.LayoutUtility/<>c::<GetPreferredHeight>b__7_1(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetPreferredHeightU3Eb__7_1_m5179206B47415CE24731EA3FFB9E2BF5DEF2E333 (void);
// 0x00000676 System.Single UnityEngine.UI.LayoutUtility/<>c::<GetFlexibleHeight>b__8_0(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetFlexibleHeightU3Eb__8_0_m7FDE30BEF1440F8F005B31F91BE3D9D3E6EC116E (void);
// 0x00000677 System.Void UnityEngine.UI.MaskableGraphic/CullStateChangedEvent::.ctor()
extern void CullStateChangedEvent__ctor_mA3A9152BAA97B289838CA14DA00507B77243CDF4 (void);
// 0x00000678 System.Void UnityEngine.UI.ScrollRect/ScrollRectEvent::.ctor()
extern void ScrollRectEvent__ctor_m826A11CD578D616068EFFE0DD61FC88F837B5FC8 (void);
// 0x00000679 System.Void UnityEngine.UI.Scrollbar/ScrollEvent::.ctor()
extern void ScrollEvent__ctor_mAFB20E7E36EB16E63F6521F87E1D8C35A61F8824 (void);
// 0x0000067A System.Void UnityEngine.UI.Scrollbar/<ClickRepeat>d__58::.ctor(System.Int32)
extern void U3CClickRepeatU3Ed__58__ctor_m6AC874A97FA925E7488837001D30572626C2C49A (void);
// 0x0000067B System.Void UnityEngine.UI.Scrollbar/<ClickRepeat>d__58::System.IDisposable.Dispose()
extern void U3CClickRepeatU3Ed__58_System_IDisposable_Dispose_m1981D05AE9BC4E2CF928E606DBAFB10715B6EE19 (void);
// 0x0000067C System.Boolean UnityEngine.UI.Scrollbar/<ClickRepeat>d__58::MoveNext()
extern void U3CClickRepeatU3Ed__58_MoveNext_m2FB8B1CFC5FDE4173657F588C73C08666C34B9C7 (void);
// 0x0000067D System.Object UnityEngine.UI.Scrollbar/<ClickRepeat>d__58::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CClickRepeatU3Ed__58_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m53369E7AD64C694A0FD93B61C12DBEF007FF6AAF (void);
// 0x0000067E System.Void UnityEngine.UI.Scrollbar/<ClickRepeat>d__58::System.Collections.IEnumerator.Reset()
extern void U3CClickRepeatU3Ed__58_System_Collections_IEnumerator_Reset_m65C1F2B932740F096DA508B30A1B97D5AE61C0DF (void);
// 0x0000067F System.Object UnityEngine.UI.Scrollbar/<ClickRepeat>d__58::System.Collections.IEnumerator.get_Current()
extern void U3CClickRepeatU3Ed__58_System_Collections_IEnumerator_get_Current_mDD3F99EF8AFD5885DF27792CC6727F443354808A (void);
// 0x00000680 System.Void UnityEngine.UI.Slider/SliderEvent::.ctor()
extern void SliderEvent__ctor_m219C5074B774908A83C9C54128370E75556A18E0 (void);
// 0x00000681 System.Void UnityEngine.UI.StencilMaterial/MatEntry::.ctor()
extern void MatEntry__ctor_m1088ABC0B5320FB051D0F7036D1AEC006C48AD1B (void);
// 0x00000682 System.Void UnityEngine.UI.Toggle/ToggleEvent::.ctor()
extern void ToggleEvent__ctor_mF58CC00AEC0CB149ACB267F0A885D814164B484C (void);
// 0x00000683 System.Void UnityEngine.UI.ToggleGroup/<>c::.cctor()
extern void U3CU3Ec__cctor_m89E177F13473C664F86CBB611035208949610E03 (void);
// 0x00000684 System.Void UnityEngine.UI.ToggleGroup/<>c::.ctor()
extern void U3CU3Ec__ctor_m5F8E8E3F5E9EC721D150BB724313F4FD39798537 (void);
// 0x00000685 System.Boolean UnityEngine.UI.ToggleGroup/<>c::<AnyTogglesOn>b__12_0(UnityEngine.UI.Toggle)
extern void U3CU3Ec_U3CAnyTogglesOnU3Eb__12_0_m6759194C9A27BC7726498AEA91636DE01DB5946C (void);
// 0x00000686 System.Boolean UnityEngine.UI.ToggleGroup/<>c::<ActiveToggles>b__13_0(UnityEngine.UI.Toggle)
extern void U3CU3Ec_U3CActiveTogglesU3Eb__13_0_m0FFD86D1B257988730B5BD85D42BD9E892FF37E5 (void);
// 0x00000687 System.Void UnityEngine.UI.ReflectionMethodsCache/Raycast3DCallback::.ctor(System.Object,System.IntPtr)
extern void Raycast3DCallback__ctor_mCB0759C0BFDAE7E4FCAE3BE3635DEF37A237F09A (void);
// 0x00000688 System.Boolean UnityEngine.UI.ReflectionMethodsCache/Raycast3DCallback::Invoke(UnityEngine.Ray,UnityEngine.RaycastHit&,System.Single,System.Int32)
extern void Raycast3DCallback_Invoke_m96DCB0F99B7985CE4A213570BAA007F9C281D437 (void);
// 0x00000689 System.IAsyncResult UnityEngine.UI.ReflectionMethodsCache/Raycast3DCallback::BeginInvoke(UnityEngine.Ray,UnityEngine.RaycastHit&,System.Single,System.Int32,System.AsyncCallback,System.Object)
extern void Raycast3DCallback_BeginInvoke_mF70380A191C13DA5AFD5617EF8E05D0166AB9193 (void);
// 0x0000068A System.Boolean UnityEngine.UI.ReflectionMethodsCache/Raycast3DCallback::EndInvoke(UnityEngine.RaycastHit&,System.IAsyncResult)
extern void Raycast3DCallback_EndInvoke_mD10DFF1413244239AEA66792FF0FDC14076F7E99 (void);
// 0x0000068B System.Void UnityEngine.UI.ReflectionMethodsCache/RaycastAllCallback::.ctor(System.Object,System.IntPtr)
extern void RaycastAllCallback__ctor_m1124C55632F15FE52408AB3760D9516CFECBFC19 (void);
// 0x0000068C UnityEngine.RaycastHit[] UnityEngine.UI.ReflectionMethodsCache/RaycastAllCallback::Invoke(UnityEngine.Ray,System.Single,System.Int32)
extern void RaycastAllCallback_Invoke_mA25988726DFF992942D7F9753C8B38AAF06408E9 (void);
// 0x0000068D System.IAsyncResult UnityEngine.UI.ReflectionMethodsCache/RaycastAllCallback::BeginInvoke(UnityEngine.Ray,System.Single,System.Int32,System.AsyncCallback,System.Object)
extern void RaycastAllCallback_BeginInvoke_mF3B3CE2228DAC1D6139A7E6A37CF58C1763E8E53 (void);
// 0x0000068E UnityEngine.RaycastHit[] UnityEngine.UI.ReflectionMethodsCache/RaycastAllCallback::EndInvoke(System.IAsyncResult)
extern void RaycastAllCallback_EndInvoke_mD35715DAD2F11C5EF0FE134586A10A0615D65E9C (void);
// 0x0000068F System.Void UnityEngine.UI.ReflectionMethodsCache/GetRaycastNonAllocCallback::.ctor(System.Object,System.IntPtr)
extern void GetRaycastNonAllocCallback__ctor_m63DAC81049B9F7C8527A85094FD9FB19ADDD043A (void);
// 0x00000690 System.Int32 UnityEngine.UI.ReflectionMethodsCache/GetRaycastNonAllocCallback::Invoke(UnityEngine.Ray,UnityEngine.RaycastHit[],System.Single,System.Int32)
extern void GetRaycastNonAllocCallback_Invoke_mC5C9CC9CC617A89C284D1DE7DD297A2E3D9E4163 (void);
// 0x00000691 System.IAsyncResult UnityEngine.UI.ReflectionMethodsCache/GetRaycastNonAllocCallback::BeginInvoke(UnityEngine.Ray,UnityEngine.RaycastHit[],System.Single,System.Int32,System.AsyncCallback,System.Object)
extern void GetRaycastNonAllocCallback_BeginInvoke_mA840990486DEAB55DF085B0838CC40778B23AAD0 (void);
// 0x00000692 System.Int32 UnityEngine.UI.ReflectionMethodsCache/GetRaycastNonAllocCallback::EndInvoke(System.IAsyncResult)
extern void GetRaycastNonAllocCallback_EndInvoke_m27AAC229334FF8E13A13D6865ABA5EFE15DB37BD (void);
// 0x00000693 System.Void UnityEngine.UI.ReflectionMethodsCache/Raycast2DCallback::.ctor(System.Object,System.IntPtr)
extern void Raycast2DCallback__ctor_m0F3912611ABC792CA238BB0A7A774AB9AC01B52E (void);
// 0x00000694 UnityEngine.RaycastHit2D UnityEngine.UI.ReflectionMethodsCache/Raycast2DCallback::Invoke(UnityEngine.Vector2,UnityEngine.Vector2,System.Single,System.Int32)
extern void Raycast2DCallback_Invoke_mE8A24A7158D5A2DEEA1C37210A230A0BFF084603 (void);
// 0x00000695 System.IAsyncResult UnityEngine.UI.ReflectionMethodsCache/Raycast2DCallback::BeginInvoke(UnityEngine.Vector2,UnityEngine.Vector2,System.Single,System.Int32,System.AsyncCallback,System.Object)
extern void Raycast2DCallback_BeginInvoke_mF504BADFEEC32EE4F4392F1895175B921A037D85 (void);
// 0x00000696 UnityEngine.RaycastHit2D UnityEngine.UI.ReflectionMethodsCache/Raycast2DCallback::EndInvoke(System.IAsyncResult)
extern void Raycast2DCallback_EndInvoke_mFCF0BDB5B7142F6DA030059561764A974E656F88 (void);
// 0x00000697 System.Void UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllCallback::.ctor(System.Object,System.IntPtr)
extern void GetRayIntersectionAllCallback__ctor_m5E404A80C54052DFD314FEEE35844AFB06E5F03E (void);
// 0x00000698 UnityEngine.RaycastHit2D[] UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllCallback::Invoke(UnityEngine.Ray,System.Single,System.Int32)
extern void GetRayIntersectionAllCallback_Invoke_m57AD088B59768E362F4EA3B665E5153E9282D511 (void);
// 0x00000699 System.IAsyncResult UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllCallback::BeginInvoke(UnityEngine.Ray,System.Single,System.Int32,System.AsyncCallback,System.Object)
extern void GetRayIntersectionAllCallback_BeginInvoke_mC6074520BD09886702C3039D34BEB8ED1B8F71B4 (void);
// 0x0000069A UnityEngine.RaycastHit2D[] UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllCallback::EndInvoke(System.IAsyncResult)
extern void GetRayIntersectionAllCallback_EndInvoke_mFBD3797128011018C74318B12D85BED8F658FFC9 (void);
// 0x0000069B System.Void UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllNonAllocCallback::.ctor(System.Object,System.IntPtr)
extern void GetRayIntersectionAllNonAllocCallback__ctor_m854C98B55B734C291A6CED4B7F2D9F149B03FCEC (void);
// 0x0000069C System.Int32 UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllNonAllocCallback::Invoke(UnityEngine.Ray,UnityEngine.RaycastHit2D[],System.Single,System.Int32)
extern void GetRayIntersectionAllNonAllocCallback_Invoke_mB9D518882273DDC16919EE0122A97D629FD0457F (void);
// 0x0000069D System.IAsyncResult UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllNonAllocCallback::BeginInvoke(UnityEngine.Ray,UnityEngine.RaycastHit2D[],System.Single,System.Int32,System.AsyncCallback,System.Object)
extern void GetRayIntersectionAllNonAllocCallback_BeginInvoke_mDFEEFE0E75899C6CD9F756EC4EDFCCD3262F356D (void);
// 0x0000069E System.Int32 UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllNonAllocCallback::EndInvoke(System.IAsyncResult)
extern void GetRayIntersectionAllNonAllocCallback_EndInvoke_m6A187B845ED00824B2922125A3DF0C96DDC71154 (void);
// 0x0000069F System.Void UnityEngine.UI.CoroutineTween.ColorTween/ColorTweenCallback::.ctor()
extern void ColorTweenCallback__ctor_mBB57DF8BE131686390944A01A6A10A8FBC2DE005 (void);
// 0x000006A0 System.Void UnityEngine.UI.CoroutineTween.FloatTween/FloatTweenCallback::.ctor()
extern void FloatTweenCallback__ctor_m85BC42EE5784B9D8659BE634B8F46BFF06933EEE (void);
// 0x000006A1 System.Void UnityEngine.UI.CoroutineTween.TweenRunner`1/<Start>d__2::.ctor(System.Int32)
// 0x000006A2 System.Void UnityEngine.UI.CoroutineTween.TweenRunner`1/<Start>d__2::System.IDisposable.Dispose()
// 0x000006A3 System.Boolean UnityEngine.UI.CoroutineTween.TweenRunner`1/<Start>d__2::MoveNext()
// 0x000006A4 System.Object UnityEngine.UI.CoroutineTween.TweenRunner`1/<Start>d__2::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
// 0x000006A5 System.Void UnityEngine.UI.CoroutineTween.TweenRunner`1/<Start>d__2::System.Collections.IEnumerator.Reset()
// 0x000006A6 System.Object UnityEngine.UI.CoroutineTween.TweenRunner`1/<Start>d__2::System.Collections.IEnumerator.get_Current()
// 0x000006A7 System.Void UnityEngine.EventSystems.EventTrigger/TriggerEvent::.ctor()
extern void TriggerEvent__ctor_mE5A64BDC6F94313C8240612A623EAAB29F25ADAF (void);
// 0x000006A8 System.Void UnityEngine.EventSystems.EventTrigger/Entry::.ctor()
extern void Entry__ctor_mA35142E0673AB7824813B59E527C474605E09B7C (void);
// 0x000006A9 System.Void UnityEngine.EventSystems.ExecuteEvents/EventFunction`1::.ctor(System.Object,System.IntPtr)
// 0x000006AA System.Void UnityEngine.EventSystems.ExecuteEvents/EventFunction`1::Invoke(T1,UnityEngine.EventSystems.BaseEventData)
// 0x000006AB System.IAsyncResult UnityEngine.EventSystems.ExecuteEvents/EventFunction`1::BeginInvoke(T1,UnityEngine.EventSystems.BaseEventData,System.AsyncCallback,System.Object)
// 0x000006AC System.Void UnityEngine.EventSystems.ExecuteEvents/EventFunction`1::EndInvoke(System.IAsyncResult)
// 0x000006AD System.Void UnityEngine.EventSystems.ExecuteEvents/<>c::.cctor()
extern void U3CU3Ec__cctor_m318A0D8B2A1679122D4022E2563BA291EE812748 (void);
// 0x000006AE System.Void UnityEngine.EventSystems.ExecuteEvents/<>c::.ctor()
extern void U3CU3Ec__ctor_m919606841B6135F79DD98C8ADA83F41FA354F1EA (void);
// 0x000006AF System.Void UnityEngine.EventSystems.ExecuteEvents/<>c::<.cctor>b__79_0(System.Collections.Generic.List`1<UnityEngine.EventSystems.IEventSystemHandler>)
extern void U3CU3Ec_U3C_cctorU3Eb__79_0_mF66ED8AEFC42C39E1BD94028C7F4468AE702BBFE (void);
// 0x000006B0 UnityEngine.EventSystems.PointerInputModule/MouseButtonEventData UnityEngine.EventSystems.PointerInputModule/ButtonState::get_eventData()
extern void ButtonState_get_eventData_mA9D054D526473A2481A997758CDDEB022E67351D (void);
// 0x000006B1 System.Void UnityEngine.EventSystems.PointerInputModule/ButtonState::set_eventData(UnityEngine.EventSystems.PointerInputModule/MouseButtonEventData)
extern void ButtonState_set_eventData_m3E72ED95C634264A32BE660552D22684B0BF8B55 (void);
// 0x000006B2 UnityEngine.EventSystems.PointerEventData/InputButton UnityEngine.EventSystems.PointerInputModule/ButtonState::get_button()
extern void ButtonState_get_button_mB538B2D483C482A7E628D26BA390449A54C958A3 (void);
// 0x000006B3 System.Void UnityEngine.EventSystems.PointerInputModule/ButtonState::set_button(UnityEngine.EventSystems.PointerEventData/InputButton)
extern void ButtonState_set_button_m9D44DBD86C06F5C9DF68A84CD5D89A4847E02D68 (void);
// 0x000006B4 System.Void UnityEngine.EventSystems.PointerInputModule/ButtonState::.ctor()
extern void ButtonState__ctor_m96C223DB2B958828D45ACB15D1CF32C4B87FFA97 (void);
// 0x000006B5 System.Boolean UnityEngine.EventSystems.PointerInputModule/MouseState::AnyPressesThisFrame()
extern void MouseState_AnyPressesThisFrame_m8055332F4AA44246655B6E19522E1A39CB172D95 (void);
// 0x000006B6 System.Boolean UnityEngine.EventSystems.PointerInputModule/MouseState::AnyReleasesThisFrame()
extern void MouseState_AnyReleasesThisFrame_mCB786F99845E669E59BF259723A2368931A324EC (void);
// 0x000006B7 UnityEngine.EventSystems.PointerInputModule/ButtonState UnityEngine.EventSystems.PointerInputModule/MouseState::GetButtonState(UnityEngine.EventSystems.PointerEventData/InputButton)
extern void MouseState_GetButtonState_m0C2884609F720A284C72EAEF061C781F4874CCAE (void);
// 0x000006B8 System.Void UnityEngine.EventSystems.PointerInputModule/MouseState::SetButtonState(UnityEngine.EventSystems.PointerEventData/InputButton,UnityEngine.EventSystems.PointerEventData/FramePressState,UnityEngine.EventSystems.PointerEventData)
extern void MouseState_SetButtonState_m4A6AB431337B8CFE2C51E7E73D9C1A15D9C78BB4 (void);
// 0x000006B9 System.Void UnityEngine.EventSystems.PointerInputModule/MouseState::.ctor()
extern void MouseState__ctor_mCEC029743547501A89B66C448642D3BA8D5EB600 (void);
// 0x000006BA System.Boolean UnityEngine.EventSystems.PointerInputModule/MouseButtonEventData::PressedThisFrame()
extern void MouseButtonEventData_PressedThisFrame_m172F2A7A82DED3678EF87AD1B4FD69D6D406E176 (void);
// 0x000006BB System.Boolean UnityEngine.EventSystems.PointerInputModule/MouseButtonEventData::ReleasedThisFrame()
extern void MouseButtonEventData_ReleasedThisFrame_mE4BFCF235B7D4B71D41FE3A4CDB376701001CD40 (void);
// 0x000006BC System.Void UnityEngine.EventSystems.PointerInputModule/MouseButtonEventData::.ctor()
extern void MouseButtonEventData__ctor_mB419FF26D986E03E724C39FC0BF03B8B2C461FD3 (void);
// 0x000006BD System.Int32 UnityEngine.EventSystems.PhysicsRaycaster/RaycastHitComparer::Compare(UnityEngine.RaycastHit,UnityEngine.RaycastHit)
extern void RaycastHitComparer_Compare_mE19E714A83902B3157EE83A24916967E8D4EBE8C (void);
// 0x000006BE System.Void UnityEngine.EventSystems.PhysicsRaycaster/RaycastHitComparer::.ctor()
extern void RaycastHitComparer__ctor_mE4EE9168BDABF1148A3071071A676F5343A867DD (void);
// 0x000006BF System.Void UnityEngine.EventSystems.PhysicsRaycaster/RaycastHitComparer::.cctor()
extern void RaycastHitComparer__cctor_mD1A6F09923FDD75B9F5D0AE505FD788507B84A40 (void);
static Il2CppMethodPointer s_methodPointers[1727] = 
{
	AnimationTriggers_get_normalTrigger_m823230E912A9564E56E2047E9E3A819B2B8FA55C,
	AnimationTriggers_set_normalTrigger_m5F067D4F2FE49D95597B57047C3409F49633E46E,
	AnimationTriggers_get_highlightedTrigger_mD525FBB2FE079F203C0D93E1C361E8EDB2F3A3E0,
	AnimationTriggers_set_highlightedTrigger_m1F0FA3B4776E5CDA87AD942BE5694CEC8789E433,
	AnimationTriggers_get_pressedTrigger_m00190AD173D951B0F7E85B5F34361FE05AB1DE44,
	AnimationTriggers_set_pressedTrigger_mF29EFB61939FE540D2849F96E8E1F0064E6647F2,
	AnimationTriggers_get_selectedTrigger_m008AFE8B295E04A47A1DD0B892EAE0506A9230FB,
	AnimationTriggers_set_selectedTrigger_m5E60D0E74C1A135BC8954EDF5479EC4780A65FD0,
	AnimationTriggers_get_disabledTrigger_mBC66170C0C45E08679FF1573FEE0F2B66175C83E,
	AnimationTriggers_set_disabledTrigger_mCCB3B04B6691787427DDFF8B1DCD49C198D263BA,
	AnimationTriggers__ctor_m11FA25E6EC5A9BA71A3F725FDBAA3F5527AF946F,
	Button__ctor_mEAD32B0D4006442C955F50B4577C5DF907EBCB5B,
	Button_get_onClick_m77E8CA6917881760CC7900930F4C789F3E2F8817,
	Button_set_onClick_m65B3D7697B513EEAB4193A246BE8D93C0D9B29DE,
	Button_Press_m33BA6E9820146E8EED7AB489A8846D879B76CF41,
	Button_OnPointerClick_m4C4EDB8613C2C5B391EFD3A29C58B0AA00DD9B91,
	Button_OnSubmit_m7CE6A04596CA9691D3E0D6D669FAD86E9A6D3427,
	Button_OnFinishSubmit_mDDCC87F264A34E86148891F24646F655C0AF7E42,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	CanvasUpdateRegistry__ctor_mA9DFE374CF59026B50EBE37E147854270730EE00,
	CanvasUpdateRegistry_get_instance_m6A2150EA4C8C74AF18E53B3CF22BF6EAF70FF927,
	CanvasUpdateRegistry_ObjectValidForUpdate_m2E72AF124053FD1E9003B488EC296410A74566C6,
	CanvasUpdateRegistry_CleanInvalidItems_mBCA41C6F93EA42647274051F7DA61F36D3330DA3,
	CanvasUpdateRegistry_PerformUpdate_m394F8B8FDD92DFCDFEEF86767B7A294B04211719,
	CanvasUpdateRegistry_ParentCount_m198B2252296D2FE5BB5EB22EBE0FD1444B8E81A9,
	CanvasUpdateRegistry_SortLayoutList_m157F65FF5A7EB039678F6EF3B1F3B8CF355BD4EB,
	CanvasUpdateRegistry_RegisterCanvasElementForLayoutRebuild_m97E606B5F1E848A6ACBA44ABE5E5A2A5ED99DCDA,
	CanvasUpdateRegistry_TryRegisterCanvasElementForLayoutRebuild_m1AE79FC7D20A9212CB55D436BA9AE807A22E2A1F,
	CanvasUpdateRegistry_InternalRegisterCanvasElementForLayoutRebuild_m1F8CC12B180B85AE9D3CA4ED52DE3A4544A9D5E4,
	CanvasUpdateRegistry_RegisterCanvasElementForGraphicRebuild_m0D3A7158D8301462FF18CC00909AD105FF1591AE,
	CanvasUpdateRegistry_TryRegisterCanvasElementForGraphicRebuild_m36405C59F3D0FA49C55737FE5481D00F5BC6350F,
	CanvasUpdateRegistry_InternalRegisterCanvasElementForGraphicRebuild_mFEFBCA741876E89C572A3BFBFD7EEC4D0FE503E4,
	CanvasUpdateRegistry_UnRegisterCanvasElementForRebuild_m79A4C7207CDAC083E716F9AA859F1763B8F84D84,
	CanvasUpdateRegistry_InternalUnRegisterCanvasElementForLayoutRebuild_m3F6811D17DFF1519E71788D368A7BEB860DCE9E4,
	CanvasUpdateRegistry_InternalUnRegisterCanvasElementForGraphicRebuild_mCACDA2130D25B96229C3C1594D44BD9347420784,
	CanvasUpdateRegistry_IsRebuildingLayout_m5720F54D56B252982240E5DF4723A3BA7B7A891B,
	CanvasUpdateRegistry_IsRebuildingGraphics_m1C67401F44BB421AE8945B8B1B3CD2AC61B75E89,
	CanvasUpdateRegistry__cctor_m97762F83684218576BD97297F450827240460C51,
	ColorBlock_get_normalColor_mE0A4EBADEFB7A6F245F590B0A5DBB59F289C0905,
	ColorBlock_set_normalColor_mAB3355641A3BA73B63E1A8727EC51A095262CC51,
	ColorBlock_get_highlightedColor_m779349828B304DB2551C3A3CCDDD69861A21EDFF,
	ColorBlock_set_highlightedColor_m7E9A152B71CD6CBD5BEE9E4019547BD9CC991AF6,
	ColorBlock_get_pressedColor_m19AA95DCC2519975D93202C997EECB3E06CE96E5,
	ColorBlock_set_pressedColor_m252EDA03CA097EF1604FF2678598BA6A294C13C8,
	ColorBlock_get_selectedColor_mE6DDB9D2D3466CCFFFF000286619BEC4AB60F83D,
	ColorBlock_set_selectedColor_mE731B0D4FFE33D3438CA3757F72B6808066937E2,
	ColorBlock_get_disabledColor_mD865FC8BCFE7B8535A51A68E78130409F3C97FC8,
	ColorBlock_set_disabledColor_mABE874E9EF8C41CE83BB16B94C7511AF1FE8AE47,
	ColorBlock_get_colorMultiplier_mA273A409AC9125C22CBCCB236F0E758C36BA9581,
	ColorBlock_set_colorMultiplier_m8EE6BD49B92CA0C7E801E9D4E39F0AB39237FE26,
	ColorBlock_get_fadeDuration_mCFF802DD654D7E9C3509A65974EB35153FDB1415,
	ColorBlock_set_fadeDuration_m2C1C0A118396BB2DF370F2F87A6ECA861AE0CA63,
	ColorBlock_get_defaultColorBlock_mD3AEFDABCF5F714D81FB2047A744930650EC223E,
	ColorBlock_Equals_m5F50CD8C86A89B8EFA4E878BD914656ECEB0177D,
	ColorBlock_Equals_mCD07A68D8E306D372ECA1D13BDA091E9579B4AEE,
	ColorBlock_op_Equality_m5D66A64DD671C058B490AB603192AF53B505DE86,
	ColorBlock_op_Inequality_m78ECD4DA562EA2A1C98E66315F0A1BCB448603D6,
	ColorBlock_GetHashCode_m92C2ECB5F5118D21A01C35481D8CC9A091AB6B4B,
	ClipperRegistry__ctor_m7F1EE293535B9B61C281BC6CCF563051B1212A74,
	ClipperRegistry_get_instance_mE4E214237577A08B2A6C8AF9DD7CDAE1B75E387B,
	ClipperRegistry_Cull_m1ECFA826A6969A177CE2DC701056E4A5E73A4BCB,
	ClipperRegistry_Register_mF8163BA97EA885507238312E699186155494D4F6,
	ClipperRegistry_Unregister_mE9C2B3D8B5C8C71FE5B888D621EABC5E7639C7A2,
	Clipping_FindCullAndClipWorldRect_m1006EEFD92ECCD0551162A8E4D677970A00B597A,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	RectangularVertexClipper_GetCanvasRect_m3A009069CB93F6A0D61221B26FD7BACD6A57533F,
	RectangularVertexClipper__ctor_mEE97397722ADAA581A3DF8267BA5DBCFE585AC6A,
	DefaultControls_get_factory_m616056407908402EFF7E24BC02D0A1B0CDED98B2,
	DefaultControls_CreateUIElementRoot_m17541BAE4AF1CE86FBAC92CF02933A4CDAB0FAD7,
	DefaultControls_CreateUIObject_mF356800BB8FDF5BF330B67B70FC4148D9D2FB47E,
	DefaultControls_SetDefaultTextValues_m79AA4B1F7A2061B259933C3F0CDBB12788BC3DFE,
	DefaultControls_SetDefaultColorTransitionValues_m7E4AA2E8B97EF5620C34FEE8D146FA35C054EB8F,
	DefaultControls_SetParentAndAlign_mC0E1D3DCB97427FF74488DFED23A51047E04E925,
	DefaultControls_SetLayerRecursively_m85578EB1E86A92ADE30289C7A9B8B937CD6933CA,
	DefaultControls_CreatePanel_m6CC4319B8D81426FC2A4E94CA836AB4F0ECA0205,
	DefaultControls_CreateButton_m73704B2DEB6F80CF622B31A7B14BBEC3A24737C2,
	DefaultControls_CreateText_mB0CA319F4BF0C8EC8773075885BD67D78A4582FE,
	DefaultControls_CreateImage_m5A948ACE15B86771B6F3EB7A8A74EBE938CEB3E6,
	DefaultControls_CreateRawImage_m3704C3F2E829FBCFEEDA34F27668000B1E6E5A02,
	DefaultControls_CreateSlider_m2AF0A50D2FF4EB21A68A5DBF92076C8DB6D50C5B,
	DefaultControls_CreateScrollbar_m876785B77922E7A0918137096FE9CEEC4BBCA1C6,
	DefaultControls_CreateToggle_m9F0611E37F71C5C077EB3D64D998A7117C830B7F,
	DefaultControls_CreateInputField_mDF85B76D7CDE06E5E49F537EA5FDD8192DA5E65A,
	DefaultControls_CreateDropdown_m00FF9DE1B54D5EA9B22EECC23EAB2D465538C0B2,
	DefaultControls_CreateScrollView_m18E2B79533E8C63917A90B112C7861D8777FAB89,
	DefaultControls__cctor_m7241DF8D34792725FB5E67F8FA801EAD9C45E2FE,
	Dropdown_get_template_m9C83BB0CFD2BA72F08ACC8B0FA9A274FAD0FC9C4,
	Dropdown_set_template_mB9D019C2D44DB5A936754540CA54AB20E948B395,
	Dropdown_get_captionText_m3E3FF20006F7EC8A8FD7ABBB7F9F723A0E3CD5FF,
	Dropdown_set_captionText_m6EB525A575E15A0A8FBBA3C5E1E04B2743B5CE97,
	Dropdown_get_captionImage_mB846CCDC2F81DEC05EFC9FA1E38505409B428253,
	Dropdown_set_captionImage_m49D7CB97D0524B43A8C47234FA092E0EE1A2A8E5,
	Dropdown_get_itemText_m1AEEFE1ACF751CD3483659F5E5B703239C28C7D5,
	Dropdown_set_itemText_m2D83A9DFB92CB75269DB174DD05560F416368240,
	Dropdown_get_itemImage_m3B115ACA023FC279CAE1757FD4AB0DF91242BA50,
	Dropdown_set_itemImage_m6C79EE0427BB5C381856CF054A460127906A2718,
	Dropdown_get_options_mF01AB08188E47DA9CD1488723FCBC453F29BDFA6,
	Dropdown_set_options_m89BE75A0A6378F91F04C2DFBCBF091DF8A59CB65,
	Dropdown_get_onValueChanged_m4EE82DC9AE8618C52CECA362EBDE6284F41E88FE,
	Dropdown_set_onValueChanged_m8AA65759FBF874CF3D12C19DA97229853FA7BD91,
	Dropdown_get_alphaFadeSpeed_mE18CF6C0434FA3570CF19C8D9687A714068A830E,
	Dropdown_set_alphaFadeSpeed_mC017C63451B6F976EA0B1E8189390B7C2CDEB5C5,
	Dropdown_get_value_m5FC2BBBD94BA37BFF81DDCE45F42E0782C44CFCD,
	Dropdown_set_value_m8899C656D4A14C8AD965B64EBAFDAA1EFC8C056A,
	Dropdown_SetValueWithoutNotify_m7099987027B026424BAD7D2B500E9D14A23ACB48,
	Dropdown_Set_m8C6D5C2E784DBA1A4F4AB73354DA8B2C1265386E,
	Dropdown__ctor_m8333CFE620788E03D2E44CAB4AADC60FFDD7D40D,
	Dropdown_Awake_m55BEE1E9BED97A6179251A5AAE9D1E734BBE4A98,
	Dropdown_Start_mA6A8B9D3F55B5E372C5A45C82DC632AB28136F11,
	Dropdown_OnDisable_m3957AFD9FF300E263AD7D406810014AB7EA07F51,
	Dropdown_RefreshShownValue_mA221C69078DAADC64EF227C7F66390A1D49E32F1,
	Dropdown_AddOptions_mF71FBCA3EBE345DB77666E64422AA2845979604B,
	Dropdown_AddOptions_m9DC5D88B6326E8D1427323778484653E29E86F8E,
	Dropdown_AddOptions_mE65624F3D156B27E80F4820012C85DBB109DD7C8,
	Dropdown_ClearOptions_mD85755513F827D82DF4A8EE04D2CEE91C4023EA0,
	Dropdown_SetupTemplate_m5CE6BC1866BDCDE6E94E367175F90E557F48E143,
	NULL,
	Dropdown_OnPointerClick_m4A7BCD99C3ADD0D5DFC3B94E0AF51110C73C5D5A,
	Dropdown_OnSubmit_m684758E3F3C8465F6580A17DB0A05C804BA3ACD3,
	Dropdown_OnCancel_mB5306D5E3BAAB6E9F3FBDE6487F02A06A6A0E568,
	Dropdown_Show_mD7E5E0A23BA93F7DDCF937D487FAA4A03B810592,
	Dropdown_CreateBlocker_m036190311A5551395BC6DD3807D909F851AC8075,
	Dropdown_DestroyBlocker_m5C4902C6F0A8F48BA82286ED70CFC60F7BA19961,
	Dropdown_CreateDropdownList_m4C38DE76864D27BBA2033CD5DD72A88B1D2896A9,
	Dropdown_DestroyDropdownList_mD11E6DE18CA6767744F725B6B1326DB7247E2FD8,
	Dropdown_CreateItem_m591B3B4546D13786893F9930BE702F3A9AAE3CDC,
	Dropdown_DestroyItem_mB71C1CAFF2E69C20B2FF8A9A82E8CA6BDBC5D829,
	Dropdown_AddItem_m5F858BC2C6F291D7E8E674A36F7036A1CA4BEAB2,
	Dropdown_AlphaFadeList_m0ECDEA6B54E8EC0ED2C4ACB016942122B6E9FB1E,
	Dropdown_AlphaFadeList_m2B80644908D3927EEB29497DBEA5BB5B8B239316,
	Dropdown_SetAlpha_mE46118E546C9444182554BD55A1352401AC8CC9A,
	Dropdown_Hide_m35382248CCB9AB3A863EC390BD50BEBEC2ACC1E4,
	Dropdown_DelayedDestroyDropdownList_mFDA7D3AEA4860DEF70F855A259A6A3F7637139CC,
	Dropdown_ImmediateDestroyDropdownList_m6B7217213F4E6CC4089712453892CBEA8725E3A4,
	Dropdown_OnSelectItem_m57F0626C9D1A326B4FA15BA4B2F20EF9D529D95B,
	Dropdown__cctor_m3B76BCC67847B1F4704C2A91FC7BBC1991630061,
	FontData_get_defaultFontData_m395A2BA13B11A53C4BD4E8F1B7D97E9E278D6063,
	FontData_get_font_m63A03245926CD05B461E00C281724370C8B7D0F4,
	FontData_set_font_mE19CF5265530AC3200BE65E20E8F909210ED71D0,
	FontData_get_fontSize_m4B7B4842DC663B866E006A4DF86EBC1C3BC095AF,
	FontData_set_fontSize_mFAB8C6A7548E75E958984BD5365348A131194B0F,
	FontData_get_fontStyle_m463803A5ED384064EC9B03549BA921BEAAC8A4A6,
	FontData_set_fontStyle_m25218403D504C2D0876E5AB25E813EEFAE85F93E,
	FontData_get_bestFit_m927FFB8A5BE4376FC966BC16E0431B443F00E691,
	FontData_set_bestFit_m0426EC53969FF4848061B4C37888D242BAD0E07A,
	FontData_get_minSize_m40C332F61CFB0F164EB84B35A05E2A10B801667B,
	FontData_set_minSize_mF884D9FD3B53247AB2C9EE9EEC15EA2CAEF04787,
	FontData_get_maxSize_mCFC5C0F12AF21C90D1D854B68A27043724911270,
	FontData_set_maxSize_mDD9FCD710B9E033877FC966E70A0DF83D79A334C,
	FontData_get_alignment_m2492DD0F8619041BD0426388DFFE2DA4634DF095,
	FontData_set_alignment_m69E5F6567789E0623536766BADD833481D8D95A5,
	FontData_get_alignByGeometry_m2283F19F108FF389FC586488AB28FFEC2A5422A7,
	FontData_set_alignByGeometry_m4A0066CFEAAE077592A22AAB95584B2ED416E139,
	FontData_get_richText_m42B50EC00F120906CE16259A13C5C37392B7E525,
	FontData_set_richText_m2A9142EB34518A1516B6DD0A02263B6AA4FAAA8A,
	FontData_get_horizontalOverflow_mD9704C9760A72DF3123CD12CF2C801424B43F9B8,
	FontData_set_horizontalOverflow_m36E9099214AECDBA10782F2AD0D53FB0C564A2BF,
	FontData_get_verticalOverflow_m42B923B1137DAEA0D1846C81B659284A5B93D2F0,
	FontData_set_verticalOverflow_m0CADC4D430AF3B97EC6AB67E307B33416F73ACA2,
	FontData_get_lineSpacing_m7E48A8B51A6E164736303C82428B1E09541BC259,
	FontData_set_lineSpacing_m4E5D389BD1B2AC5EE9819D016D348E9E86354418,
	FontData_UnityEngine_ISerializationCallbackReceiver_OnBeforeSerialize_mDC010D7E8B0760CE0609D448CB39CA0837A23CEE,
	FontData_UnityEngine_ISerializationCallbackReceiver_OnAfterDeserialize_m4963180F7FBB1126FAA1FDE6DAD964BF3EA6EC92,
	FontData__ctor_mD10DB1E862954A5B86378363336E6ED223EB167E,
	FontUpdateTracker_TrackText_mD4637B32DDF98DBC4EB12276CF3F1F123D2E8DE1,
	FontUpdateTracker_RebuildForFont_m50C112881473597E323D64BD8501BF2E2BCB7C42,
	FontUpdateTracker_UntrackText_m1AF4E3F1C4FB59FFB0CA434696983DFDD4B30C63,
	FontUpdateTracker__cctor_m574706565D0BB0A40976BDA6C673F1FC65E10361,
	Graphic_get_defaultGraphicMaterial_m4CE20290CB9C10C4761280434B5C0DD703FAF5E9,
	Graphic_get_color_m41096F123C41440AEBA4DFA9895C200D6A57E3BB,
	Graphic_set_color_mFCFCE816B75EA90B65322CC8336A7E9B87ABB1DD,
	Graphic_get_raycastTarget_mB1DAE6E1CC56FF60FDB89F13380EBA423D89C0AC,
	Graphic_set_raycastTarget_mF6ED840EE6143939BBD9D27A91E500F0088A9F0C,
	Graphic_get_useLegacyMeshGeneration_mA066E73CC94E4D2821CD3B75CCF6D1CDC9A16330,
	Graphic_set_useLegacyMeshGeneration_m1281A98F40D15A81E9F13E761A25971D26E22485,
	Graphic__ctor_mFF2C899E09B2A87349DE0CB30ED40E024F1BAC61,
	Graphic_SetAllDirty_mEE96FA6CE5AE7BE672D31FF5B9453520203920C7,
	Graphic_SetLayoutDirty_m718BE45BCBB1F1553737E4DC264C46574432318A,
	Graphic_SetVerticesDirty_m40D12C375CE57E385BB29A05AA545BA5D2756092,
	Graphic_SetMaterialDirty_mF3CFAA798081BB0DE5BEF580DB9AFF3D133BF87D,
	Graphic_OnRectTransformDimensionsChange_m791FEC0CE315489E5BAB77379905C60904CCEDF9,
	Graphic_OnBeforeTransformParentChanged_mD8CCD355B472AADD4FC1482A16AC2C24D7E430FF,
	Graphic_OnTransformParentChanged_m5F233BA713EE94492742F8BA870B6146DD9E98EE,
	Graphic_get_depth_m0F71549881BC2F4D4A64E1502747F33ADAC38061,
	Graphic_get_rectTransform_m025371162D3A3FCD6D4692B43D0BD80602D0AFC4,
	Graphic_get_canvas_mE278CED637619008522EF95A32071868DD6F028C,
	Graphic_CacheCanvas_m90ED23543C47D22791442F8A0B075BE96390BC8A,
	Graphic_get_canvasRenderer_mB3E532BE19116A3F0D6ADC1CD29D242428EAE8AA,
	Graphic_get_defaultMaterial_m0A1AF379749391DF306119369BC47E422B7E5AA8,
	Graphic_get_material_m009A329611244894C6F51FA7D72E7945074B1F66,
	Graphic_set_material_m20F9693B0716F3C6277FB5ECC4AF01992BB17508,
	Graphic_get_materialForRendering_m0FE5B8462BCE184C19D7C7991AB00733E499B168,
	Graphic_get_mainTexture_m8ADD95545D4FAB8D218C028196DCB9758C47B3E5,
	Graphic_OnEnable_m543DA5728144CAA130ADF9B8766E047A8CD222A2,
	Graphic_OnDisable_m2F04072EC06F71B669B0539C4D0351A3C6D5EBC9,
	Graphic_OnDestroy_mB0F9B2DF45C43FFE1C1E487E4D4AF219FB153E15,
	Graphic_OnCanvasHierarchyChanged_mEFE8337B5C2A02BA5391CDC62E16873A7A1B17A4,
	Graphic_OnCullingChanged_m1E3F10422AA9E264DC409F263962853FBEFD120A,
	Graphic_Rebuild_m43361D85EF8407D841CF93B7A3B9BA3FAD2999D0,
	Graphic_LayoutComplete_m59965D03F9D848264D99053CC756771EF2861FDC,
	Graphic_GraphicUpdateComplete_m3E3BB39CF9720E59C7CB2378942976A2355EC7B0,
	Graphic_UpdateMaterial_m16534E5799F16708458941FC6498B73F097A2EE0,
	Graphic_UpdateGeometry_mA96921531C4B1F1ECE14D3AEF696B6CE186A262E,
	Graphic_DoMeshGeneration_m78C460A0D1FB69DECE0453DAEEF647493A81B4DC,
	Graphic_DoLegacyMeshGeneration_m463048B9E5C90A49140769F5E9B698E056575D14,
	Graphic_get_workerMesh_m44288E0C1A3F7208C2F0C845C66D97CC243DA8F3,
	Graphic_OnFillVBO_m02BB5C8EBFECEDF310C8D64BF3631C1FAD3B1741,
	Graphic_OnPopulateMesh_m948CA3ACE51F62248FE46ED5A02860CF0F88F1B3,
	Graphic_OnPopulateMesh_mFEDD5EDAB64FF7F306FB1CBFDCA90C66C2AC3027,
	Graphic_OnDidApplyAnimationProperties_m9517A75CB3E3F34476E789D596D8876493DE63E0,
	Graphic_SetNativeSize_mEAC831D42859BDE3D7110393268DFDA5E3EB7FC8,
	Graphic_Raycast_m3FAF25FAD88AA922B0C0203EB93A29C317F6FA5D,
	Graphic_PixelAdjustPoint_m6A06D04F7D6B6D946407ECBD984AB2E9B2EF2DCF,
	Graphic_GetPixelAdjustedRect_m324344D38946D6F976CD487B493B8D9787DE891B,
	Graphic_CrossFadeColor_mA523A0BBF67D56A68EBF66D11ED9E4A4656E8E6A,
	Graphic_CrossFadeColor_mAF4F98CBBFE98F68194F613CA81D96D70BEE2130,
	Graphic_CreateColorFromAlpha_mE614B0D96600F8AD82ABF5E7E223FC567D5A64CF,
	Graphic_CrossFadeAlpha_m840C0BA8E42721135A79AEB4CDCE57E820A157F8,
	Graphic_RegisterDirtyLayoutCallback_m11140B9203E6D66297136F496425CD8D9DDAC35A,
	Graphic_UnregisterDirtyLayoutCallback_m4BF876332C14A07BB5ADFB8466153B2F7333AC71,
	Graphic_RegisterDirtyVerticesCallback_m8727CA44030990DDC04C7D0B15E42EE855D6E04A,
	Graphic_UnregisterDirtyVerticesCallback_mD988A2D705D5BC5CF07D48FA6ACEDD62B0C6D806,
	Graphic_RegisterDirtyMaterialCallback_mFA087FA23F3FD8EBDC56B9F43B677D0D22E5A10D,
	Graphic_UnregisterDirtyMaterialCallback_mB3C2D969D23C29E3CF1E3F26A7A0DE43B5402CFB,
	Graphic__cctor_mBCF4F5AE23900A0133EA8C4F3ADC3B44DD518478,
	Graphic_UnityEngine_UI_ICanvasElement_get_transform_mCCB04E0F0F285EA97EDF6D033919593677F6A0DD,
	GraphicRaycaster_get_sortOrderPriority_m709D3A9421D94A92300FF2CB8BE1FC105CE36C27,
	GraphicRaycaster_get_renderOrderPriority_m12D14281F1C24C62430F0197209048C88C788833,
	GraphicRaycaster_get_ignoreReversedGraphics_mA651ACD4D10ABF6814CA86388CFBAB53E08752C1,
	GraphicRaycaster_set_ignoreReversedGraphics_m30ED60312A83BAF135DB8698A66A282B86E7714C,
	GraphicRaycaster_get_blockingObjects_m65760F738BEBB63000DD47E0E5E1FF8BA0AE49AF,
	GraphicRaycaster_set_blockingObjects_mA8A05772456F3C6D111D13F3F928B36515D76669,
	GraphicRaycaster__ctor_mEF612B2FC80F5DB5AE8EEA04173D4E16CA17FF7B,
	GraphicRaycaster_get_canvas_m74BF579BA6B90DA2BB40CC35A4593891751D5CCA,
	GraphicRaycaster_Raycast_m84D9E6E7312B2D18DF42C1C32F8D286C478981B6,
	GraphicRaycaster_get_eventCamera_m9A3A721CBF84A96629E4BC1733BBB6A45FF9059D,
	GraphicRaycaster_Raycast_mB609C88B0463F4D9AEDF92A22699A2F0442C6903,
	GraphicRaycaster__cctor_m70E9DDE730788223448287D773BBA2A0CC65CD64,
	GraphicRegistry__ctor_m1D7A55FF980852A6DF114132EAA37534B8E97BF2,
	GraphicRegistry_get_instance_mC44355C0B339CE448FE227149CEE9E1469DEA198,
	GraphicRegistry_RegisterGraphicForCanvas_mD3BF9B48740240B443D67BB16938AEFF50FD3D70,
	GraphicRegistry_UnregisterGraphicForCanvas_m4123DD7960466B17764D322CA564DDB05F1A1005,
	GraphicRegistry_GetGraphicsForCanvas_m3F2DD225EAE745C24BD9505AB5B0BA662C1FC72D,
	GraphicRegistry__cctor_m8BBF04829878A32D2DC3B4E4488455728A531F6D,
	NULL,
	NULL,
	NULL,
	NULL,
	Image_get_sprite_m642D753672A8CBCEB67950914B44EF34C62DD137,
	Image_set_sprite_m0D1DBEFD8E361B3967964C71F93EF47E2AC53A13,
	Image_DisableSpriteOptimizations_mB0B9EF7868EF02231A2627B8A3C752ABECC4FFBC,
	Image_get_overrideSprite_mE32E3D384CA6220B81702E9E3051FF83C4232FF0,
	Image_set_overrideSprite_m3801998A40D32BC10393531714384D736D9F604B,
	Image_get_activeSprite_mF8F075992BC21B86E47F76D5F8018524DA045A88,
	Image_get_type_mBF4695569A2C6FEBCDE60AB80A386F39D5708D6A,
	Image_set_type_mCA2BF9E071A77EE7D76C7EB343BE5ABEF9E7A199,
	Image_get_preserveAspect_mF5FDA8E207A0EA3BA3614D891DA58FB42D8F0665,
	Image_set_preserveAspect_m69E602AC28CAD513726DF209DBAB355C85F6AB51,
	Image_get_fillCenter_mC1C3D94313AEB5CDDA8AFBA05E5064614776F6A5,
	Image_set_fillCenter_m0A53CDA22B0CD9DC793B61BE2AAA8FDD77817777,
	Image_get_fillMethod_m0F319641FE800193CB9FC939F4A4767D230D23F3,
	Image_set_fillMethod_mA33A12A016BAF78C4FA65DE06591E81A139BFAEE,
	Image_get_fillAmount_m52716D803065CDAFBCF2CE226868D71A58DE4792,
	Image_set_fillAmount_m3939CACF382B30A0353F300E2AE2D3823E1D42F4,
	Image_get_fillClockwise_m95EDEEA7817F4E6AAD688DD73F2CBDD42EC3AE67,
	Image_set_fillClockwise_mFECFB87C66A74A11BC65A67F5E461E3ECA89D228,
	Image_get_fillOrigin_mD984C37AA02B39C490E94C80FC3AEC1329F2E581,
	Image_set_fillOrigin_m998854DF1C46B945BF46B836C1B57EBD81670D37,
	Image_get_eventAlphaThreshold_mF7B2B10F6BED44967456285F6E948C7446E6F0CB,
	Image_set_eventAlphaThreshold_mC199B8715309D0696A43D46337D8FE21B7417AC2,
	Image_get_alphaHitTestMinimumThreshold_m46A783B6DCE2275998D39EDD95D6330AB577E153,
	Image_set_alphaHitTestMinimumThreshold_m896CA8778D60EC6265F0B0A8F638D807E6A6E629,
	Image_get_useSpriteMesh_mFDD492A5BCA3BC432A2C6B376A136A8F13EDD392,
	Image_set_useSpriteMesh_m4AD6400C198048A34495BF659E05D2534884316B,
	Image__ctor_m89E0D103F4CA0BBBC035607123F6E7C329204765,
	Image_get_defaultETC1GraphicMaterial_m471CA72CC6141A7F71D521C366E04D728F0F66A0,
	Image_get_mainTexture_mB257690C040998ECFC1BE091374B54B181823D27,
	Image_get_hasBorder_m7C05F990262DFB3E3FA9930DD0C9ADE1A9ADD55A,
	Image_get_pixelsPerUnitMultiplier_mEC77742FC868A9AF8D97062C2AF22CC67301A161,
	Image_set_pixelsPerUnitMultiplier_mA5DDCE0047AF70E5B05C12B85A97C892E917AA4A,
	Image_get_pixelsPerUnit_mFEB9AE2275AA3C78B1B378E1D5BB3DAA3FEA468F,
	Image_get_multipliedPixelsPerUnit_m461D324E57EA6D27E040D604CC5E4B7E8C1BD6F6,
	Image_get_material_m75690B58C80538290BEECC5E1D145FB19158ACCA,
	Image_set_material_m77700AC8865555E51919FD83103AE7031EB2A099,
	Image_OnBeforeSerialize_m785C27A8280F9811921AD8562456E04704A31685,
	Image_OnAfterDeserialize_m97D51356CC8BB6709D54132B514D111382A03256,
	Image_PreserveSpriteAspectRatio_m867C0743E6073345231FC0CD83DB3D63EAE28E4B,
	Image_GetDrawingDimensions_mCE6C336D88D6E49D8052F79B9126D0FB6AF4452C,
	Image_SetNativeSize_mBDA1525980ABBB4BB36C0A24E507D099CEFD86D8,
	Image_OnPopulateMesh_m104866C152A6FC9048284507F0EAD18E15884A0A,
	Image_TrackSprite_mB3639B263ED7B7E321ED6C2B92D080E8AF5291AA,
	Image_OnEnable_m9D7FE5D1A92A2297C23B9C2F64BD1A149E04BA0A,
	Image_OnDisable_m1C3110B08DE03A4B36B98C542F3791ABBFB4ADA4,
	Image_UpdateMaterial_mC3DCDCF173BCDDB05C20AFB60E06782B6A8768DE,
	Image_OnCanvasHierarchyChanged_m83917F8982210F0AB2891662F97E516C818295BE,
	Image_GenerateSimpleSprite_m46170848CF38F077E68B011D15EB12F52B92B949,
	Image_GenerateSprite_m033E01EDC91DE1DED74202F91E6F91A408955DDE,
	Image_GenerateSlicedSprite_mBF002A4287C80541C8C806C74BA171DB8DFBAB8F,
	Image_GenerateTiledSprite_mEA5DDDFA3314A70F65EC73CC79D3011AF2EC9E63,
	Image_AddQuad_mB70FE4783CDC72A84E64FEF905B0F7AC9E910AE8,
	Image_AddQuad_m0A71218655EC3BA6C226556D470881A9CE46906F,
	Image_GetAdjustedBorders_mCF8A75527B652B1EE38AA901633CB4ECAD52AB89,
	Image_GenerateFilledSprite_m01DFCEE99311E089187D34053A2374FF8002EBAA,
	Image_RadialCut_m4E9900BA6EE4A9AA9B354697D77B2A662AEC23DF,
	Image_RadialCut_m9CCD0D83BADBD2AC4EF60952F4294E98FADAB8B2,
	Image_CalculateLayoutInputHorizontal_m5232B7280E0A7DEE3BAF27C59053D65BE15BE0D2,
	Image_CalculateLayoutInputVertical_m5158697A0915E9F3DCD7136565652B9357090B2D,
	Image_get_minWidth_m626AD4C77AE11E5286F0B99EB54F3F0421472148,
	Image_get_preferredWidth_m26A0CCAD8AF401F83A2BC3343F70E5380F237FFD,
	Image_get_flexibleWidth_m65BC8846340179C353CF4D5ACFC33CEF96B8BF9B,
	Image_get_minHeight_mF744D962891D563EEAA83C556A7F03E06C0F63F4,
	Image_get_preferredHeight_mE395F5CA183EE208F1A78C5BE5E84553B15A8E40,
	Image_get_flexibleHeight_mFB51C992984741CDDC901DF8726B894E65BAE42C,
	Image_get_layoutPriority_m93D32FC9B5713E5CB880807D122565D22B620C6E,
	Image_IsRaycastLocationValid_m739ADDA1CDEF37EB21CDA648DDE30F87D39B235E,
	Image_MapCoordinate_m90184DC8DE94E172E71287F95A400EE4C5EF464C,
	Image_RebuildImage_m1A747F9521237EBC256F0B3831921844A57EB7C9,
	Image_TrackImage_m09253EA16561EB5DAA848F9E2F96FEC71300E85B,
	Image_UnTrackImage_m0C8785427EE52C01A62F7DCBCAF8BC175423E21B,
	Image_OnDidApplyAnimationProperties_m1CF377F062B5C36D1E4EEB18B7BE7D42F9653A15,
	Image__cctor_m4FB493FF96D111013AA8B8C1F0A61C7FC4BE3328,
	InputField_get_input_mAF4210F766099F23FA8695F12CA970CC8E5CA80A,
	InputField_get_compositionString_m158BE146634913936807DB36538433F4B6F9E9E1,
	InputField__ctor_m6FD452F23C09815941270A1145A3635720F74A81,
	InputField_get_mesh_m6546FECF63F4A23B1A3C8B58B0BFE294106BAE7A,
	InputField_get_cachedInputTextGenerator_m6E2FFA43D0AE993D930B4763184F248AE1915CA0,
	InputField_set_shouldHideMobileInput_m0F1A7AB81C87ACEA5DD944C31B5FFFA17FBC0566,
	InputField_get_shouldHideMobileInput_m4C519527445BF0BC3528E28ECC92353020569638,
	InputField_set_shouldActivateOnSelect_mD3E4349843483230B1F2308A4B47402B36E8B489,
	InputField_get_shouldActivateOnSelect_m38CD67B376D9EE55E1448709C55FA6A915D55889,
	InputField_get_text_mBF8B0DCF4E3CDBB06DA69715A7DD8F9E56775E79,
	InputField_set_text_m281F692E6AC99F9AE94EFE140B8AB2AAB5C4ED19,
	InputField_SetTextWithoutNotify_m383B2699A0A42D182441DB8B028129A901343C0E,
	InputField_SetText_mEF14F85B3A852C7BB42625B5982DB4BFEBAF313F,
	InputField_get_isFocused_m25CA31CA6CECDC64B52BB3AACC1B6A8A93A616A2,
	InputField_get_caretBlinkRate_m56A493EBF4A015AC2CEDA650720ADB4FF2521511,
	InputField_set_caretBlinkRate_m4EDB44D8AEDA727A25FA6CC1C3DA45BB45A41933,
	InputField_get_caretWidth_m9D8E7C39BD3DF4F8BAB672500537A3BE99C3A6CC,
	InputField_set_caretWidth_mF61CCF7F182E6DF6FA6F0353AE4EF3698A82AF97,
	InputField_get_textComponent_mC1FC063C41D84947A3B0BE349C6E937EDF0EB19E,
	InputField_set_textComponent_m11FA15B17BA3DB27324CE4040E063B7DAC091B07,
	InputField_get_placeholder_mBDB090222F665AE8A1C96F1F375732346F177EEB,
	InputField_set_placeholder_m0865B4D3D4ECD6FD461DAB885EB092EEB21A4043,
	InputField_get_caretColor_m9CC9FE92EE010A1F980A2838A41B4C081D2FDA3A,
	InputField_set_caretColor_m148EFE3197FB549ED9590E79857FA59A1745EDAC,
	InputField_get_customCaretColor_mA8F05610E0ED2EF183F5D3BFA85C2C6A5C18AC06,
	InputField_set_customCaretColor_m464BB3B1F60BE5921F4A7F332F56CC2B67BFBA39,
	InputField_get_selectionColor_mA49DCB951B526D232C0E090783433304261D4D1C,
	InputField_set_selectionColor_m518AC54CA807B49168B241A9C5AA631DECA66BEF,
	InputField_get_onEndEdit_m912D9CA48D579EE1A68544EA58EF5EEB633148C1,
	InputField_set_onEndEdit_m9319A04D9507BF95F126FBDC944EFBFD25437817,
	InputField_get_onValueChange_mC6364A9208DD2811E7DFF5F0A1225246A278BCD7,
	InputField_set_onValueChange_m16DDA125D55D52930BEC5C48B510EA1DCB06D99A,
	InputField_get_onValueChanged_m1AE46D57FF8D96F53F2039722DE9CDDB6AB58CA1,
	InputField_set_onValueChanged_mCB16702D95434534F0E94F7FD7C6CB50A2CF1AAC,
	InputField_get_onValidateInput_mCF04910E2F6920903CD095B86C1D61DA4C01B553,
	InputField_set_onValidateInput_m5BEE0E501A9B7473CF12CDE4EFB3DB07D021E293,
	InputField_get_characterLimit_mCAD464954BEA8FFE1F325EB07145F0C0F685F327,
	InputField_set_characterLimit_mF4B5E0B2BFC530654453C0341CCDD708FEFC935C,
	InputField_get_contentType_mBDEC121EFB7451BE3F56D8A2F68BF78FC28D2329,
	InputField_set_contentType_mC4E201D9E627B8031D56F9161E3A3183240BA974,
	InputField_get_lineType_mAFC713A8DC2FABB2FFC6902A767DAE2932A5BDBE,
	InputField_set_lineType_m72D4588776FB00EE7A3CD409A9476A3DA335F69A,
	InputField_get_inputType_m1B9C2C98A32BBD27759C950DC4C65F0FD69329CF,
	InputField_set_inputType_mB0E1EA230120261855A43AAB7677D7104B0C7FCD,
	InputField_get_touchScreenKeyboard_m6C45EACFFF50802976ADF0025CEAE8741153CB1E,
	InputField_get_keyboardType_m9837579BEE93CA6EEA8314AF9CE3074F39D8E661,
	InputField_set_keyboardType_m632644F9C8BA3E86134E9B438308F36706C4E13D,
	InputField_get_characterValidation_m3BA91CE0FC3845B40E1D43D6F0E36C5DB1D3EC29,
	InputField_set_characterValidation_m3190D57473E86E5303B7CDC4066156A35E5E4EB7,
	InputField_get_readOnly_m270D135DF046240056F82A8B5FB33B88A1C75410,
	InputField_set_readOnly_m6C0CB487175DCD5A6D1FEFB0095FCE6AE81EF4A1,
	InputField_get_multiLine_mBAA67A994CDFF54DDD2626911E1925EB696651F3,
	InputField_get_asteriskChar_m121033347B2DEE7DDB48DB9BA0A8E0CDD4C063CB,
	InputField_set_asteriskChar_mB506CCAFF03BC60DF6D977F6CFF4A8C49F36E643,
	InputField_get_wasCanceled_m6BECF3C88C145F3E41A52F1D71DB73829C79F5DA,
	InputField_ClampPos_mA5284D511E01A281F0496B2E5501807E89095122,
	InputField_get_caretPositionInternal_m1C8C179A08702D0100763BCBABCBD6C8657CF48C,
	InputField_set_caretPositionInternal_mF3AB830A2E57BD6C42D9F929A0022A08A19C2CBC,
	InputField_get_caretSelectPositionInternal_m6C1C9309C63A54F0758E9E98874F506A000E836D,
	InputField_set_caretSelectPositionInternal_mBA32741EB669F0A2442CD4D08769BC6A76B14A9C,
	InputField_get_hasSelection_mDD4B79D003B25F135FCE39C1C616B931B376D512,
	InputField_get_caretPosition_m1C29C23140389DEC7F6F1E219CE0F05664F26F45,
	InputField_set_caretPosition_m9FA50128D39216F22600FAED4E524E2C11EA762C,
	InputField_get_selectionAnchorPosition_mDCDBF5541AF2070013C2AAC9C8EE9F71D7F646EA,
	InputField_set_selectionAnchorPosition_m4254083520C451CC3B47F4A378AB42E30EB35D44,
	InputField_get_selectionFocusPosition_m4DA6EE88607CA347897FC618404C516BBBF26F8F,
	InputField_set_selectionFocusPosition_mB10332F1C25A0FBF55E5117311EA222341DA4226,
	InputField_OnEnable_m20C81684DD86C8AC2C9DFC484EED542348643953,
	InputField_OnDisable_m03FD432603A7B8BAEB1517C1CEF9463AC813B894,
	InputField_CaretBlink_m1A5A634C9913890C778AAA97AEBDD94FB4AE2AD2,
	InputField_SetCaretVisible_m5E833C2E576C37507EED1BB8E7277DBA7AC63F08,
	InputField_SetCaretActive_mB7D0B50A4C7EFEF79C1E42F2C4BFB151E004A2B4,
	InputField_UpdateCaretMaterial_mC952730C34A97B699C4ADF000D036DF093BC99B7,
	InputField_OnFocus_mE5526144A4E6817D74779CD9D127CCDBD3980CCE,
	InputField_SelectAll_mC99C9736C43FE76D6BDECB08EF051C764F57420B,
	InputField_MoveTextEnd_m8291A816FFD832C118C34F4220D6FE636EC6E4BB,
	InputField_MoveTextStart_m35289A28C51F5013159FB1EA1C51E9A0899BAC13,
	InputField_get_clipboard_m87ED8C088B1944A9650DBD85EC22D11433AD6899,
	InputField_set_clipboard_mA6EC02047ED47823A27FB7E87118B9543C8A168D,
	InputField_InPlaceEditing_m5F17CD27EB3078E57421F200A539B78F9FD1682D,
	InputField_UpdateCaretFromKeyboard_mA211259D2D0C449945399D833B7EDD7ED74339B3,
	InputField_LateUpdate_mE13037D8AAE74792EE4778656814D109024952B9,
	InputField_ScreenToLocal_m4B659514B174BA0738ECB4D1D6BE5DCB9A75665D,
	InputField_GetUnclampedCharacterLineFromPosition_mA6F6A42ABE7639B298B52F042C665680353D279F,
	InputField_GetCharacterIndexFromPosition_m5388B3DCABB00D1EA4CE6552FC968A33EC767DD6,
	InputField_MayDrag_m946895179CA97D3AC931726D8D8A5569A1A65E59,
	InputField_OnBeginDrag_m8776FCBE8ECD5C40E82A095677EB8C6CEE9FEA21,
	InputField_OnDrag_m61EA2B1E813F8500D8F6E35025FEF7F1A0654794,
	InputField_MouseDragOutsideRect_mBC8D652300D6171DD11D57C5F5059B16484731C6,
	InputField_OnEndDrag_mCADE3829E0CA9518C9638A46D5261B3DEF55E012,
	InputField_OnPointerDown_m5CD7B9F95A3465DDB6454CF1F2AF46896A4CF932,
	InputField_KeyPressed_mEA9D60091DBDFCC1F62B626C119A1618DB2395E4,
	InputField_IsValidChar_m3C26A8B27DAAE0A59BC7210B36212D46DB8B1E86,
	InputField_ProcessEvent_mAD3C565CB7849EAFFB71855FD6382BCECF239877,
	InputField_OnUpdateSelected_m98054B214C32ED83ADB3A2FDDE381A21DC11A046,
	InputField_GetSelectedString_m761F3DEC2B8D9B76EDC69DD671107CF7A4E56A0A,
	InputField_FindtNextWordBegin_m419767AB6316824DFE43453E667E6D4A9A348414,
	InputField_MoveRight_m4C134741EB97B5EC89420A1A1DE71AF7F7E39361,
	InputField_FindtPrevWordBegin_m98550E481175C04EDBBD08052E3F858FBE2144FE,
	InputField_MoveLeft_mCE95C5E9D07A7B8B4A5E678542B0B593D20A776C,
	InputField_DetermineCharacterLine_m925C5167CBCD2F83CC65948F091962215AEC64E1,
	InputField_LineUpCharacterPosition_m71B047A08236E2A951664B72CF9C274D901731B1,
	InputField_LineDownCharacterPosition_m6882D259B230FD4959193870B577126128F14FAC,
	InputField_MoveDown_m97C7C3ED2A7A82A40ADAD9E3C8189D07AF7757DD,
	InputField_MoveDown_m9BF66331524D87F6A52B31B24DD158F866898D7E,
	InputField_MoveUp_m195799658320F3FCB0A5FD477946BE00478D2BA4,
	InputField_MoveUp_m34EB65513DEA6C65A078E574C6D6E339D94AE2AE,
	InputField_Delete_m75479E87AD701376D0518A18BC7E4843C1FE8CC6,
	InputField_ForwardSpace_mB8BA4AC3665D63B5F2A8B55F561924E05DAB2A5E,
	InputField_Backspace_m680DD4C0F0A0909FC175FE0CCBAF2432ED5DE024,
	InputField_Insert_m27461897DD817CB4BDE4C53B2758B6DF24EAAE9C,
	InputField_UpdateTouchKeyboardFromEditChanges_m4CD005532CF761D05B43E41F42A9E2006C9D7942,
	InputField_SendOnValueChangedAndUpdateLabel_m0BDE3809282CC75454CBFC4FC3F132F2DAEC1328,
	InputField_SendOnValueChanged_m109BDF2F31D21428277833B6717D301B5913CDE8,
	InputField_SendOnSubmit_mD7791DDE32989BCA9889CE8DE7A83BBA5AA33509,
	InputField_Append_m9DB5994BC31CC8F86FC49603267FB1F66671AB63,
	InputField_Append_mAEDAFB21A110A4A5AC9408411F9AF7C6FE95B16C,
	InputField_UpdateLabel_m56AF0E325FFD43B6039469CF9F64942777AF07D7,
	InputField_IsSelectionVisible_mDDCB4FB02B253679E8A26BB30618B2BE0C8EF257,
	InputField_GetLineStartPosition_mB1B1189372CEE93568E9257709D37B7D41C745AC,
	InputField_GetLineEndPosition_m3FE92795F71AF46C930B7D155FAF4CEFC08B908E,
	InputField_SetDrawRangeToContainCaretPosition_m6D0F9575DFFB0706ACDF50DB01FB208D524D94B8,
	InputField_ForceLabelUpdate_m9078340CFD94260B81F17C288DAD373A668C51A5,
	InputField_MarkGeometryAsDirty_mA5216287BEAAC4D0014DE2DFCD0000AD16C6BA46,
	InputField_Rebuild_mA488543E825A8EC8A360A540D9FB01764AD3629D,
	InputField_LayoutComplete_mA3E0738AAC694417AF9FB264155DA14336E38FF4,
	InputField_GraphicUpdateComplete_m81F61868C3F59CFF7469CF32EE814B8828381FAC,
	InputField_UpdateGeometry_m1C7358E21A1DED9E9BC04C481DF8FC91F91F478F,
	InputField_AssignPositioningIfNeeded_m8496688DC031C0F84BB4E54DBA151E5F2E222C63,
	InputField_OnFillVBO_mBC5777473FE0CB1136EB3FBDD9A8304B15806DF2,
	InputField_GenerateCaret_m1E7FF81EE5A455B29E43D569CEB9AECA895A4245,
	InputField_CreateCursorVerts_m2A026BA8A75C2D185E031A34628042A7657D773B,
	InputField_GenerateHighlight_m7186EE9860C6681E464D08CF7E468213159F9D11,
	InputField_Validate_m826B947E2A4B23D6CB485CE11706451BA9121B62,
	InputField_ActivateInputField_m66BDD1901AC8340AB4E8CD05A57F078E0DC8A25F,
	InputField_ActivateInputFieldInternal_mE34A1852894F77959A6C9456E6DDB875E79DF43F,
	InputField_OnSelect_m2A617E01070E5CF91C03FB5767809A1D70F99BB8,
	InputField_OnPointerClick_m24CF01ECCA8827C3BE3F457AC04749862EF3DF68,
	InputField_DeactivateInputField_mF737763D44515FFDD2CB8996C217E309A7C093C1,
	InputField_OnDeselect_m82BDA40E2189550304326F34731DD3ECEB6AFBF9,
	InputField_OnSubmit_m785E6CDC0214663CF6F98AC9A510207C94C66C75,
	InputField_EnforceContentType_m10FEFA2EDDFAAFC991DB65015F1F568681773DAB,
	InputField_EnforceTextHOverflow_m379D84AC252CC5B0F97C0AD18C0211262BD46844,
	InputField_SetToCustomIfContentTypeIsNot_mCD19F5C6652848C0C69747D41E27ED45C049A68E,
	InputField_SetToCustom_m910908310AD2FA95A55DF409518D6F850101AE03,
	InputField_DoStateTransition_m731CAF975B9C0EC4F8F532F44D13682829F1D58F,
	InputField_CalculateLayoutInputHorizontal_m2C1B72BC5ABDEF5591BB2FDC052DBCE5E2B65B2F,
	InputField_CalculateLayoutInputVertical_mDB5730E842441D564B167213E30273B7A68676DE,
	InputField_get_minWidth_m6E032035AE2A92CA1598C3D2A2F2810F99F2D861,
	InputField_get_preferredWidth_m32D60DB236E3746DC4B4EF7AF959BE38644BDA2D,
	InputField_get_flexibleWidth_m5B43EC657BBE243E692C4F1220BB70D8A607D453,
	InputField_get_minHeight_m2E81E7A196378F1A26F5E5F2B135BB5A6DD27F7F,
	InputField_get_preferredHeight_m12F9C42567B57A7D9CE0006304D5BC89A798ED4F,
	InputField_get_flexibleHeight_m193CFE65714A149E47A1F440CA75A12E06A8904D,
	InputField_get_layoutPriority_m6CA2ACA9A3A94A6D181E7C3139ACC794A7DC2A40,
	InputField__cctor_m5C49905D88F7708D78B17A5F9FAF0AE5FDD1A85C,
	InputField_UnityEngine_UI_ICanvasElement_get_transform_mA04C52C3E8831E49F2D5ED03E7A1B532E83D0C28,
	AspectRatioFitter_get_aspectMode_m9DC7F64E9AB97AAB413EEF9931EDEDF90ACE0B75,
	AspectRatioFitter_set_aspectMode_m2B9DECD0227F9EA110263C1DD914ACA721BA9FFD,
	AspectRatioFitter_get_aspectRatio_m7141303427F7C4B091B584E7D4ED93B54A91BA24,
	AspectRatioFitter_set_aspectRatio_mA2730A84D3DBECC5BD1F4312AA9AEBE0E70C09EA,
	AspectRatioFitter_get_rectTransform_m10762C918EB094ED7335B938446F6537EF9E7F26,
	AspectRatioFitter__ctor_mE02BE235DC018758BFE700706FBB402DC33BDFD1,
	AspectRatioFitter_OnEnable_m2B6B9713030B8DBFCD9EFF71CEEA31909C030BAE,
	AspectRatioFitter_OnDisable_mE231BEC53154F2BA0DD9DB6955DAF9D14460EB2C,
	AspectRatioFitter_Update_m191D2D397A1A1768C15DFD06B2F0E78053754FEC,
	AspectRatioFitter_OnRectTransformDimensionsChange_m74DBDBE13646F660E7A0DE64DE8F30771209D269,
	AspectRatioFitter_UpdateRect_mF6BB81E2FBD1F500FA9B6F9412B03AA7ECC1C3F8,
	AspectRatioFitter_GetSizeDeltaToProduceSize_mC140746FFF3304905CFDA0D7BB6F44805802F018,
	AspectRatioFitter_GetParentSize_m5AA652B731F6930CA9C9B342C93354D73EFB6874,
	AspectRatioFitter_SetLayoutHorizontal_mF7D446EBAC74206ED48D7A0351D4E713A9CEA956,
	AspectRatioFitter_SetLayoutVertical_m7C15BC603D635DFE7E55724F2BA88D8DDF5C1FE3,
	AspectRatioFitter_SetDirty_mA44FF8D66147B28F0F8885F0CB2FD63A610E45F8,
	CanvasScaler_get_uiScaleMode_m8D75124B20A8598DFEF27665EBE9C5925CB25301,
	CanvasScaler_set_uiScaleMode_m478E9BFA69FD3316071D3D7ED2FE39E7178B2457,
	CanvasScaler_get_referencePixelsPerUnit_m8BBFDC7B5F8FBD64EDCE87496628A80F2A0D11F2,
	CanvasScaler_set_referencePixelsPerUnit_m4B93F51599E7546F20E3B6493B3EF64486C00EFE,
	CanvasScaler_get_scaleFactor_m5314751BC9829C63CA49617A045A0D1F878C7369,
	CanvasScaler_set_scaleFactor_m5F0946A8D73C20E1D337ED96E16687CD9E03F64E,
	CanvasScaler_get_referenceResolution_m8CB18ECD76532AD9FAFA92D9D395AB1070730A8C,
	CanvasScaler_set_referenceResolution_mF84A06A5910501D88862F2A3E60C4D1C7F2366F9,
	CanvasScaler_get_screenMatchMode_mD1444EF5D606499AE030E88AEACD0D4319C394F2,
	CanvasScaler_set_screenMatchMode_m250FDED7E3FC15A299F5C4F2F54331938A25C56B,
	CanvasScaler_get_matchWidthOrHeight_mD8FE572E1C181C79825EDBF2784D0ABC52E35335,
	CanvasScaler_set_matchWidthOrHeight_m3D4313C8B356B3B2FDF55338A0738554148C2496,
	CanvasScaler_get_physicalUnit_m2F6DD4DFDDA3DE8652A5F295C1E66060D0D8E94A,
	CanvasScaler_set_physicalUnit_mEA258DCB98BCD821B005A9B692B60AF26E89AE75,
	CanvasScaler_get_fallbackScreenDPI_m1AD8E450A8FC166D4ABD1B4DF60F0B3CF40CA098,
	CanvasScaler_set_fallbackScreenDPI_m8F5F430869974863F420751733DD54DDA65F1849,
	CanvasScaler_get_defaultSpriteDPI_mE6F4BC67BC414A04C503B416BB9E570E2FE2D233,
	CanvasScaler_set_defaultSpriteDPI_mB5AA7CA6E85A7D5D37C0B585B73F37D05FBBE1B7,
	CanvasScaler_get_dynamicPixelsPerUnit_m1D3563AB8AA6D1DDD6E555FDA4D95DFCF1561F37,
	CanvasScaler_set_dynamicPixelsPerUnit_m246DCF7C13AF23ACBBDBD961225A80DD9EA8AA5B,
	CanvasScaler__ctor_m81B7F75FE4D0083EF90495C1FFD56272F6F5B7F4,
	CanvasScaler_OnEnable_m13AC455B337B234EE4175EF573ED8605803493D6,
	CanvasScaler_Canvas_preWillRenderCanvases_m17D245138E87A90ECDD52F83DF76C2A38C23FCC4,
	CanvasScaler_OnDisable_m280A05C8B1C3CE112D66C56C4594BC14289B6BE5,
	CanvasScaler_Handle_mF38FFB050D9EF070AEA7B02DA20BCC4A0B8CC1C3,
	CanvasScaler_HandleWorldCanvas_m4046A6BA99D747151C37AB62ADB1D96B76882C42,
	CanvasScaler_HandleConstantPixelSize_m1850F67FA454035DF75C523220FA06DC490AE90E,
	CanvasScaler_HandleScaleWithScreenSize_mE0E51C003AC9FAAA848D20B0C150BE48A616CE66,
	CanvasScaler_HandleConstantPhysicalSize_m1518C4BAB0337C6C892B97AA4E02877A795453D2,
	CanvasScaler_SetScaleFactor_m7713446FB3925CF413DA9CAD0F41B6BA1664EBAC,
	CanvasScaler_SetReferencePixelsPerUnit_m701D2207CF834585C87E53C88E1D10EACAADB9C9,
	ContentSizeFitter_get_horizontalFit_mB775F652AC10946108F7D44BB52C57413086F524,
	ContentSizeFitter_set_horizontalFit_mA1745A5D95BC8E08C7433D60F7C74501EEC7D232,
	ContentSizeFitter_get_verticalFit_m937F784A1D950E72A561B7DF96206ADA5F1FC490,
	ContentSizeFitter_set_verticalFit_m57AFB7FD63A75442295C14BA58417B2110FE836A,
	ContentSizeFitter_get_rectTransform_mE7FD5F977E954B6D54B9C1CCD112A4A70840CF56,
	ContentSizeFitter__ctor_m2E5245D54587CA87E6AEE5AB7FA33AB33461D4BF,
	ContentSizeFitter_OnEnable_mBB226A80395594658A4E93F5CEBDA702B2581D74,
	ContentSizeFitter_OnDisable_m500C638EBFCDA4B7B10A93A4106B49DBADCB9619,
	ContentSizeFitter_OnRectTransformDimensionsChange_m299D481E8654CF7608B48204E48678C84DF7DB1A,
	ContentSizeFitter_HandleSelfFittingAlongAxis_m725678942EB77B09B4FCD47347DF54FD7079AFF8,
	ContentSizeFitter_SetLayoutHorizontal_m966F300CAB4A67ED9FCE5C8133F091BEAA53F435,
	ContentSizeFitter_SetLayoutVertical_m8B76F70D92D2D74ACBB85D35028B1949205FEA63,
	ContentSizeFitter_SetDirty_m4830A85DEBF04D4D2523563C5E5ECE3712225080,
	GridLayoutGroup_get_startCorner_m8D842137857E7AD45EE6AC346E0413A8F392729F,
	GridLayoutGroup_set_startCorner_mA30664DE41D3BAA82D88A5A99D1E8141799A6609,
	GridLayoutGroup_get_startAxis_mAA66BAC768514A784F891AF3771952CFDE713E7D,
	GridLayoutGroup_set_startAxis_m273639C7AFDB7C478E131FBE86C1BA856ABE2B25,
	GridLayoutGroup_get_cellSize_mC5817788B1279F0ED4FA8E97D64B705FB782FCAA,
	GridLayoutGroup_set_cellSize_m3002F1B69515359C8B04F5443D564069B9023A48,
	GridLayoutGroup_get_spacing_m4E066AD77C47D776D142944838AA592DCDBFB1F1,
	GridLayoutGroup_set_spacing_mF32D629044BD8E6C1957988794045138C24308A8,
	GridLayoutGroup_get_constraint_mD3C4128F573301158661CC38EB13105D2A3CD0F8,
	GridLayoutGroup_set_constraint_mE4443AAB6843A407F9DF59149A96C19F357823B3,
	GridLayoutGroup_get_constraintCount_mFDF654FD0ED7E27EE6B0A91CEFFD5CDE7CD3D3AD,
	GridLayoutGroup_set_constraintCount_mCC7DC87CA3EEAEDD1169CD193B5D4AA79CC6FB7A,
	GridLayoutGroup__ctor_m28EC9A0E41E7E41D2300210AD64D68F8AA601719,
	GridLayoutGroup_CalculateLayoutInputHorizontal_mE0A1816B18864A95D5C6BAF7CA80F1258740CED0,
	GridLayoutGroup_CalculateLayoutInputVertical_m38EBB62BE57E99E0E5C12613C869963B7F42ECC8,
	GridLayoutGroup_SetLayoutHorizontal_m1EF39B8828AE80B69399AA7B4BE6A4C05828D2BC,
	GridLayoutGroup_SetLayoutVertical_m31FD2FD1283496F10A5457B5606B3269648B6CCB,
	GridLayoutGroup_SetCellsAlongAxis_m9B8524B64C76236C2A650FA33469FD304B3786AA,
	HorizontalLayoutGroup__ctor_m91BF4E28B7EAD170D3298B97CD5693EAD3B49544,
	HorizontalLayoutGroup_CalculateLayoutInputHorizontal_m8DBDC80D3FA52745EAA128EE8DA388FADD0969A7,
	HorizontalLayoutGroup_CalculateLayoutInputVertical_m3BC66076E6A10D0AE17EF46A7333E099CFA4F0C7,
	HorizontalLayoutGroup_SetLayoutHorizontal_m5BBC14368FBB85B9454024243237FE3D1EF4A3EC,
	HorizontalLayoutGroup_SetLayoutVertical_mE191679651DD170E87A8BD1FDF209C4EB1B5AC82,
	HorizontalOrVerticalLayoutGroup_get_spacing_mF0E72DE0E088D3A1C72141A06E671820DC56B199,
	HorizontalOrVerticalLayoutGroup_set_spacing_m57D5B010DB70EE3BD758253FC5A4D66F4CFB2DC5,
	HorizontalOrVerticalLayoutGroup_get_childForceExpandWidth_m469E78D0FBD65A4C310E048344C78FFF670F01B2,
	HorizontalOrVerticalLayoutGroup_set_childForceExpandWidth_m4D900CF3408A41D7E65F23824609F7EF7FF57E2B,
	HorizontalOrVerticalLayoutGroup_get_childForceExpandHeight_m53DF36B44AD193D25380C7E9AC385E5E9914622C,
	HorizontalOrVerticalLayoutGroup_set_childForceExpandHeight_m76C7BA66A926BF02BE3500ADEBC10229B8FCB4A5,
	HorizontalOrVerticalLayoutGroup_get_childControlWidth_m717382EF5BA6539EADDCDCCFE57150059881C3B5,
	HorizontalOrVerticalLayoutGroup_set_childControlWidth_m2C9192500DB7BF9AB2E17C40391C4F9A7FE7DB4D,
	HorizontalOrVerticalLayoutGroup_get_childControlHeight_mE203945C2D8E119C236765B6AD048C0B37530DCB,
	HorizontalOrVerticalLayoutGroup_set_childControlHeight_m375CD26500D400D626D4CCE1A60C31656622FF88,
	HorizontalOrVerticalLayoutGroup_get_childScaleWidth_m0160878917AC8A815C80BB11EA81744C1F768313,
	HorizontalOrVerticalLayoutGroup_set_childScaleWidth_mF2CEB85EF3F4B658A8A6B6394D40EA3C44908307,
	HorizontalOrVerticalLayoutGroup_get_childScaleHeight_m39F288AB513FB4CBF4EF446B3893E20B6D1857EE,
	HorizontalOrVerticalLayoutGroup_set_childScaleHeight_m80E62DAF30C4480E7E393F9604B33628A92CC86B,
	HorizontalOrVerticalLayoutGroup_CalcAlongAxis_mBD2F5E965FB5D3FF14DA66362F3D8D6E7570B4CB,
	HorizontalOrVerticalLayoutGroup_SetChildrenAlongAxis_mE587F7E541768FF7047F667ED9275DB0ED41AB3B,
	HorizontalOrVerticalLayoutGroup_GetChildSizes_m73D43AD63F25246B418DAAF75B7EAC7046F963A5,
	HorizontalOrVerticalLayoutGroup__ctor_m0898BB696CC353377FBCF175B86681B505130127,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	LayoutElement_get_ignoreLayout_m674960BA20B5B43D66D330B5D8EC1109DE9CCCD2,
	LayoutElement_set_ignoreLayout_mA83B2CF22334007D7DB0F89770D3F0B6A1FC7549,
	LayoutElement_CalculateLayoutInputHorizontal_mCAC4BA8545C1E17B9AF5373988F9CFDD316779DF,
	LayoutElement_CalculateLayoutInputVertical_m78707F08AEDC89D19AC105B9E20163A496912B09,
	LayoutElement_get_minWidth_mD171C411C321A923DFCA1A8078E34A5843159EED,
	LayoutElement_set_minWidth_m1BF66D6E95EF801A5B524FCDFAAB3D5E94CD574A,
	LayoutElement_get_minHeight_m2073A6B54227C055021D507588AFABB4865A750E,
	LayoutElement_set_minHeight_m8C84E1959A4C086053AEA787D5764C161F36877B,
	LayoutElement_get_preferredWidth_mCB7E4710CF26E845CB0D0C601536FBBF4E05D576,
	LayoutElement_set_preferredWidth_m6F446890B38433645A78FF803A3A0315EDB6E11A,
	LayoutElement_get_preferredHeight_m69E4021BC8EBB999C0DF30438746F73AF27B07AA,
	LayoutElement_set_preferredHeight_m8400BFE46DBF2E4FA5E1C43F4C97721AC836B91E,
	LayoutElement_get_flexibleWidth_m4CACAAE62C470DBFF9DB51E5742C1905014F65CC,
	LayoutElement_set_flexibleWidth_m77B18FF58BF66FEFE916ABC8CECABC74D33ECFAD,
	LayoutElement_get_flexibleHeight_mD02CB51F08CC258113D840B5FF6FD1960E130E01,
	LayoutElement_set_flexibleHeight_mFFEE9A500A82FAF8C1AE432EA807FF05F275C038,
	LayoutElement_get_layoutPriority_m4BE0D6D1F8D36FA6CB8AE1AD02DAAD26215AB35B,
	LayoutElement_set_layoutPriority_m89170914A681A6B8CE7DAE26F3E785F95FE4AEF6,
	LayoutElement__ctor_m11506C492B20963D347C2CD2C41205D08326B183,
	LayoutElement_OnEnable_mBA9D3928DF8835C7407D60C83EF55ECD5025FCEA,
	LayoutElement_OnTransformParentChanged_mFB56C31341BAE7691F949282A7CB305E249DBCDF,
	LayoutElement_OnDisable_m0107489E98F41B97E47267D741830C0C137CE875,
	LayoutElement_OnDidApplyAnimationProperties_mBEC936D11204B7C6D72C64F884E1535135B58BF0,
	LayoutElement_OnBeforeTransformParentChanged_mEC5B1AEF104419A64FE74B2D31A29B6DC0987565,
	LayoutElement_SetDirty_mF388238B7950A97356CD86F94409B2C5E139C1EA,
	LayoutGroup_get_padding_m7C98F5699A1F144A3CD754094159DD61EDEA6D18,
	LayoutGroup_set_padding_mFF9BDC9CB27CFA3F8F7877370494589BC750E1A0,
	LayoutGroup_get_childAlignment_mC2E6A497C4BCAEF50E46CB271EA4FB48EF345826,
	LayoutGroup_set_childAlignment_m682098D7D631F9CAD62E0862216EFAFF5533CCE9,
	LayoutGroup_get_rectTransform_mBA2164F608E800F4C819611E721EA825995BA9B8,
	LayoutGroup_get_rectChildren_m145C077B057CFC695BA495A113A828E61B14E881,
	LayoutGroup_CalculateLayoutInputHorizontal_m277295CF69DFA23F13B84022E1D2482B16C35B2E,
	NULL,
	LayoutGroup_get_minWidth_mD992262173D5E3937E65062B9DDD92CFD83D66AD,
	LayoutGroup_get_preferredWidth_m278AFB42E85BB072239FCA597DED628EF14C0F7E,
	LayoutGroup_get_flexibleWidth_m9B41E60921FF83EBB1BBCBEB51AF3D174F651B4B,
	LayoutGroup_get_minHeight_mB83AFE2E8B307780B1897A6FA0ACE2B49FFE079B,
	LayoutGroup_get_preferredHeight_m8C6595741BFA31340941117D90C016D9ECD90B0C,
	LayoutGroup_get_flexibleHeight_m65C158520888C4717889070B7B65BA4A844AAEE9,
	LayoutGroup_get_layoutPriority_m7DE6C39661D8321D4416513FE296C59E41711DED,
	NULL,
	NULL,
	LayoutGroup__ctor_mE9EDB59D79B2F479B4F83B2E72B3F28A6ECE1FF1,
	LayoutGroup_OnEnable_mB39D415B2E929902587DF64A4309DB603DBF13B6,
	LayoutGroup_OnDisable_m8EC3E56D5C3BC149AB6AC14107FD5D355D26BA97,
	LayoutGroup_OnDidApplyAnimationProperties_mD9C9DC2A8A41269702743E9B2DA147D1BDA8E3B2,
	LayoutGroup_GetTotalMinSize_m5823C20B9484ACC6E15B40969AB73C22BF957702,
	LayoutGroup_GetTotalPreferredSize_mB458709CB2ADDE62A57E04C6F75E9F78EDCF0B48,
	LayoutGroup_GetTotalFlexibleSize_m46FDCCDA02E9C74D826901517227C4D35F6E4C1E,
	LayoutGroup_GetStartOffset_mE12B0110FDFF2D7EBF37B0CD707AF7D41133E7E9,
	LayoutGroup_GetAlignmentOnAxis_m8A38F1E039364BFB9D27FF1BB656663D3EC96DAB,
	LayoutGroup_SetLayoutInputForAxis_mD99F9A0F350212266AB5782DF024A5BD8752F021,
	LayoutGroup_SetChildAlongAxis_m989B25707EDE13DA0BE38840FABB9D2B413E5042,
	LayoutGroup_SetChildAlongAxisWithScale_mB08FABA1880A800F5EB3621143C6AC13F0BF52D9,
	LayoutGroup_SetChildAlongAxis_m4714DB3C67D9672D10BD889BD6E116F35BD9ABEB,
	LayoutGroup_SetChildAlongAxisWithScale_m1F46FBB4FCB5BDB1D630D9745E22BE12B2CCE126,
	LayoutGroup_get_isRootLayoutGroup_mA6019F332B4E8D73D975AA1C332CB8D7628EC9B0,
	LayoutGroup_OnRectTransformDimensionsChange_m5BD1C40240872FA6EA86602BF85A23908DD27D7E,
	LayoutGroup_OnTransformChildrenChanged_mCA082C8376435962FAE317D684BD107B56827203,
	NULL,
	LayoutGroup_SetDirty_m152A7201F1F9398073632454974676E44328CFC2,
	LayoutGroup_DelayedSetDirty_m2933254B576C5056DCFA10E48A542A6B8DB21C85,
	LayoutRebuilder_Initialize_m9B6938B2B1A081FB3B103A0996F2A542962BB292,
	LayoutRebuilder_Clear_m60DA3F587EC757923870BC3396003EA862C513D7,
	LayoutRebuilder__cctor_mAF54F10C63984CCA9DEBEF6BFDF4FA61BCC2100C,
	LayoutRebuilder_ReapplyDrivenProperties_mDBCB8CA4C64C45ABFAD4C2E8E873B7C1ABC4633F,
	LayoutRebuilder_get_transform_mE890ECF65A84FF10C7EE33BBC73D01503908D090,
	LayoutRebuilder_IsDestroyed_m7C00F5BFB607E5A367237F7E98C55B1F295A2E9D,
	LayoutRebuilder_StripDisabledBehavioursFromList_m9CF0899F9CDC51CD675408E583D91FE69EB3D0A7,
	LayoutRebuilder_ForceRebuildLayoutImmediate_m395DFDC2E411F7DAE10114CB6B76ECF9E2F2D210,
	LayoutRebuilder_Rebuild_m4F6172A7ABA4E3FE206DB9890581C993806CD018,
	LayoutRebuilder_PerformLayoutControl_mFDAE19BFECC6C038AE7F60BC7225B8EF2CDA48BB,
	LayoutRebuilder_PerformLayoutCalculation_mCB5430F37CAD504CB027BD76C7E80B18B9A27A31,
	LayoutRebuilder_MarkLayoutForRebuild_m25E7408353DE4624A78A43AB985C289210B6E1EE,
	LayoutRebuilder_ValidController_m74EE2B6ECA5CC2CD78673626192B8A44DF3DDA0F,
	LayoutRebuilder_MarkLayoutRootForRebuild_m44E0DBDA962C6820A4E747F941126E96613EA0FF,
	LayoutRebuilder_LayoutComplete_m1426141B8418693A23108B8EBB456778886B4B62,
	LayoutRebuilder_GraphicUpdateComplete_mEE37C0D1F726AD91B7A3DDCD8A6F1F056C7E1D3E,
	LayoutRebuilder_GetHashCode_m5424FDACF84B9357892543701E6FC98ADE01BA1D,
	LayoutRebuilder_Equals_m31F03DEFCFD32981725DD94633818B52E486A9A3,
	LayoutRebuilder_ToString_mFF25DB4B319B32D5387BF7FAE7AECF3D89D1723A,
	LayoutRebuilder__ctor_m2BA2A83C3615437ECE582B704689CE15E0DEB2AA,
	LayoutUtility_GetMinSize_m430414C7CA8EF99A8519968D9BD1ACEEA751A431,
	LayoutUtility_GetPreferredSize_mFF694E6C47FA410533223DC752F65F02ACA639AB,
	LayoutUtility_GetFlexibleSize_mF9999813A638C60FB044DC654F1690D151EC08D3,
	LayoutUtility_GetMinWidth_m7636AECFC6B9D23D2F935EF451CE3AA624FB49C0,
	LayoutUtility_GetPreferredWidth_m6CE457065EFB3041B95C63F846DE4FA66420E3B2,
	LayoutUtility_GetFlexibleWidth_mBCB8A662113B098119B47B2715015DB879738477,
	LayoutUtility_GetMinHeight_m340FA8EC5D74BAF9EC725DA3B92B1DE99DB1B3F8,
	LayoutUtility_GetPreferredHeight_m13A1739A1A15D012AAD85AC18307D2EDA1EE6283,
	LayoutUtility_GetFlexibleHeight_m019E2BF198E49FC916C032CB0C47EF228A18BBDE,
	LayoutUtility_GetLayoutProperty_m91333F066D9AC93F3BEC9A33AB9F3232C91FE24B,
	LayoutUtility_GetLayoutProperty_mEE67E5361FD000748AE752388165CE7EE63AE984,
	VerticalLayoutGroup__ctor_m0824F6AE284E5B00625E4AB9B9FFBDA6BD065F1F,
	VerticalLayoutGroup_CalculateLayoutInputHorizontal_mAB31FBDFC9EC9D002B2F887F8E432CA7AAC87FD4,
	VerticalLayoutGroup_CalculateLayoutInputVertical_m41DABF9935F2DD105C9C94CBD00CF9E2FC65CC90,
	VerticalLayoutGroup_SetLayoutHorizontal_mA8295CC4191B2E90A95FD75D7C214B1B47AC5820,
	VerticalLayoutGroup_SetLayoutVertical_m5B333E9565C45AFBF54803A67C031FEDBA8D8D8B,
	Mask_get_rectTransform_m9D5D4775C23D46D7ED977FE1E00424A2E592B0FC,
	Mask_get_showMaskGraphic_m63BDFCDA0B68E7EACA1B9CCFE1BD5155EA1EEC7B,
	Mask_set_showMaskGraphic_m90255D390C59EE8D263A71068837FB0768E998C8,
	Mask_get_graphic_m5B49E746A9E93A4D1BAAFD83F9ACB7C90633B5B3,
	Mask__ctor_m52B610E05764BC69F906983AB172FF23805A1D37,
	Mask_MaskEnabled_mBDFFCB167E44208335DBC9334022A7228FACA69D,
	Mask_OnSiblingGraphicEnabledDisabled_m8CF5123E985B83A339517C7B786D017BD59DE5EE,
	Mask_OnEnable_mC396891226E6853FF502F1F056790192052FF202,
	Mask_OnDisable_m9ACB6854596A0A91E3990F9CE1D7C693B513A9A0,
	Mask_IsRaycastLocationValid_m74F62BD38E42D52E34AE0DC2654AE827D4DEF85C,
	Mask_GetModifiedMaterial_m708D77F5312C3DA4B3E2D5D71046393BE533DDEF,
	MaskUtilities_Notify2DMaskStateChanged_m9059BB3432994FE2C5722C579F36F6B2BAE5B3C7,
	MaskUtilities_NotifyStencilStateChanged_m939869F3BB83A2846052F702B4FB09244AC502AD,
	MaskUtilities_FindRootSortOverrideCanvas_m7E303D29D22F86212DD023C8854211C525629FDD,
	MaskUtilities_GetStencilDepth_m01EE1FFF799078024CDC40C03A4D001351B8BBB3,
	MaskUtilities_IsDescendantOrSelf_m306364287D0DE8E3760278C59272D79E226F5A73,
	MaskUtilities_GetRectMaskForClippable_mA22FA75F79D98E00CF0B0A41DFBD0FC2D4DC2F28,
	MaskUtilities_GetRectMasksForClip_m0A1C0238E0CDFCA72B5E72EC24E3F9A180355585,
	MaskUtilities__ctor_m990AF9ADD62963CBCB13EE2C6C150F27051669D9,
	MaskableGraphic_get_onCullStateChanged_m9CF82537F28EEEC73E48B437DF49EA0B2312BDE8,
	MaskableGraphic_set_onCullStateChanged_m208B9A83B85B42F2B98F454E4A2226D7EB57697B,
	MaskableGraphic_get_maskable_mE95AFA7FF064B95334989FEE75DC2F668E250FA1,
	MaskableGraphic_set_maskable_mDFB9A55F0E7F2F4B988FF4E976FAE1DD6A336A83,
	MaskableGraphic_get_isMaskingGraphic_m2876603FFD10936ADC8008154111FECCB69DC392,
	MaskableGraphic_set_isMaskingGraphic_m2E6B1415EB6E0A0EF864752310B44F1306F429DC,
	MaskableGraphic_GetModifiedMaterial_m8FCD645EF28C3D0E9C40DE6CA88C4A6FA9D1DC31,
	MaskableGraphic_Cull_m9DBCD28391A2ECF6A84FFFF39A556C340FAC2A93,
	MaskableGraphic_UpdateCull_m73323DA72DA1B3C5FE5309398FDCC286762851B5,
	MaskableGraphic_SetClipRect_m55C87014B575FFF861392379718C0138AC12B3FD,
	MaskableGraphic_SetClipSoftness_m57E729CA63EAF90883636ACC257E687E6812484F,
	MaskableGraphic_OnEnable_m9F237DEB38F94621751B57A24C38B5C2B2E37343,
	MaskableGraphic_OnDisable_m7082110BEF7DD61D91076319CF47E97090F70899,
	MaskableGraphic_OnTransformParentChanged_mCFFE90B41975B7BD6C21B95355FD96D92CD17C5D,
	MaskableGraphic_ParentMaskStateChanged_m9AECEF843EC50D19FC347A3C1081E07A9EFEB2F9,
	MaskableGraphic_OnCanvasHierarchyChanged_m02C468B0AD88E840778B68C780FB80B7CCD2768C,
	MaskableGraphic_get_rootCanvasRect_m2751607479FE02BDA964AF973CDD19B62B208DA4,
	MaskableGraphic_UpdateClipParent_mAB3C2401455E40700CF6FAAC0E407FB3AB0E5E80,
	MaskableGraphic_RecalculateClipping_m8C757450AF711AF80F71851DB736D5377BDFEA57,
	MaskableGraphic_RecalculateMasking_mDEEA7EFFC6AB605EA8FE22E5E2050DA4F46DAF38,
	MaskableGraphic__ctor_mF2B16CE3752FDC9F7F96F5DE671690B4424B5AA6,
	MaskableGraphic_UnityEngine_UI_IClippable_get_gameObject_m68A7FD1C35B1E5A0A1FFF135F89A62F4F1521DB8,
	NULL,
	Misc_Destroy_m3EA2A050EE68D29509A76F1E9A25372B8627F1B3,
	Misc_DestroyImmediate_mE7D29D1E4B20D856C1CA3C18A9BF50F46FCC0213,
	MultipleDisplayUtilities_GetRelativeMousePositionForDrag_m185231526F59A9A770E471905EFF08A693E4BDD9,
	MultipleDisplayUtilities_GetMousePositionRelativeToMainDisplayResolution_m2D3CB08174B28122E201011E77C0A1BE762C948C,
	Navigation_get_mode_m3C77554140D0A56ACD06B1E6DB2D016F080FB95E,
	Navigation_set_mode_m98F00F98459C0C3D79FDC7221C779D83130D67BC,
	Navigation_get_selectOnUp_m8E3A8A4358C862B402C322E93062E10F22371A0E,
	Navigation_set_selectOnUp_mDC6497A819851FC70C1771FA5B4F8DEF7BDCD552,
	Navigation_get_selectOnDown_mC9469ADD19689D5D263A39861E70E43A75BB9398,
	Navigation_set_selectOnDown_mE97059CFEDDAA89BC14D85EA1FB51A9D3BDA4549,
	Navigation_get_selectOnLeft_m1B2D71E749D06A2D89855AE6715DBD253BC623FA,
	Navigation_set_selectOnLeft_m6C219E151D044D1C4F086A2DDD104C537553B79D,
	Navigation_get_selectOnRight_mD44071FB2CBE195EBD6EBF37437C3F5BBFA5B328,
	Navigation_set_selectOnRight_mEBD7DF30AC830A83DCC7F1E2BA9629864A40336E,
	Navigation_get_defaultNavigation_m00087A1157696556EB1D34E20D7324DE4788F6C6,
	Navigation_Equals_m06EE535BFA43DD09F43FB681936E6AA4112F2AE2,
	RawImage__ctor_mCB80C49C5E0B500C28F4DC84142D8C38D05CAECF,
	RawImage_get_mainTexture_mAC899EE3026C3BD076E21B43D840D05162F56E29,
	RawImage_get_texture_m992AF81884D22B9ADC97A800AB931DCB4140954E,
	RawImage_set_texture_mA09F1C8E2EBCBE1D2A06DA84BC28FB1F9ED58977,
	RawImage_get_uvRect_m3BE55AF17D17143B9F084B1FA4689C5A52A0F530,
	RawImage_set_uvRect_m610CB870B752BA8C210F031C14C1C90F127290EB,
	RawImage_SetNativeSize_m1C1C496F24A54895367632F8B3F6232F91E892BB,
	RawImage_OnPopulateMesh_m4CCF9546E0927627FCFD69922991DE112B6CB78E,
	RawImage_OnDidApplyAnimationProperties_m608D10EE69EB99AB30C1F3DC456432A723EE39A9,
	RectMask2D_get_padding_mAE70AF9C0ABD28AD225A2BFD4965C45883B31E20,
	RectMask2D_set_padding_mC54939B5E146796EC0EC33626CBF8308F3125238,
	RectMask2D_get_softness_m67F6E132A98566FC2191856462BAB6F7080884C8,
	RectMask2D_set_softness_mF808AE93A3A5C10682C0CEC9B9A5F3588BD693C6,
	RectMask2D_get_Canvas_m67059D0D1FF1530F8AA8B5D94F1A27D559C25C41,
	RectMask2D_get_canvasRect_m2CFEAC92FBAE3C1E500CAD0BDB3D6CDD263558BA,
	RectMask2D_get_rectTransform_m2EE1645888FCF5638B9B59EE4087B96FB53574AC,
	RectMask2D__ctor_m64686F359A4948A90D18A825147A4FE1B4FFD9E0,
	RectMask2D_OnEnable_m7B52E866806641669DD09B0D13CB4BBE1E1E250B,
	RectMask2D_OnDisable_m87883543DA7D4BE685C7306493BA9D26EA72553C,
	RectMask2D_IsRaycastLocationValid_m4CF23859DFFCAC7387F1CB0BBD539C2C6EED9FE9,
	RectMask2D_get_rootCanvasRect_m17D93FBA715A10CB270CE52C794B1FB687DD5431,
	RectMask2D_PerformClipping_m91BF3957B8A63187689F2A89E6098B3071E4BF7D,
	RectMask2D_UpdateClipSoftness_mF53422C7C57EE1904720E5A3E1758B66A218C375,
	RectMask2D_AddClippable_m929A0090BDFD39B38611AB64E3057D57F61FCE60,
	RectMask2D_RemoveClippable_mBB177F8B9F4C654604A627F17A28432B667100F1,
	RectMask2D_OnTransformParentChanged_mF3A127BFCDBC923F54F0CD416BA9365595023A12,
	RectMask2D_OnCanvasHierarchyChanged_mF5D924FA85A0890DCB73251CEBAE4A4C83DFE38E,
	ScrollRect_get_content_m7F3FC07991CE67DFBEE4068D6E14ED0A1E26B526,
	ScrollRect_set_content_mCCF04D1FE05A6EE7DB578FA797DD668C79F05373,
	ScrollRect_get_horizontal_m77D2BE93F6B45D023B56967D39329DB8F8892BB2,
	ScrollRect_set_horizontal_mE171242DA7E88CFA23CFD1867ABCF02408BAE630,
	ScrollRect_get_vertical_m643EEEF2FD8D01EA5BAA2378FF7E32BEC896B273,
	ScrollRect_set_vertical_mC57B4C207ACDBDBB31F81E765DF3E4991FDC2C3C,
	ScrollRect_get_movementType_m96D7F76863CD4288A6E36481A9ED3028EA37CFFC,
	ScrollRect_set_movementType_m5DC0E885A97CE2CE998AAF32B21BA0E5F0872375,
	ScrollRect_get_elasticity_mCC6354C1CEB5F288516571252CDA821B82969C95,
	ScrollRect_set_elasticity_m74BC808E94C6CD5AA54BF1AAA5E835E35A025953,
	ScrollRect_get_inertia_mD2DF80F45E405D5AB4D764FE9D6A8A7A73266468,
	ScrollRect_set_inertia_m77F6FBC5E117250CDD4588076E7795545235ECFD,
	ScrollRect_get_decelerationRate_m4033B0B9663384FCE4AE291DFA3337803D3FEDBF,
	ScrollRect_set_decelerationRate_mD6F9A2957861F11D6D8159CB86E3E95155417617,
	ScrollRect_get_scrollSensitivity_m706C7F4633E2A4B816DA0423821E0716A73BADD0,
	ScrollRect_set_scrollSensitivity_mA1A29A5B0DDC4E7A9CC25F871D0D962CAC85997E,
	ScrollRect_get_viewport_mD3C6CD4F782A5FC7F886BA1CC4DB6CF250DF164D,
	ScrollRect_set_viewport_m445D1D8568F23E4F14BF524A7C3D06AC8C779DBF,
	ScrollRect_get_horizontalScrollbar_m258E5BA6988FD113301575E1107A37D506515273,
	ScrollRect_set_horizontalScrollbar_mB61F6C8B7878EAFCB4AF0EC5D1E42E1A14F8B438,
	ScrollRect_get_verticalScrollbar_m0A9EBD87C90FBC567C11D37ECEBD2E6A7218BD0E,
	ScrollRect_set_verticalScrollbar_m8FBFA26D8764A67595C2A051E9F3EC96359AD587,
	ScrollRect_get_horizontalScrollbarVisibility_mC43D0E4908D8876D399B15F36A8D98B827C77DDC,
	ScrollRect_set_horizontalScrollbarVisibility_mC9B69627EE6A64877864E77485E27773EB855DF6,
	ScrollRect_get_verticalScrollbarVisibility_m8D671BA3821D2F3F263DAC0C7FE1487333326DA9,
	ScrollRect_set_verticalScrollbarVisibility_m04378E56059A4C84FC9B210F79C2E6FF7A507E12,
	ScrollRect_get_horizontalScrollbarSpacing_m12F0D7366D9FEE8B2E886ABFBE35663A43427AC7,
	ScrollRect_set_horizontalScrollbarSpacing_m0ECCC684AE9E391D854C6C2B5B695277F065A2D3,
	ScrollRect_get_verticalScrollbarSpacing_m99467BCEA6A514E4410693AE44644E7035A2FD17,
	ScrollRect_set_verticalScrollbarSpacing_mD3E2AFC566836F6FA7C216D628044D5B46BFB13B,
	ScrollRect_get_onValueChanged_mB59CCC8D8CD14BEB23018EDEE69EDB1EEE32C08B,
	ScrollRect_set_onValueChanged_mAF07F0AB9982FFDD4426A9E50586DA137EC5DCFD,
	ScrollRect_get_viewRect_m4CAAF3A523BAB284A6DA9D5EC45057D7EE51D89A,
	ScrollRect_get_velocity_m44CA563C38ED997693167D354904EF8139C0C9D9,
	ScrollRect_set_velocity_mEC9426341841F20D3CDD799B8C665BCFD34B4074,
	ScrollRect_get_rectTransform_m8DB7B0810D6E5D34C973716FCAC50C5B259DA3FE,
	ScrollRect__ctor_mDD61FF33C47DCA8A928240008EFAD4F0B5D007F9,
	ScrollRect_Rebuild_m267BB5221243C163733957AE0B85FB3E99650FE9,
	ScrollRect_LayoutComplete_mE14EE1A24AED1CB6F1713AE01524E6DFD713F6BE,
	ScrollRect_GraphicUpdateComplete_mE3AF45EC2A4BE612AEA5DC3353F3A2F5F50BAE21,
	ScrollRect_UpdateCachedData_m1D16AA0BC08EC0314233C5FC5A5765CA9D34AEC1,
	ScrollRect_OnEnable_mAFB147D41D660C2A29662E579C75179F10AC88E6,
	ScrollRect_OnDisable_m295590E40366286628DCE780F3A96AA1E1AFEE1A,
	ScrollRect_IsActive_m3999CA1C8943A53FC6CA52DD9162FAEE0CFD3F2E,
	ScrollRect_EnsureLayoutHasRebuilt_m2483FBE8BDAFB07D4FC6312210C6BBB9841ED68C,
	ScrollRect_StopMovement_m07CCEE2EFE71B691CB220DD4E425EEF021659CC3,
	ScrollRect_OnScroll_m08CFC24A7066E0CF03716F7EA75EB54DEDF4D66E,
	ScrollRect_OnInitializePotentialDrag_m913BEBD7F84C7E4161E28DB12051CBD2C9D5982B,
	ScrollRect_OnBeginDrag_m192E58D2BA90D243B35938EF500DD56B2530FAB9,
	ScrollRect_OnEndDrag_mD2CE3B2FB607F557033834F06B68B428B8F2379D,
	ScrollRect_OnDrag_m85965B899737B02EA82060F24F935E75DC6C697B,
	ScrollRect_SetContentAnchoredPosition_m076F4C2F727C2C6B7F7280F320A2E8D47CD3EBA4,
	ScrollRect_LateUpdate_mD0338F8F0C9BDB6ED9A77936E9B842CE4C3AFED8,
	ScrollRect_UpdatePrevData_mF1F5F118359BA01F88039771EACA41DFE383F688,
	ScrollRect_UpdateScrollbars_m497591E45E477F64ED044191EE3DB0FF13E3A282,
	ScrollRect_get_normalizedPosition_m064ABEFDFBCD4B9E01A01A9802297827AA5C8B5E,
	ScrollRect_set_normalizedPosition_mD0152A9B4137D325360590E987023103B90A2884,
	ScrollRect_get_horizontalNormalizedPosition_m959E56CFCAFE7569A2C3E5163F28B336C442C26F,
	ScrollRect_set_horizontalNormalizedPosition_mDD8430131CF4AF2D89BD823258D109DE85049C07,
	ScrollRect_get_verticalNormalizedPosition_mAF207C4C8888284A5C767D746FCD1274804575AB,
	ScrollRect_set_verticalNormalizedPosition_mA0A9AA1AFAC02ED26392F47D1BC33A488065C54D,
	ScrollRect_SetHorizontalNormalizedPosition_mF920FF30350B829DDDECFCDB1390C35468349556,
	ScrollRect_SetVerticalNormalizedPosition_mCEBF9D425E8437747800A215A77DE3DD51D1F96F,
	ScrollRect_SetNormalizedPosition_m0B931F68C9F72AADDC2D83399AD9FC4BBF1E56B9,
	ScrollRect_RubberDelta_mE509E9E109D99815A0DA8F33743E5D6D6B4E6A50,
	ScrollRect_OnRectTransformDimensionsChange_m361C33901A72D7013A4D3A6C2867035FD3A26197,
	ScrollRect_get_hScrollingNeeded_mEFE7764508480F49A1309DC875A322DDDD8FAC38,
	ScrollRect_get_vScrollingNeeded_mA8735A2355F5367934E394121E40BAED0BBF85CB,
	ScrollRect_CalculateLayoutInputHorizontal_mEDAD4A0AA8B1A774B19251979A0BF3400BE50CD6,
	ScrollRect_CalculateLayoutInputVertical_m624C98DEBA5E3460709A3B26BB1BD03F71169634,
	ScrollRect_get_minWidth_mA267D28170303672F3399D2A96A1DFDB714D4170,
	ScrollRect_get_preferredWidth_mF3644DD1214DF90155D8F4D6821DABC0A017D38C,
	ScrollRect_get_flexibleWidth_mB580A06FB49CFF43AB6523219D59E2D327031457,
	ScrollRect_get_minHeight_m43301B9C935C4F2B449F21F417D11EC078875C6D,
	ScrollRect_get_preferredHeight_m7FA20C8592B368AC8312343BF0A30458D47F15D0,
	ScrollRect_get_flexibleHeight_mA707884F08E849377677DD1CDE0E8A10CCA19A33,
	ScrollRect_get_layoutPriority_m9E8FAA08BBABB9A2D8D6C3A49A564E1DCE877666,
	ScrollRect_SetLayoutHorizontal_m5661A30C05FE721AF1920780D0F5D3F475997C25,
	ScrollRect_SetLayoutVertical_mB30C93AE3867BF3B3B9351344619FF311CBBEFB1,
	ScrollRect_UpdateScrollbarVisibility_m047CCDE29A8A95C181EEE47AB8DDB6D9B9D0589C,
	ScrollRect_UpdateOneScrollbarVisibility_mA9F384AB871F06911CB76D8EE056A8AC7C633343,
	ScrollRect_UpdateScrollbarLayout_mE84D1885FD9FD5A61CD83A2332E1ADAB6244B9E2,
	ScrollRect_UpdateBounds_mA6F591EEFAA6000373EA6879A756A0C6F8C1976D,
	ScrollRect_AdjustBounds_mAA4402E720AEC7EB8FC9282AD89888E4C3866E9C,
	ScrollRect_GetBounds_m4E34C67E606612B3B541AC10CABD1A8DD60BFB51,
	ScrollRect_InternalGetBounds_m57F907604A74BB8C930F0E8E83643B58B4F70EF4,
	ScrollRect_CalculateOffset_m198A2DD190E762F54FFDF9ADB4F9D09C3C72C49D,
	ScrollRect_InternalCalculateOffset_mB96285CE22E7699375AF4A02B612794774262AB4,
	ScrollRect_SetDirty_m658BB2DDBC1B094D7554F0F799C64C92051AE709,
	ScrollRect_SetDirtyCaching_m4CDF1D381FD4358E9399A1B8951B7BC5E6A83283,
	ScrollRect_UnityEngine_UI_ICanvasElement_get_transform_m5BCD58D5BF9AF3D8FB743417F783A815344B38B0,
	Scrollbar_get_handleRect_m104FE0AF1CA77701926B9247530BBDE16CD03421,
	Scrollbar_set_handleRect_m7AB0A8D449A11E4F2CE86DAB09E7352D04C00EE9,
	Scrollbar_get_direction_m9DE22D72DE14200D3B7F70410865872034DB3C26,
	Scrollbar_set_direction_mAD47D121E56813030F0CCAC88FB12468624A2B25,
	Scrollbar__ctor_mF899CAEC1EA445CFBE93142D08B7DDE294A394BE,
	Scrollbar_get_value_m96DA69C1452450B3BFCD269836BE9F1F396642ED,
	Scrollbar_set_value_m8A103799361CED9ACECFFAF853C68D9E0D243DC8,
	Scrollbar_SetValueWithoutNotify_mFA921565D87E028FFECBE8A9421BD50F8789B82E,
	Scrollbar_get_size_mBAE39F739D8E11802B84BFDC04AF6BD9E10168FB,
	Scrollbar_set_size_mA94BF8336B8F6C4809982100D33BF1680E07340A,
	Scrollbar_get_numberOfSteps_m6A4DFE194F885E38CBD60C633882CC0D0818C21E,
	Scrollbar_set_numberOfSteps_m44C345A60D892B318BDF22076D22DE7F45B550A5,
	Scrollbar_get_onValueChanged_mC58EA55182B24E42CEBC360FBA3F0533B3CF0FF8,
	Scrollbar_set_onValueChanged_m9A0A5750096730E93E55B5BF7BF4BB1AF77A8314,
	Scrollbar_get_stepSize_mCEAB36BF3B7DB02E28BE1F044B3116767D1F678F,
	Scrollbar_Rebuild_m2F2C370CBADB47225372A7DA2B7AAFE320AF839D,
	Scrollbar_LayoutComplete_m0F182E65D4A7E689D82FB8B807FF6D04CA87889F,
	Scrollbar_GraphicUpdateComplete_m4504E7FA7C8FFDAB250C78FD1121F6093AD8FAE0,
	Scrollbar_OnEnable_m7632B6295FE24FB5489CFEEBCDF4AF6109AD01A4,
	Scrollbar_OnDisable_m5C653E01256FB6253109072F879604EB7BA53B19,
	Scrollbar_Update_m22C117DBA8474791D2772F87AD56E872753F4A55,
	Scrollbar_UpdateCachedReferences_m4676B3AFD6D448508A7388AD4EC43E54709127AC,
	Scrollbar_Set_m597C78A582A3786A25765F81CFEDCBFA5261C506,
	Scrollbar_OnRectTransformDimensionsChange_m5BE96046811DD03D777703D7306718366794FC40,
	Scrollbar_get_axis_m45122AD4E1A73A6555181B4A6A9C86DE2EE07EE3,
	Scrollbar_get_reverseValue_mA71942063142A7A250D755D8179CBBFE355D84B4,
	Scrollbar_UpdateVisuals_m21FB151B8BBCEC58345DAC492639EF4AFFB2AD09,
	Scrollbar_UpdateDrag_mF199AC7C5D77295535B35D0C6FB3DCEA66E13B1C,
	Scrollbar_DoUpdateDrag_m7158863F17F6C85F8B6F09096E7A39B6D806FA52,
	Scrollbar_MayDrag_mFB01E597C203C999B4DDF6AD4C9E0E703B2F6B09,
	Scrollbar_OnBeginDrag_m3B76D8C6F5845106DEDBF22E50C08391387424D5,
	Scrollbar_OnDrag_mC88986297DC288FB4B2E463E75EBA59F98DF1E7B,
	Scrollbar_OnPointerDown_m8412C431E9FEBA656505F4C906C5FEA73C7D9E8A,
	Scrollbar_ClickRepeat_mDC154D3144E7BF8C44CA99EF8BC8CD4C8E56F60D,
	Scrollbar_ClickRepeat_m76E29E37C680B8A5633C9AAB8581CAEEDD83AA11,
	Scrollbar_OnPointerUp_mCD49D3A5F456198389E204C50CE3C36EA5960E5A,
	Scrollbar_OnMove_m1249139D24A32892FCDABBF6ADD2E0BE2CD7C6A4,
	Scrollbar_FindSelectableOnLeft_m374B5705442CC40C149835019C9EAB55C079F6BB,
	Scrollbar_FindSelectableOnRight_mC2CAC3EB7EA1FC16155EF3E90B6E088B5E09FD5B,
	Scrollbar_FindSelectableOnUp_m9ADBB11544C5D9D09414A397C4B22B19E60C252F,
	Scrollbar_FindSelectableOnDown_m3A2776AE65F7CDFE6F3AF88B607F06A39B35C7D2,
	Scrollbar_OnInitializePotentialDrag_m293B574719705C39D4D3E61CDBF367795015DB6E,
	Scrollbar_SetDirection_m04E971B5F25701C119EE60595560A5A821BEDB80,
	Scrollbar_UnityEngine_UI_ICanvasElement_get_transform_m582D531E9319A901C4C02AB8BE873C0F286AAC11,
	Selectable_get_allSelectablesArray_m04E41DC3D73950382018953096CCCB4666D75D78,
	Selectable_get_allSelectableCount_m5C8899307F8D8CB131ECF96189CD705E8BE19583,
	Selectable_get_allSelectables_m9F82EDDAB37348696DD42FEF5CB8DD1B40EB91AC,
	Selectable_AllSelectablesNoAlloc_mD71A0DD1083855505636B761F0818C64FD111106,
	Selectable_get_navigation_mE0FE811B11269EFDEE21C98701059F786580FB50,
	Selectable_set_navigation_m40A501995B245DC9F28F2B5BE7B97849D77A15E0,
	Selectable_get_transition_mC5883DD4A0EC4A58F41285A8684B018309041D9E,
	Selectable_set_transition_m63DF4D4E58FE8DB9AF1FF233A51794FF595B9FA1,
	Selectable_get_colors_m9E63E13A7B6C40CB0F20414FFBE15873BE5F3E4E,
	Selectable_set_colors_m81723DC8CD15819135F76C107C118C668213D80E,
	Selectable_get_spriteState_m0A341E18A903DAEF82259637F2D09B1CEC4DFD85,
	Selectable_set_spriteState_m5393CBF0D75932E2CDA1CBCA934ED0DFDA857915,
	Selectable_get_animationTriggers_m6F8F01A53FACD447624E24686E89F05EBEBF64E3,
	Selectable_set_animationTriggers_mAD7F1E48392417058B69CF8C7EAD793AFC75B05F,
	Selectable_get_targetGraphic_mB12CA26D04922ADB483397992561CA3941E78F92,
	Selectable_set_targetGraphic_mDA4746F7DF1665B6BF49CE3B026DE84640CA7AC5,
	Selectable_get_interactable_m0120339F2B195B7992F459FD79A72CA95B7808EE,
	Selectable_set_interactable_m91B2707F7B4F46F851C3100A65BEFAA557DCDFDE,
	Selectable_get_isPointerInside_mCA6F9E1EEAF058D94E6E6BE884547E8D8E0DF8ED,
	Selectable_set_isPointerInside_m1167C721135FA817A58A522347E09F5A1C1A18DB,
	Selectable_get_isPointerDown_m3975C3D82569067F116D62D0C337AAC5962C36C5,
	Selectable_set_isPointerDown_m2A0A87D0CE5F9DA9E2394F724E7CFB4B181449A5,
	Selectable_get_hasSelection_m2DB863F8B2D560B2D757FB9AB6E4054AE4FBF877,
	Selectable_set_hasSelection_mB1AADF443993B6349B39E96F6AE2D43B6809DFD8,
	Selectable__ctor_m1E7B3EB14D7DC765A511C053C0F65A37755EC4B9,
	Selectable_get_image_m74FFCB0802A2E8380B33314F53A9748370D1C9F7,
	Selectable_set_image_m1891A62E7B98B11323E1461BFE7C8BAFA8A27DA4,
	Selectable_get_animator_m6117A378EE32B632B32C7441887BABF3ABA1C9A8,
	Selectable_Awake_mCF6C8CFE3E1F040F6B2C16EEE601AEB06D736C1D,
	Selectable_OnCanvasGroupChanged_m2B8B50B4EDB1010F0D528ABFA086E21A2810F072,
	Selectable_IsInteractable_m4075B87AE967894F94D87C9A47F6F314225B2B47,
	Selectable_OnDidApplyAnimationProperties_mACD23D97F62122F07F56C97301D1BA0394DAEF30,
	Selectable_OnEnable_m63C9B777E61D9AC975344E4F2B344486A1A359C6,
	Selectable_OnTransformParentChanged_m18FB4CECAE86051DDB942189E370244D3D3E9A8E,
	Selectable_OnSetProperty_mE35632CDB4A1D3E3327EDBBF21CFD3192E5060C5,
	Selectable_OnDisable_m4D4535A97B291959E391BCC56D51BF75B7B0F1B9,
	Selectable_get_currentSelectionState_m37B79D51884A49924B92D1AE1BAA354C55CA1FD0,
	Selectable_InstantClearState_m91C43C9233166E21CF2ECEBD620DFE9E00041C47,
	Selectable_DoStateTransition_mEC025D35C6671DA32750475C88DFE7651CE4B7AB,
	Selectable_FindSelectable_m7197D69C5F25246DD57F86B660218D9F64F4902A,
	Selectable_GetPointOnRectEdge_mD500D4CD3E1541B610D04181241091241A0F5A28,
	Selectable_Navigate_m4FDD4FFCD48CFD630D17C04637502A2805CDB9CA,
	Selectable_FindSelectableOnLeft_m501FD2B988BBFFDAD318800A4D164FB21F1AE315,
	Selectable_FindSelectableOnRight_mA5550ED566545FF1E5113E935F4F57B63F3760FA,
	Selectable_FindSelectableOnUp_m26D12F3EBE3D07C4D69C639DE4D219B40886E8FA,
	Selectable_FindSelectableOnDown_m2EC533E6757FC29A2FABAB68A5E8D56394FE2637,
	Selectable_OnMove_m8AAE7D2F2A2059EED12925394E398B65F251AA4E,
	Selectable_StartColorTween_m1BA85AE34B9A886B74238F05F370835CE94CD5D9,
	Selectable_DoSpriteSwap_mF4F4977E6609789F67C5A40C7A184CAD5707F752,
	Selectable_TriggerAnimation_m438985D7B825F426888769754D50A4A2C637AFD3,
	Selectable_IsHighlighted_mC11E539C4FC416D05B0733B0A641ABA5F276BE44,
	Selectable_IsPressed_m217CD91BBE84B4D4C3A457EBA36A964DA8D5762E,
	Selectable_EvaluateAndTransitionToSelectionState_m925817B538D603A5A14AE0EC7DC3C3ABE1462B0B,
	Selectable_OnPointerDown_mF81D9CFD8AC52A2EE73E6A65CC51AC93E44D0321,
	Selectable_OnPointerUp_m8E67DADBC60C97A24608D5C158A94DF12BDD3A54,
	Selectable_OnPointerEnter_m25A9DDB384226E415785C3A6CB0A0FE61483EE03,
	Selectable_OnPointerExit_m0C898C493D18958AA9CD049A5FAAB8DBAD026DEA,
	Selectable_OnSelect_m9CFD4A5A15A6D16E75E5D6FC73CCE7869A2D23C8,
	Selectable_OnDeselect_m09801707C815FFFFEAD78D16AC1187F7C51C656D,
	Selectable_Select_m41FDB7D52E825BDE2C34B18C0EE7A80915A9F9EC,
	Selectable__cctor_mD2F3280F120072463AB6F5DA01107C71B6764F5D,
	SetPropertyUtility_SetColor_m7A4396D8CC55463527EE7B872A25AC763334D566,
	NULL,
	NULL,
	Slider_get_fillRect_mEDD45CFE2E622B61B82469DBA18B52FC3C3C279D,
	Slider_set_fillRect_mD84E7633BC3F88D77B10F78C5B6731674B98110B,
	Slider_get_handleRect_m2EFF3788BEBE513F7C5CCD3E494F37C153F2AAD8,
	Slider_set_handleRect_m5BFDDDC79CBCDFD3A85969E4793E6775EC8A54CE,
	Slider_get_direction_mE9A02803187D68D400284913BC6F93F587610022,
	Slider_set_direction_mA51E204E4880C34EAC54578285F6C25C8C7D1170,
	Slider_get_minValue_m39F8A4DDD14BE2AF97ACD326FACFF2E169377DF7,
	Slider_set_minValue_m795F45748FA2890925E28E87AB23EEC89E15756F,
	Slider_get_maxValue_mC3AE4128A6DC12217BEEBF168C92808E9EEFEB2F,
	Slider_set_maxValue_m3517BF6A1127298F11582535887B6FE5AA7C57D3,
	Slider_get_wholeNumbers_m136600AF2452CA26E86DDC3D0D54CCEFD3814F63,
	Slider_set_wholeNumbers_m6822D70D08748A8CF82A24B2AB86C83AA2E3FEE1,
	Slider_get_value_m0F777FFC198C6D9A822F89C2192D7A519CD2BD53,
	Slider_set_value_mE113ED73D32B7F474080173006FBF2D67B82718F,
	Slider_SetValueWithoutNotify_mD18769CA2D2AAD631F59972C1C759038138091C6,
	Slider_get_normalizedValue_m72EE50CB45B6B56B31A47E75D1F95B48937A7E2F,
	Slider_set_normalizedValue_mF932B150739F3C38E125175E81FD7C0F11C44A23,
	Slider_get_onValueChanged_m9D9177CDBF349783372AABF032F2D2B3178A84D6,
	Slider_set_onValueChanged_m27899FC1F664132955022FD71B640765F756BA30,
	Slider_get_stepSize_mD4640C1F82F7734407999F331AB6E007967364CC,
	Slider__ctor_mB9749A83A0FB05CF9F59D00CB5F9DAA1FDF87D64,
	Slider_Rebuild_m070D814D4008AC677F2DEC291A3191AF1CAC8C6E,
	Slider_LayoutComplete_mE739FE417F0D246B71B8B0DEC01C71F26D8D7CFB,
	Slider_GraphicUpdateComplete_mBEE6AAC8FFCB0949AA25AAD4D1008A67C95CFDB3,
	Slider_OnEnable_m94A7E2FF6F581C3992875AA18F681A9A72EC719C,
	Slider_OnDisable_m0A25AFB7921324B5B3C611F0DB30B88ED4D5F92F,
	Slider_Update_m75AE1C642DD5404ADA40E0045E2D467459BB28C4,
	Slider_OnDidApplyAnimationProperties_m969003FC5EA26B90195B76D17C20B8356E0F2355,
	Slider_UpdateCachedReferences_mAD4CB104043152029834B94B8BE74FAC82F2969D,
	Slider_ClampValue_m31CCF27E40BB02B82F2E9555DCC35C9790184EFC,
	Slider_Set_mA0A17D8C3C828B8DEFF462B664FC98F563EB6732,
	Slider_OnRectTransformDimensionsChange_mAE8973B662B2A466599391B4E025AFFC2B699995,
	Slider_get_axis_m9F710E0C68A9BB669EEAEC975162175F7739EB0D,
	Slider_get_reverseValue_mC323FAACCF39EECD0D66012C8A455D2CB8135154,
	Slider_UpdateVisuals_mE375780E83D08FA084D10A457861251A235CBA2A,
	Slider_UpdateDrag_m48423493426B22F202FC78B7AF92B95398111E9B,
	Slider_MayDrag_m9BDCF2F984E31CEFD030350E6051812195C75D6F,
	Slider_OnPointerDown_mCD894094C24BA933D5E34543598D6F484C0E62E2,
	Slider_OnDrag_m9ECE82FD5564D048B5F2E3FFF6ECCE2602189CD4,
	Slider_OnMove_mD523157E7F7722B098B6164B558C14B0C6B38384,
	Slider_FindSelectableOnLeft_m1712ADA199F792D4C30D0094AA9A43D3441C7471,
	Slider_FindSelectableOnRight_m42B9D352422ABEB7719BD3F63821A6166261C646,
	Slider_FindSelectableOnUp_mC66B25E4FB7290FCF82048F6AA857F0C6ECC3FA7,
	Slider_FindSelectableOnDown_mD2F38D581CB5AFA849AFE901EA512579A2799E6D,
	Slider_OnInitializePotentialDrag_mA0F17D75D4449731C8497D93FD27A655300DBD53,
	Slider_SetDirection_m71F1505A3E095AF24BDEE69116C88D95F51F2E10,
	Slider_UnityEngine_UI_ICanvasElement_get_transform_m47384BECFD0D74507A4118F086EFA66216799287,
	SpriteState_get_highlightedSprite_mB8CB5AD077F9FDA5A7DA9B0700B70FEB471B15F0,
	SpriteState_set_highlightedSprite_m44A452FACA739422110D9B8C2E51E8874A730B1D,
	SpriteState_get_pressedSprite_m42EB6FFB954E6BDC6384B5DCDD7348DE4F7D44EB,
	SpriteState_set_pressedSprite_mB3C2505D0D31FBB5549444AF739D887B399535F6,
	SpriteState_get_selectedSprite_mC69216B3ABE6539D061E34707C086FA76F28FF5B,
	SpriteState_set_selectedSprite_mEA22F605F22D4302EE742C2500B891DC442A0EB5,
	SpriteState_get_disabledSprite_m08ED7B54CD394C0CE044519A296600DFF14D0B57,
	SpriteState_set_disabledSprite_m4F8989570A957B357527421B89EFF14CA2228E14,
	SpriteState_Equals_mBD4F9DE44FE87CA763874C9C8C0FAC60E1686592,
	StencilMaterial_Add_m0CAC8A2810CE464C942A113C2C98B4D0DFD490C6,
	StencilMaterial_Add_mC3BA91DE802960AD78E0121510054F66D5907957,
	StencilMaterial_Add_mAB4F4B762B5FA96473A30706AC2570FAF86D4746,
	StencilMaterial_Remove_m3D0EEC517780E1528A9D4F3AABF3B78BF59B5282,
	StencilMaterial_ClearAll_m0E04E813DE65150C047EF22F090BEB6C00DED77B,
	StencilMaterial__cctor_m55BD7A7538EFDC49FDF2AF3C1F43D7D0615AF13D,
	Text__ctor_mC95797286B600CF862FC75F9E65F48267313865F,
	Text_get_cachedTextGenerator_mC2FED5B2D9A7BF6D4372FDC993D0B7F0EA3C1DA8,
	Text_get_cachedTextGeneratorForLayout_m0F227772707238FF803F6A14F7B06B17D87A8BC5,
	Text_get_mainTexture_m2DB4BB9E001F9251B8B95887CC17CA78DAEB5C45,
	Text_FontTextureChanged_mFD9E41BBD0E8875A640F7554A4A233F4F91D8D32,
	Text_get_font_mC5492E71F03FA7CD2B9C42672B662FF2383A7919,
	Text_set_font_m77D86B27FDEE1FD2D96A7419F11CF9B249A50D66,
	Text_get_text_mAC04085D2550B32FF25ED8C7FBE012B527D4F8E5,
	Text_set_text_m06205D43AD79670752504410AEA7DB65F3495261,
	Text_get_supportRichText_m773629D045B3AB8B019607FD62CF6FF5E084BE47,
	Text_set_supportRichText_m8854F111655576BEB5010C2E20DBA3F6CDD4A728,
	Text_get_resizeTextForBestFit_mA8C9E2BEB9842156E49EBD769CD195DFFBDA6BB6,
	Text_set_resizeTextForBestFit_mAE249035B12F07D09257F84A5ABA473C0E76596D,
	Text_get_resizeTextMinSize_m9B6868F8F5FDDB892FAB0606A84D0A4F60CC2A55,
	Text_set_resizeTextMinSize_m5120DA2BCA50601607C9E8C5626BF4E22B741F76,
	Text_get_resizeTextMaxSize_m425BDDA1A72EDC3E2D3BA30C4B55F8D4FD7163CD,
	Text_set_resizeTextMaxSize_mFEFAD8F77C8C7A2C7FF8C3EACB7D6FF6BAD921E8,
	Text_get_alignment_m764224AECDEEF22CCC70D507944D753FBCF58D97,
	Text_set_alignment_m561721B60004841C883CE9E1C981616E08AB1900,
	Text_get_alignByGeometry_m9F2147D31569144BC67429F00C4D5458CC75326B,
	Text_set_alignByGeometry_mCC0F6C643A459A43FEDE07106208D07993411079,
	Text_get_fontSize_m54D89E58101CB7F2B51110A6161E8C36D5373428,
	Text_set_fontSize_m7551E066F44B292BBF8EFC7EEF3CBEE1D1AAFB06,
	Text_get_horizontalOverflow_mEBD747C7A0B0DEF7AEC55307A8EDA6DD1ECCC5B2,
	Text_set_horizontalOverflow_m25E21FB646B7B4802055E363BE35A76B1C0601CF,
	Text_get_verticalOverflow_mA8582227054F2DB4071BDC70204103C98C1D7D79,
	Text_set_verticalOverflow_m4DF07E06D460D0D9182627CCA3619AA1E1C11E94,
	Text_get_lineSpacing_m45E1C10CB772BB56DA0DC2A8FEE7A7CC9B3C5105,
	Text_set_lineSpacing_m0B40346036180A5375F33075B3366F56F1C52801,
	Text_get_fontStyle_mA223DF2A20DDBB2755624498CFD8C99E22A981CA,
	Text_set_fontStyle_mEB69FC3AD201D282D5DC1985A6B3656B79542030,
	Text_get_pixelsPerUnit_m66B1F16660BDE8F058F59B80B196F5A10B8BFA11,
	Text_OnEnable_m6D5C18FAA3B6F62B55A83D44A20949C1CF5CE7FD,
	Text_OnDisable_m0B0965F6DA3A71683822989744E5705CD1641FE5,
	Text_UpdateGeometry_mA8A037291FE143D329C85EAC881FA56F84DD73E7,
	Text_AssignDefaultFont_m96292009E24D108CA2889748CBB06B34CF854B69,
	Text_GetGenerationSettings_m601D90FFD85B04F8DD7DA4D701080AAB77F2FAAD,
	Text_GetTextAnchorPivot_m46E0F5CDDA2E0366DBB463A2D46F3F334FC1D058,
	Text_OnPopulateMesh_m29E980A07D59D8151E7497E11FD5EE15AF85FF6F,
	Text_CalculateLayoutInputHorizontal_m7B2DA73FF1503750666D8468BE7102EEDA1EDD65,
	Text_CalculateLayoutInputVertical_mC194E8A8CFACDAE1F7DA8D2F3168FB14315A3A50,
	Text_get_minWidth_m46490002BA829F128F9B6190FAC94839CAFF48DC,
	Text_get_preferredWidth_mB995B7D7B8D1808D2CC91B7D8CDE6072390DDF4F,
	Text_get_flexibleWidth_m78EA0BBCDDEF992B51E387CAB6C31E72CDF70A6F,
	Text_get_minHeight_m76435DC5706971E701498CC565CB3096F5DB2C7C,
	Text_get_preferredHeight_mD5E92B056D52BDD6BCCD9F799C402605A6E5578A,
	Text_get_flexibleHeight_m77EAAD745212A4E7FD27B6415E222BE5B76792B9,
	Text_get_layoutPriority_m83D4EEEC3869BC520693077152DA06BB916F90F6,
	Text__cctor_m3CBFDFC22A6A1860DF15ADC7E2E4E6616447EFCD,
	Toggle_get_group_m8A53B9EF413E699F639789C84035237AA9E6F614,
	Toggle_set_group_m79CCF30AB22683B835A9FC60668B62E804887138,
	Toggle__ctor_m6071227A758B1F396BA3794940A43A18370821DF,
	Toggle_Rebuild_m5112CD920031EC8E296631D0825CC0171DF4CD1D,
	Toggle_LayoutComplete_m6BD1146C8118A6E439509669D6D66DFB9C8C29EC,
	Toggle_GraphicUpdateComplete_m116EDA905EAFB6F70F25185E343611C127D2D95D,
	Toggle_OnDestroy_m9754D2593E4DB02B19EEFCAEA8769D57B9307BE6,
	Toggle_OnEnable_mC49A4F8CC585002FB544314DA6ED5AEEF90CC606,
	Toggle_OnDisable_m1F8B403A7836271B53223A5112E59033F1F970C8,
	Toggle_OnDidApplyAnimationProperties_m039EA4C84F62E2C815E59BE4B9DACFD6CF19D1E5,
	Toggle_SetToggleGroup_mDA126E6B5A5DAED335E42E8BAEF4AD3DD0369AF5,
	Toggle_get_isOn_mC0C6AA83480A8DEFC7ADB2BC4FE1FCF0D92CA964,
	Toggle_set_isOn_m520D16B143619437D7997316584A029D7C3CABF8,
	Toggle_SetIsOnWithoutNotify_mE889EC3B1C7E271C822D07F5F73CB023EDFD87B4,
	Toggle_Set_m48ADB027F8B3C1B761EB6947B2DE48BC40977413,
	Toggle_PlayEffect_mD786A6A6C18AFD30E7CEAAA65FD3CA027A6AC1C7,
	Toggle_Start_m218BE913F96CC0BEDAF517F3B15DB704307E920E,
	Toggle_InternalToggle_m5E9A8D95C789BAC57A1AA00F08CF0DD3DDB9D7A9,
	Toggle_OnPointerClick_m9910AE088F9E1DA3141AA096508BAE749875F917,
	Toggle_OnSubmit_m586CC315CDCA1E0A45918AA0C6BFA917C6265939,
	Toggle_UnityEngine_UI_ICanvasElement_get_transform_m0C71617F839B3BCEEA765EF98476562CF609835D,
	ToggleGroup_get_allowSwitchOff_mB9E04E1842B8293F8B25956D0AF14F8B8B5F5D94,
	ToggleGroup_set_allowSwitchOff_m2D7F870F2BA9CB14E92C2198014862B303C63F16,
	ToggleGroup__ctor_mAE46954152026CB11A1F336EA4963BCA9A5FEFA1,
	ToggleGroup_Start_mED5FF12C3F8C51D3D3F2387EDC90D8DCB547CB5F,
	ToggleGroup_ValidateToggleIsInGroup_mD4CA76641EF05E60429FFF845F19D107C603627D,
	ToggleGroup_NotifyToggleOn_m16EABEAEDA4F5BDAEEEFBECF7E802CA7151A82E3,
	ToggleGroup_UnregisterToggle_m724862AAE8CE184E7336D54F44C5ACBC9858D20A,
	ToggleGroup_RegisterToggle_m1CC85EE0BE4DA4B993F5C04DBC87F0421BCA1ED3,
	ToggleGroup_EnsureValidState_m074ACF3B8A6E2B4FAEFE382BC505F7B0CCEF74C4,
	ToggleGroup_AnyTogglesOn_m4EDBE46AC4C4458B91462F963FA34B9AD8DA4F4B,
	ToggleGroup_ActiveToggles_mDBD4CB3FCEEB4F5C7ECB5E6D0F7EA17FDDF54300,
	ToggleGroup_SetAllTogglesOff_m5DB321BD06A6B66ADA0B0022766A561BD0AE7BC6,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	ReflectionMethodsCache__ctor_m4D4F63AC8FE19E72E654B2CA99A866FDD7992795,
	ReflectionMethodsCache_get_Singleton_m6C50C55DEEA425161B73545918267BB90B7FCB9B,
	ReflectionMethodsCache__cctor_mD5ADC515BEA2AF24353BD7045D1BC482DE1F08C5,
	VertexHelper__ctor_mF43AA93AF0E1C7EC27B0D6E2207707382A53C115,
	VertexHelper__ctor_m4FF21AED0081C159CB153B73D0DE4D7AFEC2655D,
	VertexHelper_InitializeListIfRequired_m083C55BC590E01F63EF24171AAFBF57EA8C69AB0,
	VertexHelper_Dispose_m03C8CF87F673E27160B27FC2AC64DECD2B7F0749,
	VertexHelper_Clear_mDEF52B52B9F138C32027CAA42A0C9302FC899455,
	VertexHelper_get_currentVertCount_m99ACD97A171FCB5046C7608CAD7399A8E0A6FD3F,
	VertexHelper_get_currentIndexCount_m071AFF6C0DB763292367B1C2926B41996EF164C9,
	VertexHelper_PopulateUIVertex_m75E49AE0377BABEE2C3D1CCA1624DE5668B5C42C,
	VertexHelper_SetUIVertex_m71EA6FEB875252F25180FA7F3849A962C6231976,
	VertexHelper_FillMesh_mBA946D1CEDC24DCCD8A593CF77D0B54D14FDB74B,
	VertexHelper_AddVert_m9CC5667FED5B7550564C37BBB61E2D9B558C7733,
	VertexHelper_AddVert_mD0E98F14CE110C3D1D3DB60E9F7B84D7F4F8616C,
	VertexHelper_AddVert_m8133C9A62368C1FA8DD53EB3A42A612AF694E8A6,
	VertexHelper_AddVert_m7FB2655449034894FE6FFAD2E1F4A678DB8C4FB3,
	VertexHelper_AddTriangle_mCC7AD55263B747D7653590BC9220D6369D168AF4,
	VertexHelper_AddUIVertexQuad_mDECEEA1FE0985C87BBDF905D8F29F9C2434B14E0,
	VertexHelper_AddUIVertexStream_mAAA730380EE6D6988274BDD8E86FD0B24BD19BCD,
	VertexHelper_AddUIVertexTriangleStream_m5A9D5AAECF1B6326FCED054EAC66701416641912,
	VertexHelper_GetUIVertexStream_m88D1624450F08F926008DAF833DBA2A80BC80FF2,
	VertexHelper__cctor_mFB392B47FC06B93EE482011E40BE32F0E87CCC17,
	NULL,
	BaseVertexEffect__ctor_m9356F0465FF34D591F7F41774A4626014230F46F,
	BaseMeshEffect_get_graphic_mDD7D8CD6F220B9DE656145A1346EA9799255BE21,
	BaseMeshEffect_OnEnable_mEFEC953AFEB543E262347EFCF0FDF0ACAD8FEABC,
	BaseMeshEffect_OnDisable_m92E4E2BAB5D8D713D63A74657C630AE41F48BF7A,
	BaseMeshEffect_OnDidApplyAnimationProperties_m91A58D830823680102ABE042673306DEDDD0568C,
	BaseMeshEffect_ModifyMesh_mFA7C06FDE36C1C1DE82D2FE6AE36031B668A74F9,
	NULL,
	BaseMeshEffect__ctor_m544B1FC50DE8DE4A5725C0CE17AD1F2BFE951B9E,
	NULL,
	NULL,
	NULL,
	Outline__ctor_m76F9BA58973343AD9E785DBDF781215E3D3D65D4,
	Outline_ModifyMesh_m6A282A1ABD8F14845A69A4C65AC61DF57C89BBC5,
	PositionAsUV1__ctor_mF252120BE2353EBFC62C00CE7995049118A2B14A,
	PositionAsUV1_ModifyMesh_m4407B9AE1603556116C6352738769D00CDA11419,
	Shadow__ctor_m776322C362BCFCD3EF098209CE8D98C32772E52A,
	Shadow_get_effectColor_mC7BF6CDDEC9998A03E993ED9216092782C66EC16,
	Shadow_set_effectColor_mB590179B73124FC979887516F9D8773BE7A6B776,
	Shadow_get_effectDistance_m4B496C7CE07930847630E0E636E3C255D78B08BB,
	Shadow_set_effectDistance_m06F578865EBE71228AE60DD7E8D1B10DE4589F8E,
	Shadow_get_useGraphicAlpha_mC1F216671CC11DC92B9CCCC6AE884A1A2D30AE3E,
	Shadow_set_useGraphicAlpha_m700B8D7D0DD8726B36D415997B123E275B83D6C4,
	Shadow_ApplyShadowZeroAlloc_mE8BF57D4B5976303B5A5516E893A7DEFFE38675F,
	Shadow_ApplyShadow_mAF02B8482E4012D667AE5326C4DB4B1FEAFFA39D,
	Shadow_ModifyMesh_m8C99018A8D5D3652249C7C6DC0E9E7AD0CA5BC0C,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	ColorTween_get_startColor_mA979B663DFD611DAC95F4A7B98AA36E24EE5E3D6,
	ColorTween_set_startColor_mD976BED0C47332CB811EA6B68230FFAB69DCE82D,
	ColorTween_get_targetColor_m2620FDCF03617764286DCDF8000AA3BE59C9E7AF,
	ColorTween_set_targetColor_m9BA400CD92F2182DFEDEA4494B66501C7596DD69,
	ColorTween_get_tweenMode_m908DEFB153497AC18AD08CB73AFF655C1F6D05FB,
	ColorTween_set_tweenMode_m88B5C1FA53770422C80E61B0958CA7B94E6D8B27,
	ColorTween_get_duration_mC4A1E3C2EA46A5C657A2B9DA240C796F770ECC5F,
	ColorTween_set_duration_m069BFDD0F6EABA4869ABC1F4620C54F749950E3D,
	ColorTween_get_ignoreTimeScale_m6A06826E19314EFE9783E505C75CFC76E42E8F05,
	ColorTween_set_ignoreTimeScale_m42071C6EB064666F7FF945EEC5B5261836E8E593,
	ColorTween_TweenValue_m20FCBA50CE9328956973861A9CB0A1FD97265A58,
	ColorTween_AddOnChangedCallback_m8B7B35D5B912C0BCEFB275B54A3A2EB8D1DD7DE8,
	ColorTween_GetIgnoreTimescale_m5100D5725C73E6DB3718A2CF33C9CB46CA27731E,
	ColorTween_GetDuration_m327EABA3FBCD9635DCD360834176D3AEDBFA88B0,
	ColorTween_ValidTarget_mCFF8428CFF8D45A85E4EE612263E751ED0B5987C,
	FloatTween_get_startValue_m6DC736717E2EAD27CE41A6CD292B6D28AE1DED1E,
	FloatTween_set_startValue_m34ECE8005F47D60A3F5AF976FF28881A2200B549,
	FloatTween_get_targetValue_m15E266DEA747D1DD8F49681E9E6AFD7FADBEB027,
	FloatTween_set_targetValue_m04567CCFC5510BA34D68C7A2C4AE32D400D59C3E,
	FloatTween_get_duration_mBECFBEC57BDC30B54D0638873BA3313A8F7232F5,
	FloatTween_set_duration_m7E3C3B6D6F9D1C5D9AE051ED64915029E8B4F094,
	FloatTween_get_ignoreTimeScale_mA7B69D72E1D52EF1890C89D5690D345B852C7239,
	FloatTween_set_ignoreTimeScale_m6826FE67438AA7F1E4ECB85EC83812BC2F6F092B,
	FloatTween_TweenValue_m4E4418FB7FBDC7CBF96D95518DFACF25BCBE8EB3,
	FloatTween_AddOnChangedCallback_m56955D43A7CDE997CE447A1C69CA708E8190E9AE,
	FloatTween_GetIgnoreTimescale_mB93B6C1BAD120F59F58DFE9409A64DE3A4790D88,
	FloatTween_GetDuration_m81D2D1E8D8AEDFDF03B54F1AF71A74824480B178,
	FloatTween_ValidTarget_m917EB0D30E72AC75D90D1D8F11B1D7EBBD00ECAE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	AxisEventData_get_moveVector_mCB9151FF8AFE8DC43886E715AD4B9932644DC171,
	AxisEventData_set_moveVector_m355ADAD19DE3EA67459EAE40FAEAEBE93414FEA3,
	AxisEventData_get_moveDir_mD9CF8343509BAE60C581138D824F9C53659DBBD4,
	AxisEventData_set_moveDir_mD16579255C9B76717A3B349BCFBB371044E23EFA,
	AxisEventData__ctor_m6854820EBB8321AD2472069A2D55A2242D0A51B1,
	AbstractEventData_Reset_mFD0C0918347F74594FE8C791C5A939FEB953308D,
	AbstractEventData_Use_mB892C2F5FE39571FAFFB247C795233438B15A17B,
	AbstractEventData_get_used_mC9500818C43B1C96B532F4D5DF316D25ADC1CACA,
	AbstractEventData__ctor_mD80BC34325B6235E48E02789647C69D4F283434E,
	BaseEventData__ctor_mA58C6566C43F8624C85203FAE2B27528C584675E,
	BaseEventData_get_currentInputModule_m0887B0CB20374A4AA10D4C1B480E305581533512,
	BaseEventData_get_selectedObject_m234C3A09897246D2BF97D43017C9AE476BD91770,
	BaseEventData_set_selectedObject_mE98E9692C6A7AF46D33C625CEAFDF56AFEE5FEA3,
	PointerEventData_get_pointerEnter_m47E87ACB1557B6380D0E66F57C2F9FFFD5E86DC2,
	PointerEventData_set_pointerEnter_mB891C530B173BCDF4FDD5CC757A30AE498D77360,
	PointerEventData_get_lastPress_m6B005D786FC5B30ECD8D5BC068420D0C361357F4,
	PointerEventData_set_lastPress_m0E97AFEEB05C4DDEDA0465481CFE09EFDF617319,
	PointerEventData_get_rawPointerPress_m6CECEFBAD7C50F04BD65172000B0BB916578B494,
	PointerEventData_set_rawPointerPress_mEBAE6DDF7485B81E092BDE13462926FB5C251BB2,
	PointerEventData_get_pointerDrag_m20299CC70BC6DA11AFDB8A33A957AC306FBEE5C7,
	PointerEventData_set_pointerDrag_mAA21AD97ABF508FD1D2313C36CAEF3A969F1D35D,
	PointerEventData_get_pointerCurrentRaycast_mE58F786484E13AF2E6C2706E20C889E7453E3A7A,
	PointerEventData_set_pointerCurrentRaycast_mA63CA749AC5410AF7D28F4C924BA3372E12F61FC,
	PointerEventData_get_pointerPressRaycast_m722BCA823E0405C9DF20312CDFBBEB5B1B05B7AE,
	PointerEventData_set_pointerPressRaycast_m2F371C6E5AB2AAB39C6F7F889594D480D797D5FD,
	PointerEventData_get_eligibleForClick_m2DAAE590F749D77C50A3665B848B6F778518E29A,
	PointerEventData_set_eligibleForClick_m40B82588BC83E4CF72209B9B1A50585CCE82ABD2,
	PointerEventData_get_pointerId_mD351BA661F70CDBB48AA5E80496179069E620D97,
	PointerEventData_set_pointerId_m078CD15662E127124C86C88ACB3C5B44E61F1A54,
	PointerEventData_get_position_mF25FC495A9C968C65BF34B5984616CBFB6332D55,
	PointerEventData_set_position_m9BDCBF26C28C01F781ACB8FC87448CB4ADD0BBD5,
	PointerEventData_get_delta_mC5D62E985D40A7708316C6E07B699B96D9C8184E,
	PointerEventData_set_delta_mC9CBC11B2F8147F7E94590769271297EE018682F,
	PointerEventData_get_pressPosition_m7C8D5A54C81C801EB577A60718C4211DFA1A3624,
	PointerEventData_set_pressPosition_m3F5805FAD17E1BC44B84795506DE7EBA7215A46C,
	PointerEventData_get_worldPosition_mF0DC1B57F31BB6FB8FFDD666603FF0909940EFA8,
	PointerEventData_set_worldPosition_m69BBE1250B8D37869B056EDD7FE6DED1A5B8438E,
	PointerEventData_get_worldNormal_m310D7AC52A1EBD88080267B39ADA66A6EC778D26,
	PointerEventData_set_worldNormal_mA59C3E7AA9F72E8484C51AB6F276EE53AA7CEF49,
	PointerEventData_get_clickTime_m22DF8D2239FF9E101B69E3C27710B3512328BBF3,
	PointerEventData_set_clickTime_m65041A6875D4A8091A0F7195D8E3D11F1DE49FFD,
	PointerEventData_get_clickCount_m171A2D241BD02AC43908420497688C5B354BF6E9,
	PointerEventData_set_clickCount_mE77013E6A569F7BE54306B6AE6DE6B24396789F0,
	PointerEventData_get_scrollDelta_mF473A122C860EC5279F6F5D085912BDA6418690B,
	PointerEventData_set_scrollDelta_mC28D770F77171619EADE3FADA463866F6E4F3733,
	PointerEventData_get_useDragThreshold_mD34A3546D654B48F02FA3920DBEC208891257482,
	PointerEventData_set_useDragThreshold_mB742BB006F245766C00371FF33B680FF3F0F48F1,
	PointerEventData_get_dragging_mDB8CAFA859F6B7AC6EABAE340FA047BC2620927F,
	PointerEventData_set_dragging_m34110A723023758249425A1F3C98EFA27BF19F45,
	PointerEventData_get_button_mC662D5DAC02F0ED6AE9205259116CC91BB92BD3E,
	PointerEventData_set_button_m240561B7D92B4AD898CDBD887828B48BBDD0DD2A,
	PointerEventData__ctor_m121A903CE81C0758A49C721F7C1668362BFAE7E4,
	PointerEventData_IsPointerMoving_m898C7306913917BFE04B3CF7A7A463EE94979D68,
	PointerEventData_IsScrolling_m47CCF26BC0D686E601614A08253EDA068B7690B3,
	PointerEventData_get_enterEventCamera_m4DCBA203F50F1F4D30118573061FD4634D4B4915,
	PointerEventData_get_pressEventCamera_mC505603722C7C3CBEE8C56029C2CA6C5CC769E76,
	PointerEventData_get_pointerPress_m7B8C9E16E2B9E86C4DA93A2A2E3A58E56536406B,
	PointerEventData_set_pointerPress_m053AF3BF19752D9271AAC6A633B2718C61870D33,
	PointerEventData_ToString_mFFD67D75B8BC560CBFE5E4D417D7F44124493991,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	EventSystem_get_current_m3151477735829089F66A3E46AD6DAB14CFDDE7BD,
	EventSystem_set_current_mB077A890E5CB75D7987793733E17B95F12AF006E,
	EventSystem_get_sendNavigationEvents_m0DB01018B4EF41A51D0AD481DD07F381ED2223DF,
	EventSystem_set_sendNavigationEvents_m64D25EBFE249DB5A9DC1B285321B92880B8EC75D,
	EventSystem_get_pixelDragThreshold_mE7B5BD351A7B6CD3881D212B84351F23C54AC724,
	EventSystem_set_pixelDragThreshold_mD5A11B879BA7EEFE0B4F91E0CED2AC59799E10D5,
	EventSystem_get_currentInputModule_mAA917C940E32ECAC4324D6824A9E0A951F16D891,
	EventSystem_get_firstSelectedGameObject_m8CAFDA874F89BDA34E0984860046C1C171B200E1,
	EventSystem_set_firstSelectedGameObject_m27C825634467206443B41E4D133DBCE4E4A31EAE,
	EventSystem_get_currentSelectedGameObject_mE28E78D268403602DE1FB6F059EE3E9CDB7325A4,
	EventSystem_get_lastSelectedGameObject_m761188B5E33641891010B7BBBEEDDB1F267A6A29,
	EventSystem_get_isFocused_m421DE003FCADF582AF1D7F0B8B036513E9743294,
	EventSystem__ctor_mC74FA56B3E82BA853040EEE86272224F686C13F1,
	EventSystem_UpdateModules_mF34D9E9C84AE5FF0968292C4E3390AD0AB89DBA9,
	EventSystem_get_alreadySelecting_mEDDA8DD718BFE62CCE2520CE17304B7EC80CE9B2,
	EventSystem_SetSelectedGameObject_m3347D67C1A6386E6D7AF89773DC2960953B9C702,
	EventSystem_get_baseEventDataCache_m2B14076E5EF918BE1A94F16DE1A827AC1401BC89,
	EventSystem_SetSelectedGameObject_mF38F3DE62EC3450270C3053C9EBAB425550B07A0,
	EventSystem_RaycastComparer_mBB4C501E79DC58EABE34056EEB4A56843DEA6AB3,
	EventSystem_RaycastAll_mF78E1781C8161DEEF24B6B3FCCC1037787F9A439,
	EventSystem_IsPointerOverGameObject_mA47031510BEEA565F5892CC04ACE303804BD7631,
	EventSystem_IsPointerOverGameObject_m00CDF0FF5EA712D14B7966DD8270931A13EABA91,
	EventSystem_OnEnable_mB3C6CDEC37085FFB96914A768A444B2A97BC891E,
	EventSystem_OnDisable_mF4AB795E6BBF4DD6EDA359E954F04D8498B707C0,
	EventSystem_TickModules_m7C60756590E96EBA52FEA961ED6F3548E40C9231,
	EventSystem_OnApplicationFocus_mEAB25CFE6171088D62CAA9BE8697B9E24FE5B7F8,
	EventSystem_Update_m12CAEF521A10D406D1A6EA01E00DD851683C7208,
	EventSystem_ChangeEventModule_m4A3010299F57C492A10AABF29568BC2CD6185DE6,
	EventSystem_ToString_m3BA75E77167F875764A87DE354FA4E7F57452F8E,
	EventSystem__cctor_mBE0C93B74BB6A494F3E0A52CF9DFA06795C04649,
	EventTrigger_get_delegates_m481E829B584E900AED42FF84647DB48EECD65AEC,
	EventTrigger_set_delegates_mC1312F8132D21C5E517EA38677B1C65680F486CD,
	EventTrigger__ctor_m73D31D2C96C8A96300D462E6BD864529E7411F78,
	EventTrigger_get_triggers_mC7BC90E3D01E4107C3BCA70DC6B1E11E5BCDBB40,
	EventTrigger_set_triggers_mC0AB6B03331A1D1E51AB9C0457DA7A4C3006DFEA,
	EventTrigger_Execute_m92E8047B596BC17676C740C5FDB8F737A7FFF0B7,
	EventTrigger_OnPointerEnter_m87C0E1EED47AD32E9431AA5A5FFE5711E005AD02,
	EventTrigger_OnPointerExit_m11160DE36D06FD05397916242A3EA0BE6C13E9AA,
	EventTrigger_OnDrag_mA652B1ECA52E24F78C30946EAA553A9F7FE06C84,
	EventTrigger_OnDrop_mD71D70D5754646A0282AE1725139D61D2CEB2219,
	EventTrigger_OnPointerDown_m4860D9041126B46ABE6EADCC1267DA58806056F6,
	EventTrigger_OnPointerUp_m23AF1FFE2A5CA913602895E319FF338AEBC4A70B,
	EventTrigger_OnPointerClick_m5862B8B10A07AAD930F554B1B08F6B0ACBBA552A,
	EventTrigger_OnSelect_m3CF793D81A2A45E3A5324D57FB93F12C4144E344,
	EventTrigger_OnDeselect_m14E6CBAE7884FFF19688722EE0762D5C479BA9C7,
	EventTrigger_OnScroll_m049CE9599C751C0C2C571DB33A0449636982029A,
	EventTrigger_OnMove_m6B457F494B0EA1B5CE6175610B98984D7A54A26D,
	EventTrigger_OnUpdateSelected_m6F065ADE4F9F5CE823D8E59C5B1FB98A262351E1,
	EventTrigger_OnInitializePotentialDrag_m133B4AB3DFC9A5DB7F4DD3754481CCA8D12962F8,
	EventTrigger_OnBeginDrag_m6490661EB3B73834B141F1CE27E11AF2683083BC,
	EventTrigger_OnEndDrag_m1D5E2CFD8FC9CCBE29EF95B3CE93C306D9BDE960,
	EventTrigger_OnSubmit_mAAC2057B87AA87005AE4EAEE24D72AFD12AAB861,
	EventTrigger_OnCancel_m0F73AD82791AC96D815215FDDE33FFE4D1AC85C0,
	NULL,
	ExecuteEvents_Execute_m8C29CBED5B91CAD66E8D07CC11888DFCAFB6A8C1,
	ExecuteEvents_Execute_mA09B43D4EA5330792B77CC2B0CFBEA06A57EA489,
	ExecuteEvents_Execute_mE604FE0C916D5B3418A30A7B18306DEE7DF10097,
	ExecuteEvents_Execute_mF019AE64D09B592293ECE5537030CDF5961D7366,
	ExecuteEvents_Execute_m24768528CCF25F4ADB0E66538ABF950C8EE2E9B0,
	ExecuteEvents_Execute_m7F9A4B2EC9FA8F9F8BBF628E9C8D87587A0BEC98,
	ExecuteEvents_Execute_m31B26038791B68FE23D77DCAC81A550D53575EDA,
	ExecuteEvents_Execute_m49C3D013D962BE7E16C2E92608FFCC7C9E5303F0,
	ExecuteEvents_Execute_mE1EDD9426C52F61B04E53838FFFC0C85ADE5832A,
	ExecuteEvents_Execute_m6CE9E8ECBC0242714839AD54F32974AF36D273FE,
	ExecuteEvents_Execute_mF0BD313BC5A34C5BC0DB806AFA3D59F2757ADDF1,
	ExecuteEvents_Execute_m954DCF87A2B6CBF6FEB9B676500EA148F69B20FC,
	ExecuteEvents_Execute_mE52644D5E736A355F742C46C1C6C888559EA87D5,
	ExecuteEvents_Execute_m43A103804A0A03E85B931F982D8B86A3B6734BC9,
	ExecuteEvents_Execute_mE1DC393C080EA6FC93D0D3E25217AF69FD29E26E,
	ExecuteEvents_Execute_m22ADACB5A0899E5FEA1846D4084F2C7F78292BC8,
	ExecuteEvents_Execute_mF6CE7B6F06A92AE4208A2E6E9B842F7A991A79A0,
	ExecuteEvents_get_pointerEnterHandler_mFD5296E38EB1C5EB6D16CB83913430FEEBF889A5,
	ExecuteEvents_get_pointerExitHandler_mE5EC9537676A055EEE178A4E6B58D96F9B4AC301,
	ExecuteEvents_get_pointerDownHandler_m8AE9CA906C86BBBEB75BA2D05F5DAB01F62519E3,
	ExecuteEvents_get_pointerUpHandler_m7EDDD1128DC04344CECEBCB9B6B7CD064F7FAED2,
	ExecuteEvents_get_pointerClickHandler_mA657195AEC7D0A42036CBCAC9AD48F215C3C69E3,
	ExecuteEvents_get_initializePotentialDrag_m5B3D899EB08DA227EFBFC67778DDB98D7505C6D4,
	ExecuteEvents_get_beginDragHandler_m7F238765714F73899EAFDF0BA203D9A8A57AED31,
	ExecuteEvents_get_dragHandler_m41B7D77771806788CD773C83C2E5A53D5ED5B179,
	ExecuteEvents_get_endDragHandler_m23B60D3E3873043263069A3C3145393475690769,
	ExecuteEvents_get_dropHandler_mC2362B96C6CD3628B83722F4B7C73E707C6C1EAF,
	ExecuteEvents_get_scrollHandler_m48E5B17388986BD59EC7A7BF27E3D30A9FD057F7,
	ExecuteEvents_get_updateSelectedHandler_mE18DBB058B1EDC75D4F690A1E35003749BBC0567,
	ExecuteEvents_get_selectHandler_m26186C0D78CA4A8AFA0789A09F488F7E186BE1C8,
	ExecuteEvents_get_deselectHandler_mEAA9E3701CC972EFDD20B30E9B3CD9302B2FD668,
	ExecuteEvents_get_moveHandler_m113A4222FC10723B2E38398E182C02F6624D6F24,
	ExecuteEvents_get_submitHandler_m734C2BE2F7CDA7F5C42897E3C8023D3C7E1EDF88,
	ExecuteEvents_get_cancelHandler_m5DB4A9513FB8B9248AE555F7D8E8043175B8D995,
	ExecuteEvents_GetEventChain_m27DBBF6D0FE769C131AB96781E9BFFEDA545F155,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	ExecuteEvents__cctor_m1F04FDEC642AA1676F07BF0863D7F25530477378,
	BaseInput_get_compositionString_m9DC95F28875FFB09CD8B1FC080B916BB6F9F976E,
	BaseInput_get_imeCompositionMode_mC26A90D1DDE30CEE508412D8F1FEA5AD37671DA8,
	BaseInput_set_imeCompositionMode_m1FD535BFD2D74C77DA7D0D0332114913CBA1C135,
	BaseInput_get_compositionCursorPos_m08E6856B2A7240E1FEF880323757BDF8A4917046,
	BaseInput_set_compositionCursorPos_mF2EAEC3ADCB2E035CC6A0ECCA932BBED50B427DD,
	BaseInput_get_mousePresent_mEE423E6330086DF0B673E700381CD4AA57A8181F,
	BaseInput_GetMouseButtonDown_m670DD4F91F0C9D697BAA92B89B45D6458D8A86AD,
	BaseInput_GetMouseButtonUp_mA793A56A84790D6CAF523A0C611A7AF527CBE4B8,
	BaseInput_GetMouseButton_m8CBB85496076E5E0A6B47B28C07E096C4BD751DA,
	BaseInput_get_mousePosition_m020D1FB7D27B45D19303B7B9E05038F2C7DA02ED,
	BaseInput_get_mouseScrollDelta_mBF6C6F5DD4C626413DEB5081A34D58C2F178389F,
	BaseInput_get_touchSupported_mAD828BCFAAC2647C27C21971D0E51A3415CE9F9D,
	BaseInput_get_touchCount_mDF25D855BCD418823ED1E0CA96455EC28A684AB5,
	BaseInput_GetTouch_mC6D307829A73C58B16FA7D06928BE8D3528796DD,
	BaseInput_GetAxisRaw_mEC8AE52DA69BAAF0CA88EFBDB93A7B2BEDE607F1,
	BaseInput_GetButtonDown_m41F5626DD501ECFA5348918F63C20A9649E8F862,
	BaseInput__ctor_m097A1D35CC42538881FAF0E45AFF6FB974377F19,
	BaseInputModule_get_input_m385A99609A705346D5288D047EE17374ED406BE7,
	BaseInputModule_get_inputOverride_m3C63C410A33009ACB7EAFB776066F734110391B8,
	BaseInputModule_set_inputOverride_mC8698C7F93A5E54139938F0D2E6447CEA08779CA,
	BaseInputModule_get_eventSystem_mEF6DEC17FF56D786AA217A52FCCFE8C6F38546BE,
	BaseInputModule_OnEnable_mFCB40D263C78C819D0F1A17B5679662DD31245A4,
	BaseInputModule_OnDisable_m4E5FE43DDC5E6471DAAD8435D20E9F684E5FE6CE,
	NULL,
	BaseInputModule_FindFirstRaycast_m8688F6932686AD7A5910C912787ED4239A70CD57,
	BaseInputModule_DetermineMoveDirection_mFF256A4F65F2B3E650E232F70C1B05F46DF181F2,
	BaseInputModule_DetermineMoveDirection_mD3EE701CE69F63DEBBF2B9D3FB62F550A4DAD8D8,
	BaseInputModule_FindCommonRoot_m1995190ADC1341F180811C5213F1CA522B6282A5,
	BaseInputModule_HandlePointerExitAndEnter_mFA61D8BA9B2377B56E3844CE8E3C15DF4C1959CB,
	BaseInputModule_GetAxisEventData_m2D7FF7016AC9AA5042343C19FF2CE5A33CF351F9,
	BaseInputModule_GetBaseEventData_mB945B5DF7A5C2B825C7D542D944A7795D8F5F93F,
	BaseInputModule_IsPointerOverGameObject_mEEDB14B0E8930015C4DC60A4AA362F71C07F95AF,
	BaseInputModule_ShouldActivateModule_m8EB1E427EFD3E7AC2341EE52DE4E51FD8D6EF548,
	BaseInputModule_DeactivateModule_m83781CF60B00AD9DA46E96D72321C4983EFA85FF,
	BaseInputModule_ActivateModule_m83647D8599561B6CA562F24EA7088E37DAC2AD29,
	BaseInputModule_UpdateModule_mD72D1FB1F26A50F07144B74397831EB6691F3F65,
	BaseInputModule_IsModuleSupported_m219E09AAE063439B142750898517669B36510EF0,
	BaseInputModule__ctor_m8F78B6153670F05181D1B348C4259C45DCF4C231,
	PointerInputModule_GetPointerData_mF40B733CA91DCC168F7417BD9C264D21F82C2E94,
	PointerInputModule_RemovePointerData_m17E63DD11FE440D4D88078B4895137C942C52C3A,
	PointerInputModule_GetTouchPointerEventData_m27D309E699986AE28F15FF944CCADC4EA2E9BC11,
	PointerInputModule_CopyFromTo_m33310425F20BE45DA17DA8E1E07FFE461F410F82,
	PointerInputModule_StateForMouseButton_m0B66950A94543E8F6D16AC6546E7009AEE0B8E2C,
	PointerInputModule_GetMousePointerEventData_mA8B6C810AE130118AA18CD4BD35F8F5BCE0D7E07,
	PointerInputModule_GetMousePointerEventData_mA6DE4DDE2C99B16D77DB3DD2F541C1DC23A18EB4,
	PointerInputModule_GetLastPointerEventData_mEC097EFC007EA8900D2346665F277C1E4A8D94BD,
	PointerInputModule_ShouldStartDrag_mA947D41C459516DE49CD25B0E856832956AEF02F,
	PointerInputModule_ProcessMove_mE19CAFF568799ED491CE71939D6EFD2535ACB0A5,
	PointerInputModule_ProcessDrag_m2A544286EF20A04D6E42FFCFD0F73DD89F9614A2,
	PointerInputModule_IsPointerOverGameObject_m559779A0E006BBB28F99A6AB59011FA397320B46,
	PointerInputModule_ClearSelection_m90CD812546D41142C4E9C599D7DD39A887F3F5C1,
	PointerInputModule_ToString_mF269BDD6927D4E4F92586120C558234BACE12BF8,
	PointerInputModule_DeselectIfSelectionChanged_mD24AB70C8C12903D513ABB8BAE132E707B0F0A70,
	PointerInputModule__ctor_m05A4A9E4BF8053B1444986BF3EB27D8007AE9275,
	StandaloneInputModule__ctor_m53DF966585A2888088BF07BB7DDE26BA84BA67D0,
	StandaloneInputModule_get_inputMode_m9E4FF00674C049A7F600D0CC5D278F474232B3D4,
	StandaloneInputModule_get_allowActivationOnMobileDevice_m761DA40A5C7688BB6F8EABD989D74B2239B8776E,
	StandaloneInputModule_set_allowActivationOnMobileDevice_m7E48DC59AE7F10E8ACCBC9A86E66E245B513413A,
	StandaloneInputModule_get_forceModuleActive_m7C481C9C4D478CB162E289F9D038859990973E6E,
	StandaloneInputModule_set_forceModuleActive_m41B816036BFFF624B371224005BA4D303B21F731,
	StandaloneInputModule_get_inputActionsPerSecond_mE25D1FE801046F322B862161B338A9719A4B87DD,
	StandaloneInputModule_set_inputActionsPerSecond_mD97110B0C4B4F72D6E2826BDDE28EDBB04323953,
	StandaloneInputModule_get_repeatDelay_m95DD446349C273DFC8E3ECB25DC83248E6955597,
	StandaloneInputModule_set_repeatDelay_mA45CBEB7D208DCD103CD7817F5B4691647F53B90,
	StandaloneInputModule_get_horizontalAxis_m7830DCFA78BDB86C6EB403D9B0A3AC6C2AEA202E,
	StandaloneInputModule_set_horizontalAxis_m261CC906B1304D6D9B0086AE1C552834AB6F1D59,
	StandaloneInputModule_get_verticalAxis_m1493EE2972D3244EEA8D94E0D145E8E43C6BDF0D,
	StandaloneInputModule_set_verticalAxis_m1E55CD609287D3DDA0289584C0FBDF9BAB891ABC,
	StandaloneInputModule_get_submitButton_mA466BE2B75CE6A39828DC3AB2E698F4BEE9EEDDF,
	StandaloneInputModule_set_submitButton_mFB2699D16EE8E72E814B1807F70FAF6FCBCD2B6D,
	StandaloneInputModule_get_cancelButton_m3FB17204BE25A393F920457C482A927AC216F1FE,
	StandaloneInputModule_set_cancelButton_m724FDEA363F0FFF56FBFD84AD8C1F4C57B67D2B9,
	StandaloneInputModule_ShouldIgnoreEventsOnNoFocus_mEE9196582563D3B4F864A3FDDC41B3AF058DE1E8,
	StandaloneInputModule_UpdateModule_m6BE8C301BEB10BD653F0D0EEB6522E3A8F3221BA,
	StandaloneInputModule_ReleaseMouse_mAB37571EEE6FE65733244890BE88FFF095DF8FED,
	StandaloneInputModule_IsModuleSupported_m44C18E994D6B97CDFBD841A9D7314B26B7AA340A,
	StandaloneInputModule_ShouldActivateModule_mEA1D4CC786377AD4A1A9EC035BCABA9AC32B48C5,
	StandaloneInputModule_ActivateModule_m75B8C7CF41074D98F23DBCBADBEC12204F101F04,
	StandaloneInputModule_DeactivateModule_m184C95BAB03E1AC58F7274A6CDDCDC70160301C3,
	StandaloneInputModule_Process_mF637455BCED017FB359E090B58F15C490EFD2B54,
	StandaloneInputModule_ProcessTouchEvents_m74C783AF0B4D517978ECCE3E8A1081F49D174F69,
	StandaloneInputModule_ProcessTouchPress_m46FBF040EAB0A0F8D832FEB600EF0B9C48E13F61,
	StandaloneInputModule_SendSubmitEventToSelectedObject_m29ACA510C925399B9D806ED171DA86E4F3A671E4,
	StandaloneInputModule_GetRawMoveVector_m36E309DADA8C0BB4CA0710FAABE0F4E9B77C2F6A,
	StandaloneInputModule_SendMoveEventToSelectedObject_mBD62EF30732300D347DA3D78B7473D6DCF15BC41,
	StandaloneInputModule_ProcessMouseEvent_m4CF90D3BE8DC50D135D42B31C70D3D2D30B47174,
	StandaloneInputModule_ForceAutoSelect_mD5FAA93BE3D2052F0138940C25148BF184DB0952,
	StandaloneInputModule_ProcessMouseEvent_mBC7F5E60430C4594852FB785035D8FE5EAD9FF99,
	StandaloneInputModule_SendUpdateEventToSelectedObject_m7180367BFB750772FECFBC7C621234B7FBF29C9D,
	StandaloneInputModule_ProcessMousePress_mEB96E70EDB025F2AA37FEF2063CE248AC735C16F,
	StandaloneInputModule_GetCurrentFocusedGameObject_mA354FCB4E2546E1F49D165207705A26D29EBB3D7,
	TouchInputModule__ctor_m4DA98CF8160474EEF5179225D9435497BE81D570,
	TouchInputModule_get_allowActivationOnStandalone_m5AF75CB4497AD94C5EDC08571D5B26AAA4FDEC21,
	TouchInputModule_set_allowActivationOnStandalone_m03444533ACC4BC73EBDD50489D1ECB99C0C780D0,
	TouchInputModule_get_forceModuleActive_m3DBB16E0B71B7567515CBE0089A91EF4A0B344C3,
	TouchInputModule_set_forceModuleActive_m28F890F6675872621907FE867414D4DBDBDD9EB8,
	TouchInputModule_UpdateModule_mCA26D9F764562DCBA511D947B1892AD93F5AF863,
	TouchInputModule_IsModuleSupported_mE4B9FD3BA7947F9B783B8BC44CFE8537F8D25155,
	TouchInputModule_ShouldActivateModule_mA6B7B00937F0100D53F9F2D8C71CE288E292E071,
	TouchInputModule_UseFakeInput_m2406557FC685547C9245C1052A1DF2B7D8AE0919,
	TouchInputModule_Process_m69909AB21CAA13E21A6C3E8723D168C55AB57C7D,
	TouchInputModule_FakeTouches_m660D98593231941BBFB9C9A6D52F3F68C20A1731,
	TouchInputModule_ProcessTouchEvents_m2A417627C700B7BAE40700BEBC9A55D325A07A50,
	TouchInputModule_ProcessTouchPress_m82D82ECA10567F5BC60F004814EECC7A09914FD6,
	TouchInputModule_DeactivateModule_m0B4D1B126C28668E2F6AAC08544CBAB93C086734,
	TouchInputModule_ToString_m33D845D0F7EB0AC832050B3B582010E7173741CC,
	RaycastResult_get_gameObject_m9D77DEDFF498BAFE29A5F88E9F238400D04C8FDD,
	RaycastResult_set_gameObject_m4EB676328BEC6E2C3A2AFBA4B405CEDDEAEBBFFA,
	RaycastResult_get_isValid_m2F2241EF619EFFC0F609FAA35D4C64455712DE47,
	RaycastResult_Clear_mDC3D08DD775DA02145E5AF6FE62465EBACEB4AAB,
	RaycastResult_ToString_m0EE4380602D2025F27DB18ABE887E9CC7C39BB5B,
	RaycasterManager_AddRaycaster_mE3A5D2AA12657F81E20AF477E084ED4C11E62A0F,
	RaycasterManager_GetRaycasters_m3088F1DFEEDD695546B8CC290E34FD6093CD264D,
	RaycasterManager_RemoveRaycasters_mF59A19B82C1D199DB38350293C5CAD6F92EBA1EE,
	RaycasterManager__cctor_mA898971B12280C6EA2064755CB72B2B714E63918,
	NULL,
	NULL,
	BaseRaycaster_get_priority_m711033A670FA9C2DD43A249A66FA6AEFEC9873F0,
	BaseRaycaster_get_sortOrderPriority_m771068D9ED43707FEAFC054488B3F661DF97222C,
	BaseRaycaster_get_renderOrderPriority_m3627528E3042A9101E5820E892C8D7F30084E1E6,
	BaseRaycaster_get_rootRaycaster_m4DF6B023C195A4E8E9AF8D8E411379A9052D80A5,
	BaseRaycaster_ToString_m96F781EB5818707A7904AC3F061E5AAFE37F7DB5,
	BaseRaycaster_OnEnable_mE000A849F5B40F1059DBFDA84C7743E9467B0ADA,
	BaseRaycaster_OnDisable_m83ED4E74E23400DCEE2DCEDBF85B96720725F5D7,
	BaseRaycaster_OnCanvasHierarchyChanged_m1962CEE13C1E14C31A01B0A88157245364D322F8,
	BaseRaycaster_OnTransformParentChanged_mC50B4405C2923E2B16247C1C85F5200CA3117539,
	BaseRaycaster__ctor_mBD29DEB1B35BFC380759759DB78A5C9B8F695048,
	Physics2DRaycaster__ctor_mDD17B4E09EB91C114786BBAEC903BA49871C4EA3,
	Physics2DRaycaster_Raycast_m8EE96E1D1C1C118DA04FF279BC0555ED7BE29D41,
	PhysicsRaycaster__ctor_mE6B5EB334DE25F1DE5725599B3A990C8D5A54F70,
	PhysicsRaycaster_get_eventCamera_mA4D0809E09657E6B635FF54EA8178CA5280C297E,
	PhysicsRaycaster_get_depth_mE0E914B9A592003FF8CCCC84D285AD44BA93545B,
	PhysicsRaycaster_get_finalEventMask_m635B6C7C9CFA5B94FF623AC31044C57DDE0E6C2F,
	PhysicsRaycaster_get_eventMask_m11D96704635B15FCD194B02B421807362676BE98,
	PhysicsRaycaster_set_eventMask_mE4ADA4A1183945002A910222C1FA03314238ABD6,
	PhysicsRaycaster_get_maxRayIntersections_m731D62B45F87B97DCBBE0DA728B8653E64995ABF,
	PhysicsRaycaster_set_maxRayIntersections_mA3D5632E679F880AEA21E74148FB9E315FB69D3A,
	PhysicsRaycaster_ComputeRayAndDistance_m3304D9B85EDCE08A7BC0F3EF435A5A36B2AE3026,
	PhysicsRaycaster_Raycast_mD390972E28043DD58583BC8B25ADC7C1BAD71CCC,
	UIBehaviour_Awake_m5DD9E48E9933AA28DAE1978B5FCC6B90BAF06FDC,
	UIBehaviour_OnEnable_mC9822F55BFE331807411109DA82D6AE5EF46E2C2,
	UIBehaviour_Start_mCF174BFBADA4B5806DD4FFF75984F1526AAF3884,
	UIBehaviour_OnDisable_mDA7B89CA939C50BD6F81CC350C2969755B1576A0,
	UIBehaviour_OnDestroy_mAC124B1C2131BDD6B17D70DB2A90632A2355F498,
	UIBehaviour_IsActive_m9B5E4BBBFB0037F29906ADEEA6F9FD42BEC6B64C,
	UIBehaviour_OnRectTransformDimensionsChange_m502F3C94E797FCA4C837036E3931118E5F713483,
	UIBehaviour_OnBeforeTransformParentChanged_m68E4722715DFFFBCF5E60258B0F72B29AF37F957,
	UIBehaviour_OnTransformParentChanged_m94918707543A748636155588EAE7D50A471D9EDE,
	UIBehaviour_OnDidApplyAnimationProperties_m843205FEEE8B64554A393E916AC9D5CC2CFFE8CB,
	UIBehaviour_OnCanvasGroupChanged_m199FB773259086C18FA2481F4EE7BDB7C3A14023,
	UIBehaviour_OnCanvasHierarchyChanged_m63F9F4A5B982D0417EEDCB780B12EC0946A68FB5,
	UIBehaviour_IsDestroyed_mFBB1C4329F14CC34D7B0351E21D8419FFB4BA01B,
	UIBehaviour__ctor_m270FFBC65602196134042BD4E24DB093883A1BAF,
	ButtonClickedEvent__ctor_m95CE43990A021F7E01F4697B71ABF3E73D6BD03B,
	U3COnFinishSubmitU3Ed__9__ctor_mBCBD6B7B3BDB9E9146CD76D7D64E3F2900E04247,
	U3COnFinishSubmitU3Ed__9_System_IDisposable_Dispose_mA0AACD4958863BC4C20A97FB14B641922EDBE52F,
	U3COnFinishSubmitU3Ed__9_MoveNext_m12F9C4E3C7FBDEB24B399B7E6935BC5E18856ED8,
	U3COnFinishSubmitU3Ed__9_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m8FC4B943F2051EFD53EADACDAD40C776ED503DE3,
	U3COnFinishSubmitU3Ed__9_System_Collections_IEnumerator_Reset_m9A8F55E44A8F5C19F6F4C1B7648F139895665425,
	U3COnFinishSubmitU3Ed__9_System_Collections_IEnumerator_get_Current_m018D3968294D5F3F16924C7F53120C49474A9B97,
	NULL,
	DefaultRuntimeFactory_CreateGameObject_mEF7A906B56039410AAAE4F069426883DC028B7EB,
	DefaultRuntimeFactory__ctor_mA26CD855B0C0BDDA991CB78A064EA63A736B01F0,
	DefaultRuntimeFactory__cctor_mE1EF2B3D2BB81BEC3BC4A4C058C835407C044A83,
	DropdownItem_get_text_mABB014D2DEE9F6B24515DE71A08EBFA82BB44829,
	DropdownItem_set_text_m13D42A003AF95D99F2327E23532986F9FA1F0ABE,
	DropdownItem_get_image_m2879EEFCAB097FBA79BC4DA41ECBA4EBE3CB6185,
	DropdownItem_set_image_m7C2A0990EF4FA55AA50A963A93A31E0F28189766,
	DropdownItem_get_rectTransform_mADBE4D843FE38C832CC1C9CFE03DC4D55B18E897,
	DropdownItem_set_rectTransform_m68DE1182C56F9C18124E9D2E7304879865B053C9,
	DropdownItem_get_toggle_m6DAC29FD2E711343DBCDF240B3218BD6211886DE,
	DropdownItem_set_toggle_m0EBE6629833FE4C6971885403B74CA15278BC0C9,
	DropdownItem_OnPointerEnter_mC3E0428C434A3B627C94F704CDF7A0503A971DE1,
	DropdownItem_OnCancel_m401BE297715C14DA0AED4DB0258E8429A4142AED,
	DropdownItem__ctor_mD2D98375480B51AE8DC121299E662499ECA12EE6,
	OptionData_get_text_m2357EC665D55A54DDC6D7A150E2F74D95F915307,
	OptionData_set_text_m294B34165F072EEF65BEB4700D5F1484A52DC30B,
	OptionData_get_image_m0BF991D02528EE3C67FE841C3AA87EC1AE7D8E31,
	OptionData_set_image_mF1FE39AF9BFE87422D0030C785F8631389B18701,
	OptionData__ctor_m5FF808A9DC863C8D595D5F6BD2DBDC02112F1606,
	OptionData__ctor_m72F6900DD27A92731D7B1FA02623D50440D747C3,
	OptionData__ctor_m376A2D81849FC01F09CCD5AB71BFDB596485B0A2,
	OptionData__ctor_m708D83F2BCCA7CBC3A9984B6A09128B73356FD3B,
	OptionDataList_get_options_m3628E8C41BE97B1D4CB2B5C79CC127C5F6C82CCD,
	OptionDataList_set_options_mA01C00ADF9C913B4B1DB8B3FAA30F3D2DB31EF13,
	OptionDataList__ctor_mBD571B96180D97CDFDC446EE0E37ECFE76B3541A,
	DropdownEvent__ctor_m98DC282381C3C5B01E23CBCDC916E1E35913633C,
	U3CU3Ec__DisplayClass62_0__ctor_m5929C1C6009D2B9C3DDFDE80B361ACEE79669726,
	U3CU3Ec__DisplayClass62_0_U3CShowU3Eb__0_m4658CA3C921911277414F27C3DBB031C3785EE68,
	U3CDelayedDestroyDropdownListU3Ed__74__ctor_m03CEC81B3046E88B824CD2BB0C86501875B704C8,
	U3CDelayedDestroyDropdownListU3Ed__74_System_IDisposable_Dispose_m93DD3230976C08FB2FF178D6D95AFBF1C68A6563,
	U3CDelayedDestroyDropdownListU3Ed__74_MoveNext_mC00E6AFD4D66ACD103D5ED2C48122B62F15773AB,
	U3CDelayedDestroyDropdownListU3Ed__74_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m5C30CA041CD316D3253B9CB66B6BD6B701C4A4FE,
	U3CDelayedDestroyDropdownListU3Ed__74_System_Collections_IEnumerator_Reset_m74C17D4CEEEB9C55AB06699924515E8FF3A3F6EC,
	U3CDelayedDestroyDropdownListU3Ed__74_System_Collections_IEnumerator_get_Current_m1C2940A531BAB505629535360363D51C58DC412C,
	U3CU3Ec__cctor_m09851A52E0DB1A56F529BC8F005D78B94677D525,
	U3CU3Ec__ctor_m04E92901B8E801154B3722C9E5E31E905E673D83,
	U3CU3Ec_U3CRaycastU3Eb__24_0_mB64ADCF5E31DFA898FDE3C24BAA00F8721EE915F,
	OnValidateInput__ctor_mBB48714EA8D6CB0BF9C1CC4C5FAC4A3C0D919DA9,
	OnValidateInput_Invoke_m98D4EC458F62EA7382DCB4FB619BF6B8B8C9D986,
	OnValidateInput_BeginInvoke_m0677E0E8084057293B39096DB67622649E15B77B,
	OnValidateInput_EndInvoke_m827F78F46319A1CAECBA5B5633B681D50B0EE6DA,
	SubmitEvent__ctor_m74537089F141326776A8E753F7D9ED8BC97A7285,
	OnChangeEvent__ctor_m9CE6922AF1E2E023088FDB57C76172CFA7090165,
	U3CCaretBlinkU3Ed__161__ctor_mEE32F143BA27AA79DE5CBD24DE29E82E6E686F0B,
	U3CCaretBlinkU3Ed__161_System_IDisposable_Dispose_m98F4AA2B16FA9DFB7D6E4B8585539CC87A3922FF,
	U3CCaretBlinkU3Ed__161_MoveNext_m7466BE75DA87CF3583561D803D2F11175E388476,
	U3CCaretBlinkU3Ed__161_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m92F79A5BD86298B4D82B5CFD0459E471B631338D,
	U3CCaretBlinkU3Ed__161_System_Collections_IEnumerator_Reset_mF3537E69989F503BBE2B217E5B4AF1AD8F1E2D1E,
	U3CCaretBlinkU3Ed__161_System_Collections_IEnumerator_get_Current_m109EAA38605D487FB5DCA78EFFFC2B6FE5C7FD23,
	U3CMouseDragOutsideRectU3Ed__181__ctor_m5895816668E36FCF68396450F3A4B5275286AC8E,
	U3CMouseDragOutsideRectU3Ed__181_System_IDisposable_Dispose_mF021FCC22512C83D42703FE834AA2818C69B3483,
	U3CMouseDragOutsideRectU3Ed__181_MoveNext_m1FB4B9D529753BB151092B532DC53D115385D805,
	U3CMouseDragOutsideRectU3Ed__181_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mAFDC6F4B29255C18CC6C1DDD6545A0D20A7E5C40,
	U3CMouseDragOutsideRectU3Ed__181_System_Collections_IEnumerator_Reset_m5148663FAB05E421112373BAD77616EDB87FAE23,
	U3CMouseDragOutsideRectU3Ed__181_System_Collections_IEnumerator_get_Current_mC75B3F370A087B33E84851F4CB3D7909AC357ED1,
	U3CDelayedSetDirtyU3Ed__56__ctor_m529A39CB39042BBBE0EE03E4C8A3107229DC58C1,
	U3CDelayedSetDirtyU3Ed__56_System_IDisposable_Dispose_m70DD814B7FFBC17F3D9E3DACD96BFDB3457AF8BF,
	U3CDelayedSetDirtyU3Ed__56_MoveNext_m2781C1A3EE9B2EED7720D9968DF9A2CC42065359,
	U3CDelayedSetDirtyU3Ed__56_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m7737C45381E05C537F78B44351DCFCD4E81DB038,
	U3CDelayedSetDirtyU3Ed__56_System_Collections_IEnumerator_Reset_m1A72776AC2771716E1727638FF498FCDFFB8704A,
	U3CDelayedSetDirtyU3Ed__56_System_Collections_IEnumerator_get_Current_mCBF048846EEE3A89A3D52EEE0BEBAF8B9A4608F1,
	U3CU3Ec__cctor_mC1EA7386950FAEFA79F38DA008A1F42AEF1939CA,
	U3CU3Ec__ctor_m084320279C0D4A109E26ED227B59EE5549AC7173,
	U3CU3Ec_U3C_cctorU3Eb__5_0_mF2DD128E53E9561C0A2917EF9155E6A14246BD3D,
	U3CU3Ec_U3CStripDisabledBehavioursFromListU3Eb__10_0_m35B3C6C5477F634C10AEA30C9C2CE92FD230E0F8,
	U3CU3Ec_U3CRebuildU3Eb__12_0_mE1965E7B777527BBC12ED56BB35F88CAA996DCD8,
	U3CU3Ec_U3CRebuildU3Eb__12_1_m19527422BC1212F7965D5598BED02219A03AF933,
	U3CU3Ec_U3CRebuildU3Eb__12_2_m690D9E696A8EBA4A51C10493E370BEB9F45E83B3,
	U3CU3Ec_U3CRebuildU3Eb__12_3_m4A5765125712390B59375296E31ED10F214846AD,
	U3CU3Ec__cctor_mD80A5E583F0C1BAC67483C0D8BA610373CFBF0DD,
	U3CU3Ec__ctor_mCDA376F3170EEBBAA438CC23B7C179DC68C4D971,
	U3CU3Ec_U3CGetMinWidthU3Eb__3_0_m2069017629E7B6ED1B09384A06C8485297BF556A,
	U3CU3Ec_U3CGetPreferredWidthU3Eb__4_0_m83F4E2D085E2C69291FB65A85CB791D66E6D3CAC,
	U3CU3Ec_U3CGetPreferredWidthU3Eb__4_1_m721CC8A71D9AFD03BBF7895BFB96447FA3D979DF,
	U3CU3Ec_U3CGetFlexibleWidthU3Eb__5_0_m01ECFD6FA8A4ADF08229656881AED4A23916F31F,
	U3CU3Ec_U3CGetMinHeightU3Eb__6_0_mC491799C5F4CA7F6198F2EC054798A876D7DBBF8,
	U3CU3Ec_U3CGetPreferredHeightU3Eb__7_0_m09ED4C4B779BE9FEA5D8CCBBF0D9BC2332FDDAAC,
	U3CU3Ec_U3CGetPreferredHeightU3Eb__7_1_m5179206B47415CE24731EA3FFB9E2BF5DEF2E333,
	U3CU3Ec_U3CGetFlexibleHeightU3Eb__8_0_m7FDE30BEF1440F8F005B31F91BE3D9D3E6EC116E,
	CullStateChangedEvent__ctor_mA3A9152BAA97B289838CA14DA00507B77243CDF4,
	ScrollRectEvent__ctor_m826A11CD578D616068EFFE0DD61FC88F837B5FC8,
	ScrollEvent__ctor_mAFB20E7E36EB16E63F6521F87E1D8C35A61F8824,
	U3CClickRepeatU3Ed__58__ctor_m6AC874A97FA925E7488837001D30572626C2C49A,
	U3CClickRepeatU3Ed__58_System_IDisposable_Dispose_m1981D05AE9BC4E2CF928E606DBAFB10715B6EE19,
	U3CClickRepeatU3Ed__58_MoveNext_m2FB8B1CFC5FDE4173657F588C73C08666C34B9C7,
	U3CClickRepeatU3Ed__58_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m53369E7AD64C694A0FD93B61C12DBEF007FF6AAF,
	U3CClickRepeatU3Ed__58_System_Collections_IEnumerator_Reset_m65C1F2B932740F096DA508B30A1B97D5AE61C0DF,
	U3CClickRepeatU3Ed__58_System_Collections_IEnumerator_get_Current_mDD3F99EF8AFD5885DF27792CC6727F443354808A,
	SliderEvent__ctor_m219C5074B774908A83C9C54128370E75556A18E0,
	MatEntry__ctor_m1088ABC0B5320FB051D0F7036D1AEC006C48AD1B,
	ToggleEvent__ctor_mF58CC00AEC0CB149ACB267F0A885D814164B484C,
	U3CU3Ec__cctor_m89E177F13473C664F86CBB611035208949610E03,
	U3CU3Ec__ctor_m5F8E8E3F5E9EC721D150BB724313F4FD39798537,
	U3CU3Ec_U3CAnyTogglesOnU3Eb__12_0_m6759194C9A27BC7726498AEA91636DE01DB5946C,
	U3CU3Ec_U3CActiveTogglesU3Eb__13_0_m0FFD86D1B257988730B5BD85D42BD9E892FF37E5,
	Raycast3DCallback__ctor_mCB0759C0BFDAE7E4FCAE3BE3635DEF37A237F09A,
	Raycast3DCallback_Invoke_m96DCB0F99B7985CE4A213570BAA007F9C281D437,
	Raycast3DCallback_BeginInvoke_mF70380A191C13DA5AFD5617EF8E05D0166AB9193,
	Raycast3DCallback_EndInvoke_mD10DFF1413244239AEA66792FF0FDC14076F7E99,
	RaycastAllCallback__ctor_m1124C55632F15FE52408AB3760D9516CFECBFC19,
	RaycastAllCallback_Invoke_mA25988726DFF992942D7F9753C8B38AAF06408E9,
	RaycastAllCallback_BeginInvoke_mF3B3CE2228DAC1D6139A7E6A37CF58C1763E8E53,
	RaycastAllCallback_EndInvoke_mD35715DAD2F11C5EF0FE134586A10A0615D65E9C,
	GetRaycastNonAllocCallback__ctor_m63DAC81049B9F7C8527A85094FD9FB19ADDD043A,
	GetRaycastNonAllocCallback_Invoke_mC5C9CC9CC617A89C284D1DE7DD297A2E3D9E4163,
	GetRaycastNonAllocCallback_BeginInvoke_mA840990486DEAB55DF085B0838CC40778B23AAD0,
	GetRaycastNonAllocCallback_EndInvoke_m27AAC229334FF8E13A13D6865ABA5EFE15DB37BD,
	Raycast2DCallback__ctor_m0F3912611ABC792CA238BB0A7A774AB9AC01B52E,
	Raycast2DCallback_Invoke_mE8A24A7158D5A2DEEA1C37210A230A0BFF084603,
	Raycast2DCallback_BeginInvoke_mF504BADFEEC32EE4F4392F1895175B921A037D85,
	Raycast2DCallback_EndInvoke_mFCF0BDB5B7142F6DA030059561764A974E656F88,
	GetRayIntersectionAllCallback__ctor_m5E404A80C54052DFD314FEEE35844AFB06E5F03E,
	GetRayIntersectionAllCallback_Invoke_m57AD088B59768E362F4EA3B665E5153E9282D511,
	GetRayIntersectionAllCallback_BeginInvoke_mC6074520BD09886702C3039D34BEB8ED1B8F71B4,
	GetRayIntersectionAllCallback_EndInvoke_mFBD3797128011018C74318B12D85BED8F658FFC9,
	GetRayIntersectionAllNonAllocCallback__ctor_m854C98B55B734C291A6CED4B7F2D9F149B03FCEC,
	GetRayIntersectionAllNonAllocCallback_Invoke_mB9D518882273DDC16919EE0122A97D629FD0457F,
	GetRayIntersectionAllNonAllocCallback_BeginInvoke_mDFEEFE0E75899C6CD9F756EC4EDFCCD3262F356D,
	GetRayIntersectionAllNonAllocCallback_EndInvoke_m6A187B845ED00824B2922125A3DF0C96DDC71154,
	ColorTweenCallback__ctor_mBB57DF8BE131686390944A01A6A10A8FBC2DE005,
	FloatTweenCallback__ctor_m85BC42EE5784B9D8659BE634B8F46BFF06933EEE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	TriggerEvent__ctor_mE5A64BDC6F94313C8240612A623EAAB29F25ADAF,
	Entry__ctor_mA35142E0673AB7824813B59E527C474605E09B7C,
	NULL,
	NULL,
	NULL,
	NULL,
	U3CU3Ec__cctor_m318A0D8B2A1679122D4022E2563BA291EE812748,
	U3CU3Ec__ctor_m919606841B6135F79DD98C8ADA83F41FA354F1EA,
	U3CU3Ec_U3C_cctorU3Eb__79_0_mF66ED8AEFC42C39E1BD94028C7F4468AE702BBFE,
	ButtonState_get_eventData_mA9D054D526473A2481A997758CDDEB022E67351D,
	ButtonState_set_eventData_m3E72ED95C634264A32BE660552D22684B0BF8B55,
	ButtonState_get_button_mB538B2D483C482A7E628D26BA390449A54C958A3,
	ButtonState_set_button_m9D44DBD86C06F5C9DF68A84CD5D89A4847E02D68,
	ButtonState__ctor_m96C223DB2B958828D45ACB15D1CF32C4B87FFA97,
	MouseState_AnyPressesThisFrame_m8055332F4AA44246655B6E19522E1A39CB172D95,
	MouseState_AnyReleasesThisFrame_mCB786F99845E669E59BF259723A2368931A324EC,
	MouseState_GetButtonState_m0C2884609F720A284C72EAEF061C781F4874CCAE,
	MouseState_SetButtonState_m4A6AB431337B8CFE2C51E7E73D9C1A15D9C78BB4,
	MouseState__ctor_mCEC029743547501A89B66C448642D3BA8D5EB600,
	MouseButtonEventData_PressedThisFrame_m172F2A7A82DED3678EF87AD1B4FD69D6D406E176,
	MouseButtonEventData_ReleasedThisFrame_mE4BFCF235B7D4B71D41FE3A4CDB376701001CD40,
	MouseButtonEventData__ctor_mB419FF26D986E03E724C39FC0BF03B8B2C461FD3,
	RaycastHitComparer_Compare_mE19E714A83902B3157EE83A24916967E8D4EBE8C,
	RaycastHitComparer__ctor_mE4EE9168BDABF1148A3071071A676F5343A867DD,
	RaycastHitComparer__cctor_mD1A6F09923FDD75B9F5D0AE505FD788507B84A40,
};
extern void ColorBlock_get_normalColor_mE0A4EBADEFB7A6F245F590B0A5DBB59F289C0905_AdjustorThunk (void);
extern void ColorBlock_set_normalColor_mAB3355641A3BA73B63E1A8727EC51A095262CC51_AdjustorThunk (void);
extern void ColorBlock_get_highlightedColor_m779349828B304DB2551C3A3CCDDD69861A21EDFF_AdjustorThunk (void);
extern void ColorBlock_set_highlightedColor_m7E9A152B71CD6CBD5BEE9E4019547BD9CC991AF6_AdjustorThunk (void);
extern void ColorBlock_get_pressedColor_m19AA95DCC2519975D93202C997EECB3E06CE96E5_AdjustorThunk (void);
extern void ColorBlock_set_pressedColor_m252EDA03CA097EF1604FF2678598BA6A294C13C8_AdjustorThunk (void);
extern void ColorBlock_get_selectedColor_mE6DDB9D2D3466CCFFFF000286619BEC4AB60F83D_AdjustorThunk (void);
extern void ColorBlock_set_selectedColor_mE731B0D4FFE33D3438CA3757F72B6808066937E2_AdjustorThunk (void);
extern void ColorBlock_get_disabledColor_mD865FC8BCFE7B8535A51A68E78130409F3C97FC8_AdjustorThunk (void);
extern void ColorBlock_set_disabledColor_mABE874E9EF8C41CE83BB16B94C7511AF1FE8AE47_AdjustorThunk (void);
extern void ColorBlock_get_colorMultiplier_mA273A409AC9125C22CBCCB236F0E758C36BA9581_AdjustorThunk (void);
extern void ColorBlock_set_colorMultiplier_m8EE6BD49B92CA0C7E801E9D4E39F0AB39237FE26_AdjustorThunk (void);
extern void ColorBlock_get_fadeDuration_mCFF802DD654D7E9C3509A65974EB35153FDB1415_AdjustorThunk (void);
extern void ColorBlock_set_fadeDuration_m2C1C0A118396BB2DF370F2F87A6ECA861AE0CA63_AdjustorThunk (void);
extern void ColorBlock_Equals_m5F50CD8C86A89B8EFA4E878BD914656ECEB0177D_AdjustorThunk (void);
extern void ColorBlock_Equals_mCD07A68D8E306D372ECA1D13BDA091E9579B4AEE_AdjustorThunk (void);
extern void ColorBlock_GetHashCode_m92C2ECB5F5118D21A01C35481D8CC9A091AB6B4B_AdjustorThunk (void);
extern void Navigation_get_mode_m3C77554140D0A56ACD06B1E6DB2D016F080FB95E_AdjustorThunk (void);
extern void Navigation_set_mode_m98F00F98459C0C3D79FDC7221C779D83130D67BC_AdjustorThunk (void);
extern void Navigation_get_selectOnUp_m8E3A8A4358C862B402C322E93062E10F22371A0E_AdjustorThunk (void);
extern void Navigation_set_selectOnUp_mDC6497A819851FC70C1771FA5B4F8DEF7BDCD552_AdjustorThunk (void);
extern void Navigation_get_selectOnDown_mC9469ADD19689D5D263A39861E70E43A75BB9398_AdjustorThunk (void);
extern void Navigation_set_selectOnDown_mE97059CFEDDAA89BC14D85EA1FB51A9D3BDA4549_AdjustorThunk (void);
extern void Navigation_get_selectOnLeft_m1B2D71E749D06A2D89855AE6715DBD253BC623FA_AdjustorThunk (void);
extern void Navigation_set_selectOnLeft_m6C219E151D044D1C4F086A2DDD104C537553B79D_AdjustorThunk (void);
extern void Navigation_get_selectOnRight_mD44071FB2CBE195EBD6EBF37437C3F5BBFA5B328_AdjustorThunk (void);
extern void Navigation_set_selectOnRight_mEBD7DF30AC830A83DCC7F1E2BA9629864A40336E_AdjustorThunk (void);
extern void Navigation_Equals_m06EE535BFA43DD09F43FB681936E6AA4112F2AE2_AdjustorThunk (void);
extern void SpriteState_get_highlightedSprite_mB8CB5AD077F9FDA5A7DA9B0700B70FEB471B15F0_AdjustorThunk (void);
extern void SpriteState_set_highlightedSprite_m44A452FACA739422110D9B8C2E51E8874A730B1D_AdjustorThunk (void);
extern void SpriteState_get_pressedSprite_m42EB6FFB954E6BDC6384B5DCDD7348DE4F7D44EB_AdjustorThunk (void);
extern void SpriteState_set_pressedSprite_mB3C2505D0D31FBB5549444AF739D887B399535F6_AdjustorThunk (void);
extern void SpriteState_get_selectedSprite_mC69216B3ABE6539D061E34707C086FA76F28FF5B_AdjustorThunk (void);
extern void SpriteState_set_selectedSprite_mEA22F605F22D4302EE742C2500B891DC442A0EB5_AdjustorThunk (void);
extern void SpriteState_get_disabledSprite_m08ED7B54CD394C0CE044519A296600DFF14D0B57_AdjustorThunk (void);
extern void SpriteState_set_disabledSprite_m4F8989570A957B357527421B89EFF14CA2228E14_AdjustorThunk (void);
extern void SpriteState_Equals_mBD4F9DE44FE87CA763874C9C8C0FAC60E1686592_AdjustorThunk (void);
extern void ColorTween_get_startColor_mA979B663DFD611DAC95F4A7B98AA36E24EE5E3D6_AdjustorThunk (void);
extern void ColorTween_set_startColor_mD976BED0C47332CB811EA6B68230FFAB69DCE82D_AdjustorThunk (void);
extern void ColorTween_get_targetColor_m2620FDCF03617764286DCDF8000AA3BE59C9E7AF_AdjustorThunk (void);
extern void ColorTween_set_targetColor_m9BA400CD92F2182DFEDEA4494B66501C7596DD69_AdjustorThunk (void);
extern void ColorTween_get_tweenMode_m908DEFB153497AC18AD08CB73AFF655C1F6D05FB_AdjustorThunk (void);
extern void ColorTween_set_tweenMode_m88B5C1FA53770422C80E61B0958CA7B94E6D8B27_AdjustorThunk (void);
extern void ColorTween_get_duration_mC4A1E3C2EA46A5C657A2B9DA240C796F770ECC5F_AdjustorThunk (void);
extern void ColorTween_set_duration_m069BFDD0F6EABA4869ABC1F4620C54F749950E3D_AdjustorThunk (void);
extern void ColorTween_get_ignoreTimeScale_m6A06826E19314EFE9783E505C75CFC76E42E8F05_AdjustorThunk (void);
extern void ColorTween_set_ignoreTimeScale_m42071C6EB064666F7FF945EEC5B5261836E8E593_AdjustorThunk (void);
extern void ColorTween_TweenValue_m20FCBA50CE9328956973861A9CB0A1FD97265A58_AdjustorThunk (void);
extern void ColorTween_AddOnChangedCallback_m8B7B35D5B912C0BCEFB275B54A3A2EB8D1DD7DE8_AdjustorThunk (void);
extern void ColorTween_GetIgnoreTimescale_m5100D5725C73E6DB3718A2CF33C9CB46CA27731E_AdjustorThunk (void);
extern void ColorTween_GetDuration_m327EABA3FBCD9635DCD360834176D3AEDBFA88B0_AdjustorThunk (void);
extern void ColorTween_ValidTarget_mCFF8428CFF8D45A85E4EE612263E751ED0B5987C_AdjustorThunk (void);
extern void FloatTween_get_startValue_m6DC736717E2EAD27CE41A6CD292B6D28AE1DED1E_AdjustorThunk (void);
extern void FloatTween_set_startValue_m34ECE8005F47D60A3F5AF976FF28881A2200B549_AdjustorThunk (void);
extern void FloatTween_get_targetValue_m15E266DEA747D1DD8F49681E9E6AFD7FADBEB027_AdjustorThunk (void);
extern void FloatTween_set_targetValue_m04567CCFC5510BA34D68C7A2C4AE32D400D59C3E_AdjustorThunk (void);
extern void FloatTween_get_duration_mBECFBEC57BDC30B54D0638873BA3313A8F7232F5_AdjustorThunk (void);
extern void FloatTween_set_duration_m7E3C3B6D6F9D1C5D9AE051ED64915029E8B4F094_AdjustorThunk (void);
extern void FloatTween_get_ignoreTimeScale_mA7B69D72E1D52EF1890C89D5690D345B852C7239_AdjustorThunk (void);
extern void FloatTween_set_ignoreTimeScale_m6826FE67438AA7F1E4ECB85EC83812BC2F6F092B_AdjustorThunk (void);
extern void FloatTween_TweenValue_m4E4418FB7FBDC7CBF96D95518DFACF25BCBE8EB3_AdjustorThunk (void);
extern void FloatTween_AddOnChangedCallback_m56955D43A7CDE997CE447A1C69CA708E8190E9AE_AdjustorThunk (void);
extern void FloatTween_GetIgnoreTimescale_mB93B6C1BAD120F59F58DFE9409A64DE3A4790D88_AdjustorThunk (void);
extern void FloatTween_GetDuration_m81D2D1E8D8AEDFDF03B54F1AF71A74824480B178_AdjustorThunk (void);
extern void FloatTween_ValidTarget_m917EB0D30E72AC75D90D1D8F11B1D7EBBD00ECAE_AdjustorThunk (void);
extern void RaycastResult_get_gameObject_m9D77DEDFF498BAFE29A5F88E9F238400D04C8FDD_AdjustorThunk (void);
extern void RaycastResult_set_gameObject_m4EB676328BEC6E2C3A2AFBA4B405CEDDEAEBBFFA_AdjustorThunk (void);
extern void RaycastResult_get_isValid_m2F2241EF619EFFC0F609FAA35D4C64455712DE47_AdjustorThunk (void);
extern void RaycastResult_Clear_mDC3D08DD775DA02145E5AF6FE62465EBACEB4AAB_AdjustorThunk (void);
extern void RaycastResult_ToString_m0EE4380602D2025F27DB18ABE887E9CC7C39BB5B_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[70] = 
{
	{ 0x0600002B, ColorBlock_get_normalColor_mE0A4EBADEFB7A6F245F590B0A5DBB59F289C0905_AdjustorThunk },
	{ 0x0600002C, ColorBlock_set_normalColor_mAB3355641A3BA73B63E1A8727EC51A095262CC51_AdjustorThunk },
	{ 0x0600002D, ColorBlock_get_highlightedColor_m779349828B304DB2551C3A3CCDDD69861A21EDFF_AdjustorThunk },
	{ 0x0600002E, ColorBlock_set_highlightedColor_m7E9A152B71CD6CBD5BEE9E4019547BD9CC991AF6_AdjustorThunk },
	{ 0x0600002F, ColorBlock_get_pressedColor_m19AA95DCC2519975D93202C997EECB3E06CE96E5_AdjustorThunk },
	{ 0x06000030, ColorBlock_set_pressedColor_m252EDA03CA097EF1604FF2678598BA6A294C13C8_AdjustorThunk },
	{ 0x06000031, ColorBlock_get_selectedColor_mE6DDB9D2D3466CCFFFF000286619BEC4AB60F83D_AdjustorThunk },
	{ 0x06000032, ColorBlock_set_selectedColor_mE731B0D4FFE33D3438CA3757F72B6808066937E2_AdjustorThunk },
	{ 0x06000033, ColorBlock_get_disabledColor_mD865FC8BCFE7B8535A51A68E78130409F3C97FC8_AdjustorThunk },
	{ 0x06000034, ColorBlock_set_disabledColor_mABE874E9EF8C41CE83BB16B94C7511AF1FE8AE47_AdjustorThunk },
	{ 0x06000035, ColorBlock_get_colorMultiplier_mA273A409AC9125C22CBCCB236F0E758C36BA9581_AdjustorThunk },
	{ 0x06000036, ColorBlock_set_colorMultiplier_m8EE6BD49B92CA0C7E801E9D4E39F0AB39237FE26_AdjustorThunk },
	{ 0x06000037, ColorBlock_get_fadeDuration_mCFF802DD654D7E9C3509A65974EB35153FDB1415_AdjustorThunk },
	{ 0x06000038, ColorBlock_set_fadeDuration_m2C1C0A118396BB2DF370F2F87A6ECA861AE0CA63_AdjustorThunk },
	{ 0x0600003A, ColorBlock_Equals_m5F50CD8C86A89B8EFA4E878BD914656ECEB0177D_AdjustorThunk },
	{ 0x0600003B, ColorBlock_Equals_mCD07A68D8E306D372ECA1D13BDA091E9579B4AEE_AdjustorThunk },
	{ 0x0600003E, ColorBlock_GetHashCode_m92C2ECB5F5118D21A01C35481D8CC9A091AB6B4B_AdjustorThunk },
	{ 0x060002EA, Navigation_get_mode_m3C77554140D0A56ACD06B1E6DB2D016F080FB95E_AdjustorThunk },
	{ 0x060002EB, Navigation_set_mode_m98F00F98459C0C3D79FDC7221C779D83130D67BC_AdjustorThunk },
	{ 0x060002EC, Navigation_get_selectOnUp_m8E3A8A4358C862B402C322E93062E10F22371A0E_AdjustorThunk },
	{ 0x060002ED, Navigation_set_selectOnUp_mDC6497A819851FC70C1771FA5B4F8DEF7BDCD552_AdjustorThunk },
	{ 0x060002EE, Navigation_get_selectOnDown_mC9469ADD19689D5D263A39861E70E43A75BB9398_AdjustorThunk },
	{ 0x060002EF, Navigation_set_selectOnDown_mE97059CFEDDAA89BC14D85EA1FB51A9D3BDA4549_AdjustorThunk },
	{ 0x060002F0, Navigation_get_selectOnLeft_m1B2D71E749D06A2D89855AE6715DBD253BC623FA_AdjustorThunk },
	{ 0x060002F1, Navigation_set_selectOnLeft_m6C219E151D044D1C4F086A2DDD104C537553B79D_AdjustorThunk },
	{ 0x060002F2, Navigation_get_selectOnRight_mD44071FB2CBE195EBD6EBF37437C3F5BBFA5B328_AdjustorThunk },
	{ 0x060002F3, Navigation_set_selectOnRight_mEBD7DF30AC830A83DCC7F1E2BA9629864A40336E_AdjustorThunk },
	{ 0x060002F5, Navigation_Equals_m06EE535BFA43DD09F43FB681936E6AA4112F2AE2_AdjustorThunk },
	{ 0x06000407, SpriteState_get_highlightedSprite_mB8CB5AD077F9FDA5A7DA9B0700B70FEB471B15F0_AdjustorThunk },
	{ 0x06000408, SpriteState_set_highlightedSprite_m44A452FACA739422110D9B8C2E51E8874A730B1D_AdjustorThunk },
	{ 0x06000409, SpriteState_get_pressedSprite_m42EB6FFB954E6BDC6384B5DCDD7348DE4F7D44EB_AdjustorThunk },
	{ 0x0600040A, SpriteState_set_pressedSprite_mB3C2505D0D31FBB5549444AF739D887B399535F6_AdjustorThunk },
	{ 0x0600040B, SpriteState_get_selectedSprite_mC69216B3ABE6539D061E34707C086FA76F28FF5B_AdjustorThunk },
	{ 0x0600040C, SpriteState_set_selectedSprite_mEA22F605F22D4302EE742C2500B891DC442A0EB5_AdjustorThunk },
	{ 0x0600040D, SpriteState_get_disabledSprite_m08ED7B54CD394C0CE044519A296600DFF14D0B57_AdjustorThunk },
	{ 0x0600040E, SpriteState_set_disabledSprite_m4F8989570A957B357527421B89EFF14CA2228E14_AdjustorThunk },
	{ 0x0600040F, SpriteState_Equals_mBD4F9DE44FE87CA763874C9C8C0FAC60E1686592_AdjustorThunk },
	{ 0x060004BA, ColorTween_get_startColor_mA979B663DFD611DAC95F4A7B98AA36E24EE5E3D6_AdjustorThunk },
	{ 0x060004BB, ColorTween_set_startColor_mD976BED0C47332CB811EA6B68230FFAB69DCE82D_AdjustorThunk },
	{ 0x060004BC, ColorTween_get_targetColor_m2620FDCF03617764286DCDF8000AA3BE59C9E7AF_AdjustorThunk },
	{ 0x060004BD, ColorTween_set_targetColor_m9BA400CD92F2182DFEDEA4494B66501C7596DD69_AdjustorThunk },
	{ 0x060004BE, ColorTween_get_tweenMode_m908DEFB153497AC18AD08CB73AFF655C1F6D05FB_AdjustorThunk },
	{ 0x060004BF, ColorTween_set_tweenMode_m88B5C1FA53770422C80E61B0958CA7B94E6D8B27_AdjustorThunk },
	{ 0x060004C0, ColorTween_get_duration_mC4A1E3C2EA46A5C657A2B9DA240C796F770ECC5F_AdjustorThunk },
	{ 0x060004C1, ColorTween_set_duration_m069BFDD0F6EABA4869ABC1F4620C54F749950E3D_AdjustorThunk },
	{ 0x060004C2, ColorTween_get_ignoreTimeScale_m6A06826E19314EFE9783E505C75CFC76E42E8F05_AdjustorThunk },
	{ 0x060004C3, ColorTween_set_ignoreTimeScale_m42071C6EB064666F7FF945EEC5B5261836E8E593_AdjustorThunk },
	{ 0x060004C4, ColorTween_TweenValue_m20FCBA50CE9328956973861A9CB0A1FD97265A58_AdjustorThunk },
	{ 0x060004C5, ColorTween_AddOnChangedCallback_m8B7B35D5B912C0BCEFB275B54A3A2EB8D1DD7DE8_AdjustorThunk },
	{ 0x060004C6, ColorTween_GetIgnoreTimescale_m5100D5725C73E6DB3718A2CF33C9CB46CA27731E_AdjustorThunk },
	{ 0x060004C7, ColorTween_GetDuration_m327EABA3FBCD9635DCD360834176D3AEDBFA88B0_AdjustorThunk },
	{ 0x060004C8, ColorTween_ValidTarget_mCFF8428CFF8D45A85E4EE612263E751ED0B5987C_AdjustorThunk },
	{ 0x060004C9, FloatTween_get_startValue_m6DC736717E2EAD27CE41A6CD292B6D28AE1DED1E_AdjustorThunk },
	{ 0x060004CA, FloatTween_set_startValue_m34ECE8005F47D60A3F5AF976FF28881A2200B549_AdjustorThunk },
	{ 0x060004CB, FloatTween_get_targetValue_m15E266DEA747D1DD8F49681E9E6AFD7FADBEB027_AdjustorThunk },
	{ 0x060004CC, FloatTween_set_targetValue_m04567CCFC5510BA34D68C7A2C4AE32D400D59C3E_AdjustorThunk },
	{ 0x060004CD, FloatTween_get_duration_mBECFBEC57BDC30B54D0638873BA3313A8F7232F5_AdjustorThunk },
	{ 0x060004CE, FloatTween_set_duration_m7E3C3B6D6F9D1C5D9AE051ED64915029E8B4F094_AdjustorThunk },
	{ 0x060004CF, FloatTween_get_ignoreTimeScale_mA7B69D72E1D52EF1890C89D5690D345B852C7239_AdjustorThunk },
	{ 0x060004D0, FloatTween_set_ignoreTimeScale_m6826FE67438AA7F1E4ECB85EC83812BC2F6F092B_AdjustorThunk },
	{ 0x060004D1, FloatTween_TweenValue_m4E4418FB7FBDC7CBF96D95518DFACF25BCBE8EB3_AdjustorThunk },
	{ 0x060004D2, FloatTween_AddOnChangedCallback_m56955D43A7CDE997CE447A1C69CA708E8190E9AE_AdjustorThunk },
	{ 0x060004D3, FloatTween_GetIgnoreTimescale_mB93B6C1BAD120F59F58DFE9409A64DE3A4790D88_AdjustorThunk },
	{ 0x060004D4, FloatTween_GetDuration_m81D2D1E8D8AEDFDF03B54F1AF71A74824480B178_AdjustorThunk },
	{ 0x060004D5, FloatTween_ValidTarget_m917EB0D30E72AC75D90D1D8F11B1D7EBBD00ECAE_AdjustorThunk },
	{ 0x060005F1, RaycastResult_get_gameObject_m9D77DEDFF498BAFE29A5F88E9F238400D04C8FDD_AdjustorThunk },
	{ 0x060005F2, RaycastResult_set_gameObject_m4EB676328BEC6E2C3A2AFBA4B405CEDDEAEBBFFA_AdjustorThunk },
	{ 0x060005F3, RaycastResult_get_isValid_m2F2241EF619EFFC0F609FAA35D4C64455712DE47_AdjustorThunk },
	{ 0x060005F4, RaycastResult_Clear_mDC3D08DD775DA02145E5AF6FE62465EBACEB4AAB_AdjustorThunk },
	{ 0x060005F5, RaycastResult_ToString_m0EE4380602D2025F27DB18ABE887E9CC7C39BB5B_AdjustorThunk },
};
static const int32_t s_InvokerIndices[1727] = 
{
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	23,
	23,
	14,
	26,
	23,
	26,
	26,
	14,
	32,
	14,
	23,
	23,
	114,
	23,
	4,
	9,
	23,
	23,
	95,
	141,
	122,
	94,
	9,
	122,
	94,
	9,
	122,
	26,
	26,
	49,
	49,
	3,
	1107,
	1587,
	1107,
	1587,
	1107,
	1587,
	1107,
	1587,
	1107,
	1587,
	684,
	296,
	684,
	296,
	1661,
	9,
	1662,
	1663,
	1663,
	10,
	23,
	4,
	23,
	122,
	122,
	1664,
	23,
	14,
	23,
	14,
	1665,
	1665,
	1138,
	1666,
	23,
	4,
	1667,
	2,
	122,
	122,
	134,
	330,
	1668,
	1668,
	1668,
	1668,
	1668,
	1668,
	1668,
	1668,
	1668,
	1668,
	1668,
	3,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	684,
	296,
	10,
	32,
	32,
	591,
	23,
	23,
	23,
	23,
	23,
	26,
	26,
	26,
	23,
	23,
	-1,
	26,
	26,
	26,
	23,
	28,
	26,
	28,
	26,
	28,
	26,
	789,
	1240,
	1216,
	296,
	23,
	1669,
	23,
	26,
	3,
	4,
	14,
	26,
	10,
	32,
	10,
	32,
	114,
	31,
	10,
	32,
	10,
	32,
	10,
	32,
	114,
	31,
	114,
	31,
	10,
	32,
	10,
	32,
	684,
	296,
	23,
	23,
	23,
	122,
	122,
	122,
	3,
	4,
	1107,
	1587,
	114,
	31,
	114,
	31,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	10,
	14,
	14,
	23,
	14,
	14,
	14,
	26,
	14,
	14,
	23,
	23,
	23,
	23,
	23,
	32,
	23,
	23,
	23,
	23,
	23,
	23,
	4,
	26,
	26,
	26,
	23,
	23,
	1622,
	1670,
	1108,
	1671,
	1672,
	1673,
	1674,
	26,
	26,
	26,
	26,
	26,
	26,
	3,
	14,
	10,
	10,
	114,
	31,
	10,
	32,
	23,
	14,
	27,
	14,
	1675,
	3,
	23,
	4,
	134,
	134,
	0,
	3,
	23,
	114,
	14,
	23,
	14,
	26,
	23,
	14,
	26,
	14,
	10,
	32,
	114,
	31,
	114,
	31,
	10,
	32,
	684,
	296,
	114,
	31,
	10,
	32,
	684,
	296,
	684,
	296,
	114,
	31,
	23,
	4,
	14,
	114,
	684,
	296,
	684,
	684,
	14,
	26,
	23,
	23,
	1676,
	1677,
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	406,
	406,
	26,
	26,
	1678,
	1679,
	1680,
	406,
	1681,
	1682,
	23,
	23,
	684,
	684,
	684,
	684,
	684,
	684,
	10,
	1622,
	1683,
	122,
	122,
	122,
	23,
	3,
	14,
	14,
	23,
	14,
	14,
	31,
	114,
	31,
	114,
	14,
	26,
	26,
	406,
	114,
	684,
	296,
	10,
	32,
	14,
	26,
	14,
	26,
	1107,
	1587,
	114,
	31,
	1107,
	1587,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	14,
	10,
	32,
	10,
	32,
	114,
	31,
	114,
	215,
	560,
	114,
	6,
	10,
	32,
	10,
	32,
	114,
	10,
	32,
	10,
	32,
	10,
	32,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	31,
	31,
	4,
	122,
	114,
	23,
	23,
	1670,
	1684,
	1685,
	9,
	26,
	26,
	28,
	26,
	26,
	116,
	207,
	26,
	26,
	14,
	10,
	42,
	10,
	42,
	1008,
	1686,
	1686,
	31,
	42,
	31,
	42,
	23,
	23,
	23,
	560,
	23,
	23,
	23,
	23,
	26,
	560,
	23,
	114,
	185,
	185,
	32,
	23,
	23,
	32,
	23,
	23,
	23,
	23,
	26,
	1687,
	23,
	1687,
	1688,
	23,
	23,
	26,
	26,
	23,
	26,
	26,
	23,
	23,
	26,
	23,
	591,
	23,
	23,
	684,
	684,
	684,
	684,
	684,
	684,
	10,
	3,
	14,
	10,
	32,
	684,
	296,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	1690,
	1137,
	23,
	23,
	23,
	10,
	32,
	684,
	296,
	684,
	296,
	1137,
	1138,
	10,
	32,
	684,
	296,
	10,
	32,
	684,
	296,
	684,
	296,
	684,
	296,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	296,
	296,
	10,
	32,
	10,
	32,
	14,
	23,
	23,
	23,
	23,
	32,
	23,
	23,
	23,
	10,
	32,
	10,
	32,
	1137,
	1138,
	1137,
	1138,
	10,
	32,
	10,
	32,
	23,
	23,
	23,
	23,
	23,
	32,
	23,
	23,
	23,
	23,
	23,
	684,
	296,
	114,
	31,
	114,
	31,
	114,
	31,
	114,
	31,
	114,
	31,
	114,
	31,
	591,
	591,
	1691,
	23,
	23,
	23,
	684,
	684,
	684,
	684,
	684,
	684,
	10,
	23,
	23,
	114,
	114,
	31,
	23,
	23,
	684,
	296,
	684,
	296,
	684,
	296,
	684,
	296,
	684,
	296,
	684,
	296,
	10,
	32,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	14,
	26,
	10,
	32,
	14,
	14,
	23,
	23,
	684,
	684,
	684,
	684,
	684,
	684,
	10,
	23,
	23,
	23,
	23,
	23,
	23,
	1239,
	1239,
	1239,
	1692,
	1239,
	1693,
	1694,
	1695,
	1695,
	1696,
	114,
	23,
	23,
	-1,
	23,
	28,
	26,
	23,
	3,
	122,
	14,
	114,
	122,
	122,
	32,
	27,
	27,
	122,
	111,
	122,
	23,
	23,
	10,
	9,
	14,
	23,
	92,
	92,
	92,
	1504,
	1504,
	1504,
	1504,
	1504,
	1504,
	1697,
	1698,
	23,
	23,
	23,
	23,
	23,
	14,
	114,
	31,
	14,
	23,
	114,
	23,
	23,
	23,
	1622,
	28,
	122,
	122,
	0,
	141,
	111,
	0,
	134,
	23,
	14,
	26,
	114,
	31,
	114,
	31,
	28,
	1665,
	31,
	1665,
	1138,
	23,
	23,
	23,
	23,
	23,
	1108,
	23,
	23,
	23,
	23,
	14,
	28,
	122,
	122,
	192,
	1269,
	10,
	32,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	1699,
	1700,
	23,
	14,
	14,
	26,
	1108,
	1109,
	23,
	26,
	23,
	1317,
	1467,
	1701,
	1702,
	14,
	1108,
	14,
	23,
	23,
	23,
	1622,
	1108,
	23,
	23,
	26,
	26,
	23,
	23,
	14,
	26,
	114,
	31,
	114,
	31,
	10,
	32,
	684,
	296,
	114,
	31,
	684,
	296,
	684,
	296,
	14,
	26,
	14,
	26,
	14,
	26,
	10,
	32,
	10,
	32,
	684,
	296,
	684,
	296,
	14,
	26,
	14,
	1137,
	1138,
	14,
	23,
	32,
	23,
	23,
	23,
	23,
	23,
	114,
	23,
	23,
	26,
	26,
	26,
	26,
	26,
	1138,
	23,
	23,
	1138,
	1137,
	1138,
	684,
	296,
	684,
	296,
	296,
	296,
	1703,
	392,
	23,
	114,
	114,
	23,
	23,
	684,
	684,
	684,
	684,
	684,
	684,
	10,
	23,
	23,
	23,
	1704,
	23,
	23,
	1214,
	1159,
	1705,
	1670,
	1706,
	23,
	23,
	14,
	14,
	26,
	10,
	32,
	23,
	684,
	296,
	296,
	684,
	296,
	10,
	32,
	14,
	26,
	684,
	32,
	23,
	23,
	23,
	23,
	23,
	23,
	1707,
	23,
	10,
	114,
	23,
	26,
	1708,
	9,
	26,
	26,
	26,
	28,
	1709,
	26,
	26,
	14,
	14,
	14,
	14,
	26,
	591,
	14,
	4,
	131,
	4,
	95,
	1710,
	1711,
	10,
	32,
	1712,
	1713,
	1714,
	1715,
	14,
	26,
	14,
	26,
	114,
	31,
	114,
	31,
	114,
	31,
	114,
	31,
	23,
	14,
	26,
	14,
	23,
	23,
	114,
	23,
	23,
	23,
	23,
	23,
	10,
	23,
	591,
	1716,
	1717,
	27,
	14,
	14,
	14,
	14,
	26,
	1718,
	26,
	26,
	114,
	114,
	23,
	26,
	26,
	26,
	26,
	26,
	26,
	23,
	3,
	1719,
	-1,
	-1,
	14,
	26,
	14,
	26,
	10,
	32,
	684,
	296,
	684,
	296,
	114,
	31,
	684,
	296,
	296,
	684,
	296,
	14,
	26,
	684,
	23,
	32,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	1099,
	1707,
	23,
	10,
	114,
	23,
	27,
	9,
	26,
	26,
	26,
	14,
	14,
	14,
	14,
	26,
	591,
	14,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	1720,
	167,
	1721,
	1722,
	122,
	3,
	3,
	23,
	14,
	14,
	14,
	23,
	14,
	26,
	14,
	26,
	114,
	31,
	114,
	31,
	10,
	32,
	10,
	32,
	10,
	32,
	114,
	31,
	10,
	32,
	10,
	32,
	10,
	32,
	684,
	296,
	10,
	32,
	684,
	23,
	23,
	23,
	23,
	1723,
	1724,
	26,
	23,
	23,
	684,
	684,
	684,
	684,
	684,
	684,
	10,
	3,
	14,
	26,
	23,
	32,
	23,
	23,
	23,
	23,
	23,
	23,
	406,
	114,
	31,
	31,
	42,
	31,
	23,
	23,
	26,
	26,
	14,
	114,
	31,
	23,
	23,
	26,
	406,
	26,
	26,
	23,
	114,
	14,
	31,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	23,
	4,
	3,
	23,
	26,
	23,
	23,
	23,
	10,
	10,
	64,
	1734,
	26,
	1735,
	1736,
	1737,
	1738,
	38,
	26,
	27,
	26,
	26,
	3,
	26,
	23,
	14,
	23,
	23,
	23,
	26,
	26,
	23,
	26,
	26,
	26,
	23,
	26,
	23,
	26,
	23,
	1107,
	1587,
	1137,
	1138,
	114,
	31,
	1739,
	1739,
	26,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	296,
	114,
	684,
	114,
	1107,
	1587,
	1107,
	1587,
	10,
	32,
	684,
	296,
	114,
	31,
	296,
	26,
	114,
	684,
	114,
	684,
	296,
	684,
	296,
	684,
	296,
	114,
	31,
	296,
	26,
	114,
	684,
	114,
	-1,
	-1,
	-1,
	-1,
	-1,
	1137,
	1138,
	10,
	32,
	26,
	23,
	23,
	114,
	23,
	26,
	14,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	1740,
	1741,
	1740,
	1741,
	114,
	31,
	10,
	32,
	1137,
	1138,
	1137,
	1138,
	1137,
	1138,
	1129,
	1130,
	1129,
	1130,
	684,
	296,
	10,
	32,
	1137,
	1138,
	114,
	31,
	114,
	31,
	10,
	32,
	26,
	114,
	114,
	14,
	14,
	14,
	26,
	14,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	4,
	122,
	114,
	31,
	10,
	32,
	14,
	14,
	26,
	14,
	14,
	114,
	23,
	23,
	114,
	27,
	14,
	26,
	1742,
	27,
	114,
	30,
	23,
	23,
	23,
	31,
	23,
	26,
	14,
	3,
	14,
	26,
	23,
	14,
	26,
	62,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	-1,
	134,
	134,
	134,
	134,
	134,
	134,
	134,
	134,
	134,
	134,
	134,
	134,
	134,
	134,
	134,
	134,
	134,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	134,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	3,
	14,
	10,
	32,
	1137,
	1138,
	114,
	30,
	30,
	30,
	1137,
	1137,
	114,
	10,
	1651,
	195,
	9,
	23,
	14,
	14,
	26,
	14,
	23,
	23,
	23,
	1743,
	1744,
	1745,
	1,
	27,
	1746,
	14,
	30,
	114,
	23,
	23,
	23,
	114,
	23,
	1747,
	26,
	1748,
	27,
	37,
	14,
	34,
	34,
	1749,
	26,
	26,
	30,
	23,
	14,
	27,
	23,
	23,
	10,
	114,
	31,
	114,
	31,
	684,
	296,
	684,
	296,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	114,
	23,
	27,
	114,
	114,
	23,
	23,
	23,
	114,
	753,
	114,
	1137,
	114,
	23,
	114,
	32,
	114,
	26,
	14,
	23,
	114,
	31,
	114,
	31,
	23,
	114,
	114,
	114,
	23,
	23,
	23,
	753,
	23,
	14,
	14,
	26,
	114,
	23,
	14,
	122,
	4,
	122,
	3,
	27,
	14,
	10,
	10,
	10,
	14,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	27,
	23,
	14,
	10,
	10,
	1750,
	1620,
	10,
	32,
	1751,
	27,
	23,
	23,
	23,
	23,
	23,
	114,
	23,
	23,
	23,
	23,
	23,
	23,
	114,
	23,
	23,
	32,
	23,
	114,
	14,
	23,
	14,
	113,
	113,
	23,
	3,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	26,
	26,
	23,
	14,
	26,
	14,
	26,
	23,
	26,
	26,
	27,
	14,
	26,
	23,
	23,
	23,
	31,
	32,
	23,
	114,
	14,
	23,
	14,
	3,
	23,
	41,
	102,
	1688,
	1689,
	193,
	23,
	23,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	3,
	23,
	26,
	9,
	26,
	26,
	26,
	26,
	3,
	23,
	195,
	195,
	195,
	195,
	195,
	195,
	195,
	195,
	23,
	23,
	23,
	32,
	23,
	114,
	14,
	23,
	14,
	23,
	23,
	23,
	3,
	23,
	9,
	9,
	102,
	1725,
	1726,
	1727,
	102,
	1728,
	1729,
	28,
	102,
	1730,
	1731,
	116,
	102,
	1600,
	1732,
	1733,
	102,
	1728,
	1729,
	28,
	102,
	1730,
	1731,
	116,
	23,
	23,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	23,
	23,
	-1,
	-1,
	-1,
	-1,
	3,
	23,
	26,
	14,
	26,
	10,
	32,
	23,
	114,
	114,
	34,
	569,
	23,
	114,
	114,
	23,
	1752,
	23,
	3,
};
static const Il2CppTokenRangePair s_rgctxIndices[16] = 
{
	{ 0x0200003C, { 8, 9 } },
	{ 0x0200003D, { 17, 12 } },
	{ 0x02000047, { 29, 22 } },
	{ 0x0200004B, { 51, 6 } },
	{ 0x020000B8, { 57, 1 } },
	{ 0x0600007F, { 0, 3 } },
	{ 0x06000295, { 3, 1 } },
	{ 0x060003D6, { 4, 3 } },
	{ 0x060003D7, { 7, 1 } },
	{ 0x0600055C, { 58, 2 } },
	{ 0x06000580, { 60, 4 } },
	{ 0x06000581, { 64, 1 } },
	{ 0x06000582, { 65, 1 } },
	{ 0x06000583, { 66, 1 } },
	{ 0x06000584, { 67, 1 } },
	{ 0x06000585, { 68, 1 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[69] = 
{
	{ (Il2CppRGCTXDataType)3, 16794 },
	{ (Il2CppRGCTXDataType)2, 18293 },
	{ (Il2CppRGCTXDataType)3, 16795 },
	{ (Il2CppRGCTXDataType)2, 18494 },
	{ (Il2CppRGCTXDataType)3, 16796 },
	{ (Il2CppRGCTXDataType)2, 21485 },
	{ (Il2CppRGCTXDataType)3, 16797 },
	{ (Il2CppRGCTXDataType)2, 18618 },
	{ (Il2CppRGCTXDataType)3, 16798 },
	{ (Il2CppRGCTXDataType)2, 21486 },
	{ (Il2CppRGCTXDataType)3, 16799 },
	{ (Il2CppRGCTXDataType)3, 16800 },
	{ (Il2CppRGCTXDataType)3, 16801 },
	{ (Il2CppRGCTXDataType)2, 21487 },
	{ (Il2CppRGCTXDataType)3, 16802 },
	{ (Il2CppRGCTXDataType)2, 21488 },
	{ (Il2CppRGCTXDataType)3, 16803 },
	{ (Il2CppRGCTXDataType)3, 16804 },
	{ (Il2CppRGCTXDataType)3, 16805 },
	{ (Il2CppRGCTXDataType)3, 16806 },
	{ (Il2CppRGCTXDataType)2, 21489 },
	{ (Il2CppRGCTXDataType)3, 16807 },
	{ (Il2CppRGCTXDataType)3, 16808 },
	{ (Il2CppRGCTXDataType)3, 16809 },
	{ (Il2CppRGCTXDataType)3, 16810 },
	{ (Il2CppRGCTXDataType)3, 16811 },
	{ (Il2CppRGCTXDataType)3, 16812 },
	{ (Il2CppRGCTXDataType)2, 18669 },
	{ (Il2CppRGCTXDataType)3, 16813 },
	{ (Il2CppRGCTXDataType)3, 16814 },
	{ (Il2CppRGCTXDataType)3, 16815 },
	{ (Il2CppRGCTXDataType)3, 16816 },
	{ (Il2CppRGCTXDataType)3, 16817 },
	{ (Il2CppRGCTXDataType)3, 16818 },
	{ (Il2CppRGCTXDataType)3, 16819 },
	{ (Il2CppRGCTXDataType)3, 16820 },
	{ (Il2CppRGCTXDataType)3, 16821 },
	{ (Il2CppRGCTXDataType)3, 16822 },
	{ (Il2CppRGCTXDataType)3, 16823 },
	{ (Il2CppRGCTXDataType)3, 16824 },
	{ (Il2CppRGCTXDataType)3, 16825 },
	{ (Il2CppRGCTXDataType)3, 16826 },
	{ (Il2CppRGCTXDataType)3, 16827 },
	{ (Il2CppRGCTXDataType)3, 16828 },
	{ (Il2CppRGCTXDataType)3, 16829 },
	{ (Il2CppRGCTXDataType)3, 16830 },
	{ (Il2CppRGCTXDataType)3, 16831 },
	{ (Il2CppRGCTXDataType)2, 21490 },
	{ (Il2CppRGCTXDataType)3, 16832 },
	{ (Il2CppRGCTXDataType)2, 21491 },
	{ (Il2CppRGCTXDataType)3, 16833 },
	{ (Il2CppRGCTXDataType)2, 21492 },
	{ (Il2CppRGCTXDataType)3, 16834 },
	{ (Il2CppRGCTXDataType)3, 16835 },
	{ (Il2CppRGCTXDataType)2, 18734 },
	{ (Il2CppRGCTXDataType)3, 16836 },
	{ (Il2CppRGCTXDataType)2, 21493 },
	{ (Il2CppRGCTXDataType)2, 21494 },
	{ (Il2CppRGCTXDataType)2, 18810 },
	{ (Il2CppRGCTXDataType)1, 18810 },
	{ (Il2CppRGCTXDataType)3, 16837 },
	{ (Il2CppRGCTXDataType)2, 18812 },
	{ (Il2CppRGCTXDataType)1, 18812 },
	{ (Il2CppRGCTXDataType)3, 16838 },
	{ (Il2CppRGCTXDataType)3, 16839 },
	{ (Il2CppRGCTXDataType)2, 21495 },
	{ (Il2CppRGCTXDataType)3, 16840 },
	{ (Il2CppRGCTXDataType)3, 16841 },
	{ (Il2CppRGCTXDataType)3, 16842 },
};
extern const Il2CppCodeGenModule g_UnityEngine_UICodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_UICodeGenModule = 
{
	"UnityEngine.UI.dll",
	1727,
	s_methodPointers,
	70,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	16,
	s_rgctxIndices,
	69,
	s_rgctxValues,
	NULL,
};
